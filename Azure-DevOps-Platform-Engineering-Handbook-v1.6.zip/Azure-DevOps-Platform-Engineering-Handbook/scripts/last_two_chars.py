def last_two(value: str) -> str:
    """Return the final two characters; shorter strings are returned unchanged."""
    return value[-2:]


if __name__ == "__main__":
    for sample in ("Azure", "A", ""):
        print(repr(sample), "->", repr(last_two(sample)))
