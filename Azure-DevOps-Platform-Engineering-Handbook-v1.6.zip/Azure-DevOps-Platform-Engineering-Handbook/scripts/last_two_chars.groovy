String lastTwo(String value) {
    return value == null ? "" : value.takeRight(2)
}

["Azure", "A", "", null].each { value ->
    println "${value} -> ${lastTwo(value)}"
}
