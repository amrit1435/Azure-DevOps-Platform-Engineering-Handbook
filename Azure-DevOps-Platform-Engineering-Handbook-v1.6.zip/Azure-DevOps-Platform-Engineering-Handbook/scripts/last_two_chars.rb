def last_two(value)
  value.to_s.last(2)
end

["Azure", "A", "", nil].each do |value|
  puts "#{value.inspect} -> #{last_two(value).inspect}"
end
