# Exported Documents

- `Azure-DevOps-Interview-Handbook.docx` - latest complete Word handbook.
- `Azure-DevOps-Interview-Handbook-v1.3.docx` - versioned v1.3 export.
- Earlier versioned exports are retained for change history.

- `Azure-DevOps-Interview-Handbook-v1.5.docx` - release 1.5 with Top 20 Azure + Terraform + DevSecOps Architect interview bank.
