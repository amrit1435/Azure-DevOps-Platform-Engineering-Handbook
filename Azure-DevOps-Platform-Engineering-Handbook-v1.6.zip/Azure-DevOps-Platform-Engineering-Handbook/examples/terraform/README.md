# Production Terraform Repository Example

```text
infrastructure/
├── modules/
│   ├── resource-group/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   ├── versions.tf
│   │   └── README.md
│   ├── network/
│   ├── key-vault/
│   └── monitoring/
├── environments/
│   ├── dev/
│   │   ├── backend.tf
│   │   ├── providers.tf
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── dev.example.tfvars
│   ├── qa/
│   └── prod/
├── policies/
├── tests/
└── pipelines/
```

## Rules

- Keep reusable modules separate from deployable roots.
- Use a separate backend key for each environment/component.
- Pin provider and module versions.
- Use Entra ID/OIDC to access the Azure Storage backend.
- Never commit state, real tfvars secrets or saved plans.
- Run format, validation, linting, security scanning and plan in pull requests.
- Require approvals for Production.
