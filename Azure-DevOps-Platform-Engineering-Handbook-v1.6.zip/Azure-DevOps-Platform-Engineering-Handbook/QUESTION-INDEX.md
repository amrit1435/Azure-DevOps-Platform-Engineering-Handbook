# Complete Question Index

## Profile and project

- Tell me about yourself with project details.
- Explain your daily activities and team contribution.
- Differentiate infrastructure and application.
- What is the aim of your project?
- Explain current project architecture.
- What infrastructure have you provisioned?
- How is the application deployed?
- Which technologies are used?

## Azure Administrator and networking

- Remove public IPs while maintaining access and outbound traffic.
- Private Endpoint exists but DNS resolves public IP.
- Troubleshoot Application Gateway 502.
- Configure Azure Front Door.
- NAT Gateway use cases.
- VM shutdown but billing continues.
- Extend Linux root filesystem/add disk.
- Diagnose high CPU with Azure-native tools.
- Centrally update multiple VMs.
- Azure Automation Accounts and Update Manager.
- Contributor but Blob access denied.
- API key as build-time/runtime secret and GitHub storage.
- Design high availability in Azure.
- CI/CD tools besides Azure DevOps.
- Workflow file definition.
- Pipeline file and location.
- Azure Web App configuration.

## Azure Landing Zone and Terraform

- Where Landing Zone is used in the project.
- What Azure Landing Zone is and why it is required.
- Landing Zone architecture.
- Management Group versus Subscription.
- Hub-and-Spoke architecture.
- Platform Landing Zone.
- Azure Policy and two examples.
- Policy versus RBAC.
- Design a Landing Zone for a new company.
- Automate Landing Zone.
- Terraform experience and purpose.
- Production Terraform repository organization.
- Manage Dev/QA/Production.
- Protect Terraform state.
- Handle drift.
- Terraform CI/CD pipeline content.

## TCS Platform Engineering, Azure and DevOps

All TCS questions are consolidated in one chapter. The primary questions include:

- Migrate monolith to microservices.
- Design a platform for 50 applications.
- Isolated environment architecture and security controls.
- Manage multiple environments with Terraform and CI/CD.
- Set up an Internal Developer Platform.
- Create a common dashboard for 50 applications.
- Metrics and tools for all applications.
- Multi-environment and CI/CD best practices.
- Create a pipeline from scratch.
- Troubleshoot pipeline logs.
- Centralized monitoring from scratch.
- Secure AKS.
- Azure Landing Zone components.
- Landing Zone validation and next steps before workload deployment.
- Azure Application Gateway and step-by-step configuration.
- Public, Internal, Standard and Gateway Load Balancer concepts.
- Current Azure Storage account types.
- `terraform plan` versus `terraform apply`.
- `provider.tf` content and provider aliases.
- Public IP association with NICs, frontends and NAT Gateway.
- Git branching strategies.
- CI versus continuous delivery/deployment.
- Step-by-step Azure subnet configuration.
- External/Public Load Balancer.
- Internal Load Balancer and use cases.
- Precautions before modifying an application on a VM.
- VM internet-connectivity troubleshooting.
- Docker scenario questions.
- Kubernetes scenario questions.
- CI/CD hands-on and scenario questions.
- End-to-end DevOps implementation.
- Day-to-day DevOps activities.
- CI/CD troubleshooting.
- Docker and Kubernetes troubleshooting.
- Azure networking scenarios.
- Terraform deployment and infrastructure troubleshooting.


## LTM Client Round 2

- Secure an Amazon S3 bucket.
- Connect two subnets in the same or different VPCs.
- Explain Azure Management Groups.
- Configure a Microsoft Entra app registration for an Azure DevOps pipeline.
- Explain AWS Transit Gateway.
- Explain when to use an AWS Application Load Balancer.
- Define Terraform drift and how to detect/remediate it.
- Explain Terraform data blocks.
- Explain how to use Ansible for configuration and deployment.
- Select A versus CNAME records for Azure Application Gateway.
- Explain an AWS IAM role trust policy.
- Explain why Terraform is idempotent in normal declarative use.

## Persistent DevSecOps

All 57 questions from the supplied Persistent interview list are answered in:

- DevSecOps fundamentals.
- CI/CD pipeline.
- Vulnerability management.
- SonarQube.
- Terraform security.
- GitHub Actions and Jenkins.
- Python, Groovy and Ruby.
- Current project.
- Container security.
- Build failure and remediation.

## Resume skills and missing core DevOps

- Azure DevOps services, environments, service connections, agents and templates.
- Variables, Key Vault, artifacts and rollback.
- Git branching, merge/rebase and reset/revert.
- ARM/Bicep versus Terraform.
- Terraform count, for_each, lifecycle and import.
- PowerShell, Bash and Azure CLI.
- Entra ID, RBAC, Managed Identity and Conditional Access.
- Backup versus Site Recovery.
- Azure Monitor, Log Analytics, Application Insights and KQL.
- Incident/change management and ISO 27001.
- Docker, AKS, Helm, autoscaling and GitOps.
- Intune/M365 relevance and automation outcomes.


## Azure DevOps, Terraform and Production Deployment Round

Detailed answers: [`docs/10-azure-devops-terraform-production-round/README.md`](docs/10-azure-devops-terraform-production-round/README.md)

Questions 1-22 cover introduction, infrastructure-to-DevOps journey, end-to-end application CI/CD, failed Production deployment, Azure DevOps and Terraform infrastructure pipelines, service connections, managed identities, agents, Terraform drift/state/refresh/deleted resources/locking, PaaS deployment, 10x scaling and high availability.

## Architect-Level Azure Landing Zone

- [Enterprise-scale regulated Azure Landing Zone end-to-end architecture](docs/11-architect-level-azure-landing-zone/README.md)


## Top 20 Azure + Terraform + DevSecOps Architect Questions

Detailed answers: [`docs/12-top-20-terraform-architect/README.md`](docs/12-top-20-terraform-architect/README.md)

1. Enterprise Terraform architecture for Azure.
2. Remote backend, state locking and production state management.
3. State isolation for Dev, QA, UAT, Prod and multiple workloads.
4. Root modules, child modules and reusable module design.
5. `count` versus `for_each`.
6. Nested maps/objects with `for_each`.
7. Azure Landing Zone from scratch to production with Terraform.
8. Hub-and-spoke networking with VNet, subnet, NSG, UDR, Firewall and peering.
9. Service Principal versus Managed Identity versus OIDC for Terraform authentication.
10. Terraform secrets and Azure Key Vault integration.
11. Complete Terraform DevSecOps pipeline.
12. Checkov, tfsec, TFLint and secret scanning.
13. Terraform drift detection and remediation.
14. Unexpected destruction/recreation in `terraform plan`.
15. Importing existing Azure infrastructure into Terraform.
16. Terraform lifecycle controls.
17. Multi-team state ownership, conflicts and concurrent deployments.
18. Production-grade private AKS with Terraform.
19. Recovery from partial `terraform apply` or Azure API failure.
20. Multi-subscription, multi-region Azure Landing Zone + Terraform + DevSecOps platform.


## Git Fundamentals Interview Bank

Detailed answers: [`docs/07-git-github-guide/README.md`](docs/07-git-github-guide/README.md)

- Git, version control, repository, working directory and staging area.
- `git add`, `git commit`, commit messages and basic workflow.
- `git status`, history and `git log`.
- Branches, main, switching, merging and merge conflicts.
- Remote repositories and GitHub.
- `git push`, `git pull`, `git clone`, and key command differences.
- Local-to-remote communication and a beginner-friendly Git explanation.
