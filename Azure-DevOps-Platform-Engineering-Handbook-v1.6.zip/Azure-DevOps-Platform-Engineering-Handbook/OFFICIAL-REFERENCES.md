# Official References

## Microsoft Azure

- Azure Landing Zones: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/
- Landing Zone design areas: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/design-areas
- Azure Storage private endpoints: https://learn.microsoft.com/azure/storage/common/storage-private-endpoints
- Application Gateway 502 troubleshooting: https://learn.microsoft.com/troubleshoot/azure/application-gateway/application-gateway-troubleshooting-502
- Azure Update Manager: https://learn.microsoft.com/azure/update-manager/overview
- AKS security concepts and best practices: https://learn.microsoft.com/azure/aks/concepts-security
- Application Gateway overview: https://learn.microsoft.com/azure/application-gateway/overview
- Application Gateway configuration: https://learn.microsoft.com/azure/application-gateway/configuration-overview
- Create Application Gateway: https://learn.microsoft.com/azure/application-gateway/quick-create-portal
- Azure Load Balancer SKUs: https://learn.microsoft.com/azure/load-balancer/skus
- Azure Storage account types: https://learn.microsoft.com/azure/storage/common/storage-account-overview
- Manage Azure subnets: https://learn.microsoft.com/azure/virtual-network/virtual-network-manage-subnet
- Azure public IP addresses: https://learn.microsoft.com/azure/virtual-network/ip-services/public-ip-addresses
- Default outbound access: https://learn.microsoft.com/azure/virtual-network/ip-services/default-outbound-access
- Network Watcher connection troubleshoot: https://learn.microsoft.com/azure/network-watcher/connection-troubleshoot-manage
- Effective security rules: https://learn.microsoft.com/azure/network-watcher/effective-security-rules-overview
- Azure Management Groups: https://learn.microsoft.com/azure/governance/management-groups/overview
- Azure Resource Manager service connections: https://learn.microsoft.com/azure/devops/pipelines/library/connect-to-azure
- Entra federated identity credentials: https://learn.microsoft.com/entra/workload-id/workload-identity-federation-create-trust
- Convert older Azure DevOps WIF service connections: https://learn.microsoft.com/azure/devops/pipelines/release/convert-service-connections
- Application Gateway custom DNS guidance: https://learn.microsoft.com/azure/application-gateway/configure-web-app

## GitHub

- GitHub Actions workflows: https://docs.github.com/actions/concepts/workflows-and-actions/workflows
- Workflow syntax: https://docs.github.com/actions/reference/workflows-and-actions/workflow-syntax

## HashiCorp Terraform

- Standard module structure: https://developer.hashicorp.com/terraform/language/modules/develop/structure
- AzureRM backend: https://developer.hashicorp.com/terraform/language/backend/azurerm
- Terraform state: https://developer.hashicorp.com/terraform/language/state
- Terraform plan: https://developer.hashicorp.com/terraform/cli/commands/plan
- Terraform apply: https://developer.hashicorp.com/terraform/cli/commands/apply
- Terraform providers: https://developer.hashicorp.com/terraform/language/providers
- Provider requirements: https://developer.hashicorp.com/terraform/language/providers/requirements
- Terraform data sources: https://developer.hashicorp.com/terraform/language/data-sources
- Manage Terraform resource drift: https://developer.hashicorp.com/terraform/tutorials/state/resource-drift

## Sonar

- Analysis overview: https://docs.sonarsource.com/sonarqube-server/analyzing-source-code/analysis-overview
- Branch analysis: https://docs.sonarsource.com/sonarqube-server/analyzing-source-code/branch-analysis/introduction

## Trivy and tfsec

- Trivy vulnerability scanning: https://trivy.dev/docs/latest/scanner/vulnerability/
- Trivy filtering: https://trivy.dev/docs/latest/configuration/filtering/
- tfsec configuration: https://aquasecurity.github.io/tfsec/latest/guides/configuration/config/
- tfsec custom checks: https://aquasecurity.github.io/tfsec/latest/guides/configuration/custom-checks/

## Microsoft DevOps and Git

- Continuous integration: https://learn.microsoft.com/devops/develop/what-is-continuous-integration
- DevOps architecture and CI/CD concepts: https://learn.microsoft.com/azure/architecture/guide/devops/devops-get-started
- Microsoft Git branching and release flow: https://learn.microsoft.com/devops/develop/how-microsoft-develops-devops

## Amazon Web Services

- Amazon S3 security best practices: https://docs.aws.amazon.com/AmazonS3/latest/userguide/security-best-practices.html
- S3 Block Public Access: https://docs.aws.amazon.com/AmazonS3/latest/userguide/access-control-block-public-access.html
- Amazon VPC subnet route tables: https://docs.aws.amazon.com/vpc/latest/userguide/subnet-route-tables.html
- Amazon VPC peering: https://docs.aws.amazon.com/vpc/latest/userguide/vpc-peering.html
- AWS Transit Gateway: https://docs.aws.amazon.com/vpc/latest/tgw/what-is-transit-gateway.html
- AWS Application Load Balancer: https://docs.aws.amazon.com/elasticloadbalancing/latest/application/introduction.html
- AWS IAM roles and trust policies: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles.html

## Ansible

- Ansible playbooks: https://docs.ansible.com/projects/ansible/latest/playbook_guide/index.html
- Ansible inventory: https://docs.ansible.com/projects/ansible/latest/inventory_guide/intro_inventory.html
- Reusable Ansible roles: https://docs.ansible.com/projects/ansible/latest/playbook_guide/playbooks_roles.html
