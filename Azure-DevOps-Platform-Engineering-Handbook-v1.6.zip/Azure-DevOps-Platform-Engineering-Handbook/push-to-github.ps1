param(
    [string]$RepoUrl = "https://github.com/amrit1435/Azure-DevOps-Platform-Engineering-Handbook.git",
    [string]$CommitMessage = "Add complete Azure DevOps interview handbook"
)

$ErrorActionPreference = "Stop"

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw "Git is not installed or not available in PATH."
}

if (-not (Test-Path ".git")) {
    git init
}

git branch -M main

$origin = git remote 2>$null | Where-Object { $_ -eq "origin" }
if ($origin) {
    git remote set-url origin $RepoUrl
} else {
    git remote add origin $RepoUrl
}

git add .
$changes = git status --porcelain
if ($changes) {
    git commit -m $CommitMessage
} else {
    Write-Host "No local changes to commit."
}

Write-Host "Pushing to origin/main..."
git push -u origin main
