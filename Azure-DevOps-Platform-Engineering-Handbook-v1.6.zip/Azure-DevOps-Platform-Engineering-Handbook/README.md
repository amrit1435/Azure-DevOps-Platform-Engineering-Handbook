# Azure DevOps, Platform Engineering and DevSecOps Interview Handbook

**Author:** Amritpal Singh  
**Focus:** Core DevOps functional work using Microsoft Azure  
**Edition:** 2026  
**Status:** Release 1.6 - Git Fundamentals interview question bank added

This repository is a practical interview-preparation handbook for the following profiles:

- Azure DevOps Engineer
- Azure Cloud Administrator / Engineer
- DevSecOps Engineer
- Platform Engineer
- Cloud Infrastructure Engineer
- Site Reliability Engineer
- Azure Solution Architect (infrastructure-focused)

The content combines:

1. Questions provided from real interviews, including TCS Platform Engineering, Persistent DevSecOps and LTM client rounds.
2. Questions derived from the author's resume and hands-on skills.
3. Missing core DevOps topics required for Azure-focused roles.
4. Simple explanations, project scenarios, commands, troubleshooting steps and follow-up questions.

> Important: Keep project answers truthful. Replace sample client details, metrics and technologies with facts that you can defend in follow-up questions. Topics outside direct hands-on experience should be presented as interview knowledge or working familiarity.

## Handbook sections

| Section | Content |
|---|---|
| [01 - Profile and Current Project](docs/01-profile-and-project/README.md) | Introduction, project architecture, daily work, role and contribution |
| [02 - Azure Administrator and Networking](docs/02-azure-administrator-networking/README.md) | Public/private access, DNS, App Gateway, Front Door, NAT, VMs, storage, HA and Web Apps |
| [03 - Azure Landing Zone and Terraform](docs/03-azure-landing-zone-terraform/README.md) | Landing Zone, management groups, policies, hub-spoke, automation and repository design |
| [04 - Complete TCS Interview Bank](docs/04-platform-engineering-tcs/README.md) | 37 primary questions covering platform engineering, Azure Landing Zone, networking, Terraform, CI/CD, Docker, Kubernetes and troubleshooting |
| [05 - Persistent DevSecOps](docs/05-devsecops-persistent/README.md) | DevSecOps, CI/CD, SonarQube, Trivy, tfsec, containers and build-failure scenarios |
| [06 - Resume Skills and Core DevOps](docs/06-core-devops-resume-skills/README.md) | Azure DevOps, Git, scripting, identity, backup, monitoring, Docker/AKS and missing interview topics |
| [07 - Git Fundamentals and GitHub Guide](docs/07-git-github-guide/README.md) | 38 Git fundamentals interview questions plus exact VS Code/GitHub publishing commands |
| [08 - Rapid Revision](docs/08-rapid-revision/README.md) | One-line answers, troubleshooting order and interview response frameworks |
| [09 - LTM Client Round 2](docs/09-ltm-client-round-2/README.md) | AWS S3, VPC networking, Transit Gateway, ALB, Azure pipeline identity, Terraform, Ansible and DNS |
| [10 - Azure DevOps Terraform Production Round](docs/10-azure-devops-terraform-production-round/README.md) | Production CI/CD, Terraform state, drift, locking, PaaS scaling and HA |
| [11 - Architect Azure Landing Zone](docs/11-architect-level-azure-landing-zone/README.md) | Enterprise-scale regulated Azure Landing Zone architecture |
| [12 - Top 20 Terraform Architect Questions](docs/12-top-20-terraform-architect/README.md) | Priority Senior/Architect Terraform, Landing Zone, DevSecOps and Private AKS scenarios |

## Downloadable export

- [Complete Microsoft Word handbook](exports/Azure-DevOps-Interview-Handbook.docx)
- [TCS interview repetition tracker](interview-tracker/TCS-INTERVIEW-LOG.md)
- [LTM client round 2 tracker](interview-tracker/LTM-CLIENT-ROUND-2-LOG.md)

## Practical examples

- [Azure DevOps Terraform pipeline](examples/azure-devops/terraform-pipeline.yml)
- [GitHub Actions security workflow](examples/github-actions/devsecops.yml)
- [Jenkins DevSecOps pipeline](examples/jenkins/Jenkinsfile)
- [Terraform production repository example](examples/terraform/README.md)
- [Live coding examples](scripts/)

## How to study

For each question, prepare three versions:

- **30 seconds:** definition and purpose.
- **2 minutes:** design, implementation and security.
- **5 minutes:** real scenario, troubleshooting, trade-offs and result.

Use this speaking structure for scenario questions:

```text
Requirement -> Design choice -> Implementation -> Security -> Validation -> Result
```

Use STAR for experience questions:

```text
Situation -> Task -> Action -> Result
```

## Experience classification

### Resume-aligned hands-on strengths

- Microsoft Azure infrastructure administration
- Azure DevOps pipelines and release automation
- Terraform and ARM/Bicep infrastructure as code
- PowerShell, Bash and Azure CLI automation
- Azure networking, VMs, storage, backup, Site Recovery and monitoring
- Entra ID, Conditional Access, MFA, SSPR, RBAC and hybrid identity
- Git-based branching and pull-request workflows
- Windows and Linux operations
- ITIL incident/change management and ISO 27001 governance

### Working familiarity / interview knowledge

- Docker and AKS
- Jenkins and Groovy
- SonarQube, Trivy and tfsec
- Internal Developer Platforms and Backstage
- Prometheus, Grafana and OpenTelemetry
- Advanced Kubernetes and GitOps

## Security warning

Never commit any of the following:

- Passwords, API keys, tokens or certificates
- Terraform state files or saved plans containing sensitive data
- Real tenant IDs, subscription IDs or client secrets
- Client names and confidential architecture diagrams
- `.env`, secret `.tfvars`, `.pfx`, `.pem` or private keys

Use a private repository until all employer and client information has been sanitized.

## Suggested first commit

```bash
git add .
git commit -m "Add Azure DevOps interview handbook"
git push -u origin main
```

See the complete instructions in [Git and GitHub Push Guide](docs/07-git-github-guide/README.md).

## Latest Interview Round

- [Azure DevOps, Terraform and Production Deployment Round](docs/10-azure-devops-terraform-production-round/README.md)

### Architect-level architecture chapter

- [Enterprise Azure Landing Zone: end-to-end regulated architecture](docs/11-architect-level-azure-landing-zone/README.md)

### Priority-1 Terraform Architect preparation

- [Top 20 Azure + Terraform + DevSecOps Architect questions](docs/12-top-20-terraform-architect/README.md)
