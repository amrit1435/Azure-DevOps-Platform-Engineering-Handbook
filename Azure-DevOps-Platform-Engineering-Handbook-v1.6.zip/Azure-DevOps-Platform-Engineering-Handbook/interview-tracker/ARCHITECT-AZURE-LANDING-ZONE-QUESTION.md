# Architect-Level Azure Landing Zone Interview Tracker

## Question category

- Azure Cloud Architect
- Azure Landing Zone Architect
- Principal Cloud Architect
- Senior DevSecOps Architect

## Core areas

- Management groups and subscriptions
- Governance and policy as code
- Identity and privileged access
- Hub-and-spoke and Virtual WAN
- Private connectivity and DNS
- Terraform modules and remote state
- Azure DevOps and GitHub Actions
- DevSecOps scanning
- Monitoring and security operations
- Backup and disaster recovery
- Cost optimization and Well-Architected Framework

## Repeat tracking

| Date | Company | Role | Round | Exact wording | Repeated topic | Notes |
|---|---|---|---|---|---|---|
| 2026-07-31 | Not specified | Architect-level Azure role | Not specified | Enterprise-scale Azure Landing Zone end-to-end | New canonical architecture question | Comprehensive design question |

## Revision priority

1. Two-minute executive answer.
2. Management-group and subscription hierarchy.
3. Hub-and-spoke traffic flow.
4. Terraform repository and state design.
5. CI/CD gates and workload identity federation.
6. RTO/RPO, backup and cross-region DR.
7. Well-Architected mapping and cost optimization.
