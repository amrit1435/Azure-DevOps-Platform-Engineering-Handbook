# Top 20 Terraform Architect Priority Tracker

Source: consolidated Senior / Architect / SME interview-preparation list supplied on 2026-08-18.

## Priority-1 (highest architect weight)

- Q1 Enterprise Terraform architecture
- Q2 Remote state and locking
- Q7 Azure Landing Zone with Terraform
- Q8 Hub-and-spoke networking
- Q9 Secure Terraform authentication
- Q11 Terraform DevSecOps pipeline
- Q13 Drift
- Q17 Multi-team state ownership
- Q18 Private AKS
- Q20 Multi-subscription multi-region platform

## Study status

Use this file to mark each question: Not Started / Reading / Can Answer 2 min / Can Answer 5 min / Mock Interview Ready.
