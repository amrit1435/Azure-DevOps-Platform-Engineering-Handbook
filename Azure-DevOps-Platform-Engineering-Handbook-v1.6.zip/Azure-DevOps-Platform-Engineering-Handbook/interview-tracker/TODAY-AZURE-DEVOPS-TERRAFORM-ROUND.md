# Interview Log - Azure DevOps, Terraform and Production Deployment Round

## Interview metadata

- Date received: 2026-07-22
- Round: Technical interview
- Main areas: Azure DevOps, Terraform, production deployment, PaaS, scaling and high availability
- Total questions: 22

## Questions captured

1. Introduce yourself and explain your DevOps journey.
2. How did you move from infrastructure to DevOps?
3. Explain one Azure DevOps CI/CD pipeline from code commit to Production deployment.
4. Production deployment failed: build versus release, logs and rollback.
5. Explain one infrastructure pipeline using Azure DevOps and Terraform.
6. Explain Service Connection.
7. Managed Identity versus Service Principal.
8. Azure-hosted agent versus self-hosted agent.
9. Detect Terraform drift after a manual Azure change.
10. Explain Terraform state file.
11. Explain refresh.
12. How does Terraform plan detect deleted resources?
13. How do you restore deleted resources?
14. What is zero drift or equilibrium state?
15. How do multiple engineers work on the same Terraform project?
16. Explain state locking.
17. Explain application CI/CD pipeline.
18. Explain every step from Git push to Production.
19. Which Azure PaaS services have you worked on?
20. Explain one application deployed using Azure PaaS.
21. Application load becomes 10x: what do you scale?
22. How do you achieve high availability?

## Repeated-topic signals

The following topics also appeared in earlier interview collections and should be treated as high-priority revision areas:

- End-to-end CI/CD pipeline.
- Terraform plan, state, drift and team collaboration.
- Azure DevOps service connections and agents.
- Production troubleshooting and rollback.
- Application hosting and scalability.
- High availability architecture.

## Action items

- Practice a 90-second introduction and a 3-minute project explanation.
- Be able to draw both application and infrastructure pipeline flows.
- Practice one real deployment-failure story using Situation, Action and Result.
- Run a Terraform drift lab by changing a test resource manually and reviewing the next plan.
- Practice App Service slot deployment and rollback.
