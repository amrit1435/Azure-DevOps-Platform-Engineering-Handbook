# TCS Interview Question Repetition Tracker

Use this file after every TCS interview or after receiving questions from another candidate. The purpose is to identify repeated questions and focus revision on the highest-frequency topics.

## Frequency labels

- **Repeated frequently** - confirmed in three or more recorded interviews.
- **Asked twice** - confirmed in two recorded interviews.
- **Asked once** - confirmed in one recorded interview.
- **Hands-on task** - requires commands, YAML, Terraform or live troubleshooting.
- **Needs lab practice** - answer is understood but implementation needs practice.
- **Frequency not measured** - the question is in the current collection, but no verified interview count has been recorded yet.

## Current question groups

The initial collection below is grouped by topic. Frequency is deliberately marked as **not measured** until real interview records are added.

| Group | Current status | Notes |
|---|---|---|
| Azure Landing Zone | Frequency not measured | Components, platform/application landing zones, governance and next steps |
| Azure networking | Frequency not measured | Subnets, public/private IPs, VM internet, Application Gateway and Load Balancer |
| Terraform | Frequency not measured | Plan/apply, providers, state, multi-environment and failures |
| CI/CD | Frequency not measured | CI versus CD, pipeline creation, logs, failures and approvals |
| Docker | Hands-on task; frequency not measured | Runtime, ports, permissions, images and vulnerability failures |
| Kubernetes/AKS | Hands-on task; frequency not measured | Pod states, services, networking, resources and security |
| Platform Engineering | Frequency not measured | IDP, 50 applications, dashboards and developer productivity |
| Monitoring | Frequency not measured | Common dashboards, metrics, alerts and central observability |

> Update frequency only from real interview evidence. Do not invent a count.

## Interview record template

### TCS interview - YYYY-MM-DD

- **Role:**
- **Round:**
- **Location/Business unit:**
- **Interviewer focus:**
- **Questions asked:**
  1.
  2.
  3.
- **Questions repeated from the handbook:**
- **New questions to add:**
- **Hands-on task given:**
- **Questions not answered confidently:**
- **Topics to revise:**
- **Result or feedback:**

## Monthly review

At the end of each month:

1. Merge duplicate questions with different wording.
2. Increase the frequency label only when supported by a real interview record.
3. Add a short, detailed and scenario answer for every new question.
4. Add commands or a lab for hands-on questions.
5. Move the top repeated questions into the Rapid Revision chapter.
