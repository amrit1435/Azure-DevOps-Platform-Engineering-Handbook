# LTM Client Round 2 Interview Log

- **Recorded on:** 2026-07-20
- **Round:** Client Round 2
- **Interviewers:** Two international client interviewers
- **Main focus:** AWS networking and security, Azure governance and pipeline identity, Terraform, Ansible and DNS

## Questions asked

1. How will you secure an S3 bucket?
2. How can you connect two subnets?
3. What is an Azure Management Group?
4. How would you configure an app registration so that it connects to a pipeline?
5. What is AWS Transit Gateway?
6. When do we use Application Load Balancer?
7. What is Terraform drift?
8. What is a Terraform data block?
9. How would you use Ansible?
10. Which DNS record maps the public IP of Azure Application Gateway?
11. What is an AWS IAM trust policy?
12. Why are IaC tools such as Terraform idempotent?

## Topic analysis

| Topic | Questions | Revision priority |
|---|---:|---|
| AWS security and identity | 1, 11 | High |
| AWS networking and load balancing | 2, 5, 6 | High |
| Azure governance and identity | 3, 4 | High |
| Terraform | 7, 8, 12 | High |
| Configuration management | 9 | Medium to high |
| Azure DNS/Application Gateway | 10 | Medium |

## Practical labs to complete

- Create a private S3 bucket with Block Public Access, SSE-KMS, versioning and TLS-enforcement policy.
- Connect two test VPCs by VPC peering and validate routes, security groups and DNS.
- Build a small Transit Gateway topology with separate route tables for Production and Development.
- Create an Azure DevOps ARM service connection using workload identity federation.
- Run a scheduled Terraform drift-detection plan.
- Use Terraform data sources to reference an existing VNet or AMI.
- Configure two Linux VMs with an Ansible inventory and idempotent playbook.
- Create an A record and CNAME test for an Application Gateway custom domain.

## Questions to practise aloud

Use this response structure:

```text
Definition -> When to use -> Configuration -> Security -> Scenario -> Troubleshooting
```

## Confidence tracker

| Question | Confidence: Low/Medium/High | Lab completed | Notes |
|---|---|---|---|
| S3 security |  |  |  |
| Connect subnets |  |  |  |
| Azure Management Group |  |  |  |
| Pipeline app registration |  |  |  |
| Transit Gateway |  |  |  |
| Application Load Balancer |  |  |  |
| Terraform drift |  |  |  |
| Terraform data block |  |  |  |
| Ansible |  |  |  |
| Application Gateway DNS |  |  |  |
| IAM trust policy |  |  |  |
| Terraform idempotency |  |  |  |
