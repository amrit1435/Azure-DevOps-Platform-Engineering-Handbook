# 03 - Azure Landing Zone and Terraform Interview Questions

---

## 1. Where are you using Azure Landing Zone in your project?

### Interview answer

We use Azure Landing Zone as the foundation of the Azure environment, not as one individual application resource. It defines how subscriptions are organized, how shared networking is provided, how policies and RBAC are inherited, how logs are centralized and how application environments are onboarded.

A typical implementation contains:

- Platform subscriptions for connectivity, management and shared identity services.
- Application subscriptions for Dev, QA and Production.
- Management-group-based policy and RBAC inheritance.
- Hub-spoke networking and private connectivity.
- Central Log Analytics, monitoring and security services.
- Terraform and CI/CD for repeatable deployment.

### Project scenario

> The monitoring application needed Dev, QA and Production environments. Instead of creating all resources in one subscription, we placed workload subscriptions under the appropriate landing-zone management group. Each subscription inherited mandatory tags, diagnostic settings and public-access restrictions, then connected to the shared hub network.

---

## 2. What is an Azure Landing Zone and why do we need it?

### Short answer

An Azure Landing Zone is a standardized, scalable and governed Azure foundation prepared to host workloads. It combines identity, subscription organization, networking, security, policy, monitoring, operations and automation.

### Why it is needed

Without a landing zone, teams often create resources directly in unrelated subscriptions. This causes:

- Inconsistent security.
- Overlapping IP ranges.
- Excessive permissions.
- Missing logs and backups.
- Uncontrolled public access.
- Poor ownership and cost visibility.
- Slow onboarding for every new application.

A landing zone provides secure defaults and repeatable guardrails while allowing application teams to deploy within approved boundaries.

### Scenario

> Three application teams independently created Azure environments. Each used different naming, networking and logging. A landing-zone model standardized subscription vending, networking, policies and monitoring, so future teams received a ready-to-use foundation.

---

## 3. Explain Azure Landing Zone architecture

### Conceptual architecture

```mermaid
flowchart TB
    Tenant[Microsoft Entra Tenant]
    Root[Tenant Root Group]
    Org[Organization Management Group]
    Platform[Platform]
    LZ[Landing Zones]
    Sandbox[Sandbox]
    Decom[Decommissioned]
    Identity[Identity Subscription]
    Connectivity[Connectivity Subscription]
    Management[Management Subscription]
    Corp[Corp Management Group]
    Online[Online Management Group]
    Dev[Application Dev Subscription]
    Prod[Application Prod Subscription]

    Tenant --> Root --> Org
    Org --> Platform
    Org --> LZ
    Org --> Sandbox
    Org --> Decom
    Platform --> Identity
    Platform --> Connectivity
    Platform --> Management
    LZ --> Corp
    LZ --> Online
    Corp --> Dev
    Online --> Prod
```

### Main design areas

1. Azure billing and Entra tenant.
2. Identity and access management.
3. Management groups and subscription organization.
4. Network topology and connectivity.
5. Security.
6. Management and operations.
7. Governance.
8. Platform automation and DevOps.

### Interview explanation

The Entra tenant provides identity. Management groups organize subscriptions by governance requirement. Platform subscriptions host shared identity, connectivity and management services. Application landing zones host individual workloads or environments. Azure Policy and RBAC are assigned at the correct hierarchy level so subscriptions inherit controls. Hub-spoke or Virtual WAN provides connectivity. Monitoring, security and backup services are centralized where appropriate. The complete platform is deployed and maintained through infrastructure as code.

---

## 4. Difference between Management Group and Subscription

| Management Group | Subscription |
|---|---|
| Governance container above subscriptions | Billing, quota and resource-management boundary |
| Contains child management groups or subscriptions | Contains resource groups and Azure resources |
| Used for inherited policy and RBAC | Used to isolate workload, environment, ownership and cost |
| Does not normally host workload resources directly | Hosts VMs, VNets, storage, databases and other resources |
| Designed around common governance needs | Designed around lifecycle, limits and operational boundaries |

### Interview example

> I may assign a policy initiative at the Production management group so every production subscription inherits logging and public-network restrictions. The actual application resources are created inside resource groups in the subscription.

### Design warning

Do not copy the complete company reporting structure into management groups. Keep the hierarchy reasonably shallow and organize subscriptions mainly by policy and governance requirements.

---

## 5. Explain Hub-and-Spoke architecture

### Short answer

Hub-and-spoke is a network topology where a central hub VNet provides shared connectivity and security services, and spoke VNets host separate applications or environments.

### Hub services

- Azure Firewall or approved NVA.
- VPN Gateway or ExpressRoute Gateway.
- Azure Bastion.
- Private DNS Resolver or central DNS services.
- Shared routing and egress.
- DDoS-related controls where required.

### Spoke services

- Application VMs.
- AKS or other compute.
- Private Endpoints.
- Databases and application services.
- Team- or workload-specific subnets.

### Important point

VNet peering is not transitive. Spoke A cannot automatically reach Spoke B simply because both are peered to the hub. Inter-spoke routing must be deliberately designed through a firewall, NVA, Virtual WAN or another supported routing pattern.

### Scenario

> Production and non-production workloads had separate spokes. All outbound traffic followed UDRs to Azure Firewall in the hub. On-premises traffic entered through ExpressRoute, and private DNS resolution was centralized.

---

## 6. What is a Platform Landing Zone?

### Interview answer

A Platform Landing Zone is the centrally managed Azure foundation that provides shared services to application landing zones.

It commonly includes:

- Management-group hierarchy.
- Azure Policy assignments.
- Connectivity subscription and hub networking.
- Management subscription with monitoring and automation.
- Identity-related shared services when required.
- Security services and central diagnostics.
- Subscription vending and platform automation.

An **Application Landing Zone** is the subscription or set of subscriptions where a specific application or workload is deployed. The platform team operates shared capabilities; the application team operates the workload within the guardrails.

### Scenario

> The platform team managed Azure Firewall, ExpressRoute, Log Analytics and global policies. The application team managed its React, Python and database resources in separate application landing-zone subscriptions.

---

## 7. What are Azure Policies? Describe two policies

### Interview answer

Azure Policy evaluates resources against business and technical rules. A policy definition contains a condition and an effect, and multiple policies can be grouped into an initiative.

Common effects include:

- Audit.
- Deny.
- Modify.
- Append.
- DeployIfNotExists.
- AuditIfNotExists.
- Disabled.

### Policy example 1 - Allowed locations

The policy limits deployments to approved Azure regions. If the company permits only specific regions because of data residency or operational support, a Deny effect can block deployments elsewhere.

### Policy example 2 - Deploy diagnostic settings

A DeployIfNotExists policy checks whether supported resources send required logs to a central Log Analytics workspace. If not, a remediation task can deploy the missing configuration when the policy assignment identity has the required permissions.

### Additional examples

- Deny public IP creation.
- Require tags such as Owner, CostCenter and Environment.
- Restrict VM SKUs.
- Require HTTPS-only storage.
- Audit or deny public network access.
- Deploy Defender settings.

### Scenario

> A developer attempted to create a storage account with public network access. RBAC allowed the creation, but Azure Policy denied the noncompliant configuration and provided a policy violation message.

---

## 8. Difference between Azure Policy and RBAC

| Azure Policy | Azure RBAC |
|---|---|
| Controls what resource configuration is allowed or required | Controls who can perform which action at what scope |
| Evaluates compliance and configuration | Evaluates identity permissions |
| Can audit, deny, modify or deploy settings | Allows management-plane or data-plane operations through roles |
| Example: deny public storage | Example: grant Storage Blob Data Reader |

### One-line answer

RBAC answers **who can do what**, while Policy answers **what configuration is permitted or required**.

### Scenario

> A user with Contributor could create a storage account, but Policy prevented creation when public access was enabled. The same user still needed a Blob data role to read container data.

---

## 9. You join a new company and must design its Azure Landing Zone. How would you do it?

### Step 1 - Discovery

Gather:

- Business units and expected workloads.
- Regulatory and data-residency requirements.
- Existing tenants, subscriptions and billing model.
- On-premises connectivity.
- Identity and privileged-access model.
- Production/non-production separation.
- Availability, RTO and RPO.
- Cost ownership and chargeback.
- Existing monitoring, SIEM and ITSM processes.

### Step 2 - Tenant and identity

- Confirm Entra tenant and emergency-access model.
- Create groups for platform, network, security and workload roles.
- Use least-privilege RBAC.
- Use PIM for privileged roles.
- Use managed identity or workload identity for applications and automation.
- Define Conditional Access and MFA requirements.

### Step 3 - Management groups

Example:

```text
Organization
├── Platform
│   ├── Identity
│   ├── Connectivity
│   └── Management
├── Landing-Zones
│   ├── Corp
│   └── Online
├── Sandbox
└── Decommissioned
```

### Step 4 - Subscription strategy

Create subscriptions based on environment, workload, ownership, limits and compliance. Common subscriptions include connectivity, management, identity, shared services, Dev, Test and Production.

### Step 5 - Networking

- Select hub-spoke or Virtual WAN.
- Plan non-overlapping IP addresses.
- Design VPN/ExpressRoute.
- Implement firewall, UDRs and egress controls.
- Centralize private DNS resolution.
- Use Private Endpoints for PaaS services.
- Define inbound publishing patterns.

### Step 6 - Governance and security

Create initiatives for:

- Allowed regions and resource types.
- Required tags.
- Diagnostic settings.
- Public network restrictions.
- Encryption and Key Vault controls.
- Defender for Cloud.
- Backup and recovery requirements.

### Step 7 - Management and operations

- Central Azure Monitor and Log Analytics.
- Activity Log export.
- Service Health alerts.
- Backup and recovery.
- Update management.
- Incident, change and access processes.

### Step 8 - Automation and subscription vending

Use Terraform or Bicep, Git, pull requests, security scanning and controlled pipelines. A subscription-vending workflow should apply management-group placement, budget, tags, RBAC, network connection, logging and policy automatically.

### Step 9 - Pilot and iterate

Deploy one low-risk workload, validate controls, collect feedback and then scale.

### Interview statement

> I treat the Microsoft reference architecture as a starting point, not a template that must be copied without understanding the company's requirements.

---

## 10. How do you automate Azure Landing Zone?

### Interview answer

I automate it through infrastructure as code, source control and CI/CD.

A standard workflow is:

1. Define management groups, policies, subscriptions, networking, logging and role assignments in Terraform or Bicep.
2. Store code in Git.
3. Use reusable, versioned modules.
4. Run formatting, validation, linting and security checks in pull requests.
5. Generate a plan and require review.
6. Use workload identity federation or managed identity for pipeline authentication.
7. Apply changes through protected environment stages.
8. Store state remotely with locking and restricted access.
9. Run scheduled plans for drift detection.
10. Version releases and maintain change records.

### Scenario

> A new workload subscription request triggered a reviewed pipeline. The automation created the subscription, moved it to the correct management group, assigned policies and RBAC, connected networking, enabled diagnostics and applied a budget.

---

## 11. Have you worked with Terraform? Why do we use it?

### Interview answer

Yes. Terraform is a declarative Infrastructure-as-Code tool. We describe the desired infrastructure in code, and Terraform compares configuration, state and the real platform to create an execution plan.

We use Terraform for:

- Repeatable deployments.
- Version control and peer review.
- Reusable modules.
- Consistency between environments.
- Reduced manual errors.
- Change preview with `terraform plan`.
- Multi-provider support.
- CI/CD automation.
- Drift visibility.

### Normal workflow

```bash
terraform fmt -check -recursive
terraform init
terraform validate
terraform plan -out=tfplan
terraform apply tfplan
```

### Scenario

> A VNet was manually modified in the portal. The next Terraform plan showed the difference. The team decided whether to accept the change into code or revert the manual drift.

---

## 12. How do you organize a production Terraform repository?

### Recommended structure

```text
infrastructure/
├── modules/
│   ├── resource-group/
│   ├── virtual-network/
│   ├── key-vault/
│   ├── virtual-machine/
│   └── monitoring/
├── environments/
│   ├── dev/
│   ├── qa/
│   └── prod/
├── policies/
├── scripts/
├── tests/
├── .github/workflows/
└── azure-pipelines.yml
```

Each reusable module normally contains:

```text
main.tf
variables.tf
outputs.tf
versions.tf
README.md
```

Each deployable environment/root module contains its own backend key, provider configuration, module calls and environment-specific variables.

### Production practices

- Separate state by lifecycle and blast radius.
- Use Azure Storage remote backend with locking.
- Authenticate through Entra ID and OIDC/managed identity.
- Pin provider and module versions.
- Do not commit `.tfstate`, secret `.tfvars` or saved plans.
- Use PR validation and a reviewed plan.
- Use production approvals.
- Keep reusable modules small and composable.
- Test modules and examples.
- Document inputs, outputs and ownership.

### State segmentation example

```text
platform-management.tfstate
platform-connectivity.tfstate
platform-monitoring.tfstate
app-a-dev.tfstate
app-a-prod.tfstate
```

A single state for the entire organization creates a large blast radius and slow operations.

---

## 13. How do you manage Dev, QA and Production with Terraform?

### Interview answer

I use shared, versioned modules and separate root configurations or state for each environment. The same module version is promoted through Dev, QA and Production, while environment-specific values such as size, count, region and network IDs are passed as variables.

Each environment has:

- Separate state key or backend.
- Separate subscription or approved scope.
- Separate identity/service connection.
- Separate variable values.
- Separate approvals and deployment history.

### Promotion flow

```text
Module change -> Dev plan/apply -> Validation -> QA -> Validation -> Production approval -> Prod apply
```

### Why not copy code manually?

Manual copies diverge. Modules and versioned releases ensure the same tested logic is used everywhere.

---

## 14. How do you protect Terraform state?

### Interview answer

Terraform state can contain resource IDs and sometimes sensitive values, so I treat it as confidential operational data.

Controls include:

- Remote Azure Storage backend.
- Entra ID authentication rather than storage account keys.
- Storage Blob Data roles at minimum required scope.
- Private Endpoint and network restrictions when required.
- Blob versioning, soft delete and recovery controls.
- State locking.
- Separate state files by environment and component.
- No state files in Git.
- Restricted break-glass access.
- Audit logs and alerts.

### Scenario

> Two pipelines attempted to modify the same state. Backend locking prevented concurrent writes. We allowed the active deployment to finish rather than forcing unlock. A force-unlock would be used only after confirming no active process owns the lock.

---

## 15. What is Terraform drift and how do you handle it?

### Answer

Drift is a difference between Terraform configuration/state and the real infrastructure, often caused by portal changes, another automation tool or an external service.

I handle drift by:

1. Running scheduled `terraform plan` or refresh-only checks.
2. Investigating who changed the resource and why.
3. Deciding whether code or the real resource is the approved source.
4. Updating code, importing/moving state, or reverting the manual change.
5. Applying RBAC and process controls to reduce uncontrolled manual changes.

### Scenario

> A Production NSG rule was added manually during an incident. After the incident, the change appeared in the plan. We reviewed whether it was still required, then either added it to Terraform with proper documentation or removed it through an approved apply.

---

## 16. What should a Terraform CI/CD pipeline contain?

### Pull-request pipeline

```text
Checkout
terraform fmt -check
terraform init
terraform validate
TFLint
IaC security scan
terraform plan
Publish plan/report
Peer review
```

### Deployment pipeline

```text
Protected environment approval
Re-initialize trusted backend
Apply reviewed/saved plan where workflow supports it
Post-deployment validation
Publish logs and change evidence
```

### Security controls

- OIDC/workload identity federation.
- Least-privilege service connection.
- Protected branches and environment approvals.
- No secrets in YAML or tfvars.
- Separate plan and apply permissions where required.
- Manual approval for Production.
- Artifact integrity and retention.

### Scenario

> A pull request attempted to open SSH from the internet. tfsec/Trivy configuration scanning blocked the PR before the Terraform plan was approved. The engineer restricted the source range and used Bastion instead.

---

## Official references

- Azure Landing Zones overview: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/
- Landing Zone design areas: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/design-areas
- Terraform module structure: https://developer.hashicorp.com/terraform/language/modules/develop/structure
- Terraform AzureRM backend: https://developer.hashicorp.com/terraform/language/backend/azurerm
- Terraform state: https://developer.hashicorp.com/terraform/language/state
- Terraform plan: https://developer.hashicorp.com/terraform/cli/commands/plan
