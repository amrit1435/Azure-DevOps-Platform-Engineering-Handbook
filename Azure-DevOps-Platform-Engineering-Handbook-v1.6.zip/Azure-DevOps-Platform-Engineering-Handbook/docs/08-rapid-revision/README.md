# 08 - Rapid Revision Cheat Sheet

## Interview response frameworks

### Design question

```text
Requirements -> Assumptions -> Architecture -> Security -> Automation -> Monitoring -> HA/DR -> Cost -> Validation
```

### Troubleshooting question

```text
Confirm impact -> Check recent changes -> Inspect health/logs -> Test connectivity -> Isolate layer -> Fix -> Validate -> Prevent recurrence
```

### Experience question

```text
Situation -> Task -> Action -> Result -> Lesson
```

---

## Azure one-line answers

- **Azure Landing Zone:** governed, scalable Azure foundation covering identity, subscriptions, network, security, monitoring and automation.
- **Management Group:** governance scope above subscriptions.
- **Subscription:** billing, quota and resource-management boundary.
- **RBAC:** who can do what at which scope.
- **Azure Policy:** which configurations are allowed or required.
- **Private Endpoint:** private IP in a VNet for reaching a supported PaaS service.
- **NAT Gateway:** predictable outbound internet access for private subnet resources.
- **Azure Bastion:** browser-based RDP/SSH without direct VM public IP.
- **Application Gateway:** regional Layer 7 load balancer with WAF capability.
- **Front Door:** global HTTP/S entry point, acceleration, WAF and origin routing.
- **Update Manager:** centralized update assessment and scheduling for supported servers.
- **Contributor but Blob denied:** management-plane role does not automatically grant blob data-plane access.
- **Stopped versus deallocated:** deallocation releases VM compute allocation; disks and related services still cost.

---

## Terraform one-line answers

- **State:** maps Terraform resources to real infrastructure and stores metadata.
- **Remote backend:** central state storage with locking and team access control.
- **Module:** reusable Terraform configuration.
- **Root module:** deployable working directory calling resources/modules.
- **Drift:** difference between code/state and actual infrastructure.
- **Plan:** preview of proposed changes; it does not apply them.
- **Import:** bring an existing resource under Terraform state and then align code.
- **`for_each`:** stable keyed instances.
- **`count`:** numeric instances indexed by position.
- **Production rule:** separate state by environment/lifecycle; never commit state or secret tfvars.

---

## DevSecOps one-line answers

- **DevSecOps:** shared, automated security throughout SDLC and runtime.
- **SAST:** scans source/compiled code patterns.
- **SCA:** scans open-source dependencies and licenses.
- **DAST:** tests a running application externally.
- **Secret scan:** detects credentials in source/history.
- **IaC scan:** checks Terraform/Kubernetes/cloud configuration before deployment.
- **Trivy:** scans images, filesystem, secrets and misconfigurations.
- **tfsec:** static Terraform security scanner; `trivy config` is a related modern path.
- **SonarQube:** code quality/security analysis with quality gates.
- **Progressive enforcement:** start with visibility, then gradually block high-risk new findings.
- **False positive:** finding does not apply; “not exploitable” is not automatically false positive.

---

## CI/CD one-line answers

- Build once and promote the same immutable artifact.
- Run validation and security scans in pull requests.
- Use OIDC/workload identity instead of long-lived cloud secrets.
- Separate Production permissions and approvals.
- Store secrets in Key Vault or protected CI secret stores.
- Record commit SHA, artifact digest and deployment ID.
- Add smoke tests, health checks and rollback plan.
- Troubleshoot the first meaningful error, not only the final failed message.

---

## AKS security one-line answers

- Entra ID + RBAC for cluster access.
- Private cluster/API access for sensitive workloads.
- Workload identity instead of pod secrets.
- Key Vault CSI for secret retrieval.
- Network policies and namespace isolation.
- Non-root containers, no privileged mode and resource limits.
- Private ACR, image scanning and admission policy.
- Defender for Containers, audit logs, Prometheus and alerts.
- Planned Kubernetes/node-image upgrades and tested backup.

---

## Common scenario order

### Application Gateway 502

```text
Backend Health -> Probe -> Port/protocol -> DNS -> NSG/UDR -> TLS/hostname -> App logs -> Gateway logs
```

### Private Endpoint resolves public IP

```text
Endpoint approval -> Correct subresource -> Private DNS zone -> A record -> VNet link -> Custom DNS forwarding -> Cache
```

### Pipeline failure

```text
Failed stage -> First real error -> Recent changes -> Variables/secrets -> Auth/RBAC -> Agent -> Network/dependency -> Reproduce
```

### High CPU VM

```text
Azure metrics -> Correlate memory/disk/network -> Recent change -> VM Insights/process -> Right-size/tune -> Alert
```

### Vulnerability blocks build

```text
Review report -> Confirm package/context -> Check fixed version -> Patch/upgrade/remove -> Test -> Rebuild -> Rescan -> Exception only if approved
```

---

## Final interview reminders

- Do not invent hands-on experience.
- State assumptions before designing.
- Mention security, monitoring and rollback in architecture answers.
- Explain why you selected a service, not only what it does.
- Use measurable results only when they are true.
- Keep the first answer around two minutes and wait for follow-up questions.

---

## New TCS Azure DevOps rapid revision

- **Landing Zone components:** Management groups, subscriptions, identity, networking, security, policy, monitoring, operations and automation.
- **After Landing Zone creation:** Validate policy, RBAC, DNS, routes, firewall, monitoring, backup and pipeline in a pilot before onboarding workloads.
- **Application Gateway:** Managed Layer 7 HTTP/HTTPS load balancer with listeners, routing, probes, TLS and optional WAF.
- **Load Balancer types:** Public and Internal; use Standard for modern Production workloads. Gateway Load Balancer is for supported NVA chaining.
- **Storage account types:** Standard GPv2, Premium Block Blob, Premium File Shares and Premium Page Blobs.
- **Terraform plan/apply:** Plan previews; apply executes. In pipelines, apply the reviewed saved plan.
- **provider.tf:** Conventional file for required providers and provider configuration; all `.tf` files are loaded together.
- **Public IP association:** Attached to NIC/frontends/NAT/Firewall/Gateway resources, not directly to a VNet or subnet.
- **Branching strategy:** Defines branch creation, protection, merge and release. Prefer short-lived branches and protected main for frequent CI/CD.
- **CI versus CD:** CI builds/tests and publishes an artifact; CD promotes the artifact through environments.
- **Subnet configuration:** Plan CIDR, create subnet, associate NSG/UDR/NAT/delegation, then validate routes and connectivity.
- **VM application change:** Test, back up, prepare rollback, drain traffic, automate change, validate and monitor.
- **VM no internet:** Check explicit egress, effective NSG/route, firewall, DNS, OS proxy/firewall and remote allowlist.
- **Docker failure order:** Logs, exit code, entrypoint, environment, permissions, ports/network and resource limits.
- **Kubernetes failure order:** Pod events, previous logs, probes, resources, Service endpoints, NetworkPolicy and node health.
- **Terraform failure order:** Protect state, stop concurrent apply, verify identity/backend, correct root cause, re-plan and peer review.
