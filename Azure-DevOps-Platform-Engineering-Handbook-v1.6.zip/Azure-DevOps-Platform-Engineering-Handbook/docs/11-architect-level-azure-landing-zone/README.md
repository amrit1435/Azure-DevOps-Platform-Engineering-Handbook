# Architect-Level Azure Landing Zone: End-to-End Enterprise Design

This chapter answers a single comprehensive architecture question for Azure Cloud Architect, Azure Landing Zone Architect, Principal Cloud Architect and Senior DevSecOps Architect interviews. The language is intentionally simple, but the design is enterprise-grade and suitable for a regulated organization.

> **Interview positioning:** Start with business and regulatory requirements, then explain the target operating model, governance hierarchy, connectivity, identity, security, observability, resilience, Terraform implementation and CI/CD controls. Do not list Azure services without explaining why they exist and how they are governed.

---

## The architect-level question

**Design and explain an enterprise-scale Azure Landing Zone for a regulated enterprise using Terraform. Cover governance, management groups, subscriptions, resource groups, hub-and-spoke networking, identity, security, monitoring, backup, disaster recovery, Git, CI/CD, IaC security scanning, cost optimization and zero-touch production deployment across Development, QA, UAT and Production.**

---

## 1. Two-minute executive interview answer

I would design the platform in two layers: a **platform landing zone** and multiple **application landing zones**. The platform landing zone provides shared identity, connectivity, management and security services. Application landing zones provide governed subscriptions where workload teams deploy Dev, QA, UAT and Production resources.

At the tenant level, I create a management-group hierarchy and assign Azure Policy initiatives, RBAC and compliance controls at the highest appropriate scope. I separate platform subscriptions for Connectivity, Identity, Management and Security, and I use dedicated workload subscriptions for each environment, especially Production, to create clear security, billing and operational boundaries.

For networking, I normally use hub-and-spoke for a regional enterprise and Virtual WAN when there are many regions, branches or large-scale transit requirements. The hub contains Azure Firewall, VPN or ExpressRoute gateway, Bastion, DNS resolver and shared private DNS. Application traffic reaches private workloads through Front Door or Application Gateway WAF, and outbound traffic is controlled through Azure Firewall or NAT Gateway according to the security requirement. PaaS services use Private Endpoints and public network access is disabled wherever possible.

Identity is based on Microsoft Entra ID, least-privilege RBAC, PIM for privileged access, managed identities for Azure workloads and workload identity federation for CI/CD. Secrets are stored in Key Vault; pipelines do not store client secrets.

Terraform is organized into versioned reusable modules. State is stored in a secured Azure Storage backend with locking, encryption, private access, RBAC and separate state per environment. Pull requests run formatting, validation, TFLint, Checkov or tfsec, secret scanning, policy checks, cost estimation and `terraform plan`. Apply is allowed only from a protected branch through an approved pipeline. Production uses approvals, segregation of duties, change evidence, automated smoke tests and rollback or recovery procedures.

Monitoring is centralized through Azure Monitor, Log Analytics, Application Insights, diagnostic settings, Defender for Cloud and Microsoft Sentinel. Backup, ASR and cross-region recovery are designed from workload-specific RTO and RPO. Cost controls use tags, budgets, Advisor, right sizing, reservations or savings plans and Infracost in pull requests.

The result is a repeatable, policy-driven and auditable environment with minimal manual intervention. Zero manual intervention does not mean zero governance; it means all approved changes flow through code, review, automated controls and controlled pipelines.

---

## 2. Requirements and architecture decisions before deployment

Before writing Terraform, I run architecture discovery workshops and document the following:

1. **Business criticality:** Which workloads are critical, important or noncritical?
2. **Regulatory scope:** ISO 27001, PCI DSS, SOC, HIPAA, regional data-residency or internal controls.
3. **Identity model:** Single tenant or exceptional multi-tenant requirement, privileged roles and break-glass access.
4. **Connectivity:** Internet-facing, internal-only, hybrid connectivity, branch connectivity, partner access and DNS ownership.
5. **Data classification:** Public, internal, confidential or restricted data.
6. **Availability objectives:** Required SLA, region strategy, zone strategy, RTO and RPO.
7. **Operating model:** Central platform team, workload teams, security operations and FinOps ownership.
8. **Deployment model:** Azure DevOps or GitHub, approval model, artifact retention and change-management evidence.
9. **Subscription strategy:** Environment isolation, business-unit isolation, quota, billing and regulatory boundaries.
10. **Service selection:** PaaS first where suitable, but based on workload requirements rather than preference alone.

### Key design principle

The landing zone is not the application architecture. It is the governed foundation into which application architectures are deployed. Microsoft describes Azure Landing Zones as a standardized, scalable foundation composed of a platform landing zone and application landing zones.

---

## 3. Target architecture

```mermaid
flowchart TB
    Tenant[Microsoft Entra Tenant]
    Root[Enterprise Root Management Group]
    Platform[Platform Management Group]
    LandingZones[Landing Zones Management Group]
    Sandbox[Sandbox Management Group]
    Decom[Decommissioned Management Group]

    IdentitySub[Identity Subscription]
    ConnSub[Connectivity Subscription]
    MgmtSub[Management Subscription]
    SecSub[Security Subscription]

    Corp[Corp Management Group]
    Online[Online Management Group]
    DevSub[Development Subscription]
    QASub[QA Subscription]
    UATSub[UAT Subscription]
    ProdSub[Production Subscription]

    Tenant --> Root
    Root --> Platform
    Root --> LandingZones
    Root --> Sandbox
    Root --> Decom
    Platform --> IdentitySub
    Platform --> ConnSub
    Platform --> MgmtSub
    Platform --> SecSub
    LandingZones --> Corp
    LandingZones --> Online
    Corp --> DevSub
    Corp --> QASub
    Corp --> UATSub
    Online --> ProdSub
```

### Platform subscriptions

| Subscription | Purpose | Typical resources |
|---|---|---|
| Connectivity | Enterprise transit and shared network services | Azure Firewall, Firewall Policy, VPN/ExpressRoute gateway, Virtual WAN or hub VNet, Bastion, DNS Private Resolver, DDoS plan |
| Identity | Identity infrastructure that must be separated | Domain controllers if required, Entra Domain Services, identity connectors |
| Management | Central operations and observability | Log Analytics, Automation, Update Manager configuration, Monitor workbooks, action groups |
| Security | Security operations and security data | Microsoft Sentinel, security automation, selected Defender integrations |

### Application subscriptions

A regulated workload normally receives separate subscriptions for Development, QA, UAT and Production. Production isolation is especially valuable because it provides:

- Independent access control and privileged groups.
- Separate policy assignments where required.
- Separate quotas and blast radius.
- Clear cost ownership.
- Cleaner incident response and audit evidence.
- Protection from accidental nonproduction changes.

For smaller workloads, Dev and QA can sometimes share a nonproduction subscription, but only after risk, quota and compliance review.

---

## 4. Management groups, subscriptions and resource groups

### Management-group hierarchy

A practical hierarchy is:

```text
Tenant Root Group
└── Contoso
    ├── Platform
    │   ├── Identity
    │   ├── Connectivity
    │   ├── Management
    │   └── Security
    ├── Landing-Zones
    │   ├── Corp
    │   ├── Online
    │   └── Regulated
    ├── Sandbox
    └── Decommissioned
```

- **Corp:** Workloads that require hybrid connectivity or corporate routing.
- **Online:** Internet-facing or cloud-native workloads that do not require corporate network transit for all flows.
- **Regulated:** Optional group for workloads needing an additional policy baseline.
- **Sandbox:** Isolated experimentation with time limits, budgets and less restrictive but still safe controls.
- **Decommissioned:** Subscriptions pending final removal, with deny policies and no new deployments.

Do not create management groups for every department, application, region or environment unless a governance difference genuinely exists. Management groups should represent durable governance boundaries.

### Subscription vending

Subscriptions are created through a controlled subscription-vending pipeline or service catalog. The request contains:

- Workload name and owner.
- Environment.
- Data classification.
- Cost center.
- Region and residency requirement.
- Connectivity model.
- Required policy archetype.
- Required RBAC groups.
- Budget and alert thresholds.

The pipeline creates or configures the subscription, moves it under the correct management group, assigns tags and budgets, creates baseline resource groups, connects it to shared networking and enables diagnostics and Defender plans.

### Resource-group design

Resource groups follow lifecycle, ownership and deployment boundaries rather than simply service type. Example:

```text
rg-payments-prod-network-weu-001
rg-payments-prod-app-weu-001
rg-payments-prod-data-weu-001
rg-payments-prod-monitor-weu-001
```

Resources that are deployed, secured and deleted together can share a resource group. Shared resources with a different lifecycle remain separate.

---

## 5. Governance and compliance controls

### Azure Policy and initiatives

I define a policy hierarchy with three levels:

1. **Enterprise baseline at the organization root**
   - Allowed regions.
   - Required tags.
   - Diagnostic settings.
   - Secure transfer required.
   - TLS minimum version.
   - Deny public access for selected services.
   - Defender for Cloud configuration.

2. **Archetype controls at Corp, Online or Regulated management groups**
   - Corp workloads must use approved DNS and routing.
   - Online workloads require WAF and DDoS controls where applicable.
   - Regulated workloads require private endpoints, customer-managed keys where mandated and stricter logging retention.

3. **Workload-specific controls at subscription or resource-group scope**
   - Approved SKUs.
   - Approved resource types.
   - Additional data-residency or encryption rules.

I group related policy definitions into **policy initiatives** such as `Enterprise-Security-Baseline`, `Regulated-Data-Controls` and `Monitoring-Baseline`. I use `Deny` only after testing through `Audit` or `DeployIfNotExists`, remediation and exemption review.

### Progressive policy enforcement

```text
Audit → Remediate → Deny for new resources → Enforce on existing estate
```

Policy exemptions require an owner, justification, compensating control and expiry date. Permanent unexplained exemptions are not acceptable.

### Resource locks

- `CanNotDelete` locks protect shared production resources, Key Vaults, connectivity components and recovery vaults.
- `ReadOnly` locks are used carefully because they can break operational actions.
- Locks do not replace RBAC, backup or pipeline controls.

### Tags and naming

Mandatory tags normally include:

```text
Application
Environment
Owner
BusinessUnit
CostCenter
DataClassification
Criticality
ManagedBy
ExpiryDate
```

A naming convention should be deterministic but not excessively long:

```text
<resource-type>-<workload>-<environment>-<region>-<instance>
```

Example:

```text
vnet-payments-prod-weu-001
kv-payments-prod-weu-001
law-platform-prod-weu-001
```

### Blueprint strategy

Azure Blueprints is treated as a legacy concept. For new implementations, I use management groups, policy initiatives, RBAC, subscription vending and Terraform or Bicep. Existing Blueprint assignments are assessed and migrated to policy-as-code and IaC.

---

## 6. Identity, privileged access and pipeline authentication

### Microsoft Entra ID

- Use one enterprise tenant unless a legal or sovereignty requirement demands more.
- Create groups for job functions, not direct user assignments.
- Use Conditional Access, MFA and compliant-device requirements.
- Maintain two tightly controlled cloud-only emergency access accounts.
- Review access periodically through access reviews.

### RBAC model

```text
Management Group: platform administrators and policy operators
Subscription: workload owner, security reader, cost-management reader
Resource Group: application or infrastructure team permissions
Resource: exceptional scope only
```

Separate control-plane and data-plane roles. For example, Contributor on a storage account does not automatically provide Blob Data Contributor access.

### Privileged Identity Management

High privilege is eligible, not permanent. PIM activation requires:

- MFA.
- Business justification.
- Approval for sensitive roles.
- Limited activation duration.
- Notification and audit trail.

### Managed identities

Use managed identities for Azure resources such as App Service, Functions, VMs, AKS workloads and automation. The application receives an Azure-managed identity and accesses Key Vault, Storage or databases through RBAC without storing a password.

### Workload identity federation for CI/CD

For Azure DevOps or GitHub Actions, prefer workload identity federation using OIDC:

1. Create an Entra application or user-assigned managed identity.
2. Configure a federated credential that trusts the pipeline issuer, subject and audience.
3. Assign the minimum Azure RBAC role at the required scope.
4. Configure the Azure DevOps service connection or GitHub environment.
5. Pipeline exchanges its OIDC token for an Azure access token.

No long-lived client secret is stored. Production and nonproduction use different identities and scopes.

---

## 7. Enterprise networking architecture

### Hub-and-spoke versus Virtual WAN

Use **hub-and-spoke** when the enterprise has a manageable number of regions and wants detailed control of shared hub services. Use **Virtual WAN** when there are many branches, regions, VPNs, ExpressRoute circuits or large-scale transitive connectivity requirements.

### Regional hub design

The connectivity subscription contains a hub per active region. Typical hub subnets are:

```text
AzureFirewallSubnet
AzureBastionSubnet
GatewaySubnet
RouteServerSubnet, if required
DNS inbound and outbound resolver subnets
Shared services subnet
```

Application subscriptions contain spoke VNets. Peering connects spokes to the regional hub. Spoke-to-spoke traffic is routed through the firewall when inspection is required.

### NSGs, ASGs and UDRs

- **NSGs** control permitted inbound and outbound flows at subnet or NIC level.
- **ASGs** group application tiers logically so NSG rules do not depend on individual IP addresses.
- **UDRs** force traffic through Azure Firewall, NVA or another approved next hop.

Example traffic rule:

```text
Internet → Front Door → Application Gateway WAF → Web tier → API tier → Database private endpoint
```

### Azure Firewall and Firewall Policy

- Centralized ingress, egress and east-west inspection.
- Firewall Policy separates rule collections from the firewall instance.
- Use network rules, application rules, threat intelligence and Premium TLS inspection only where justified.
- Stream firewall logs to Log Analytics and Sentinel.

### Inbound services

- **Azure Front Door:** Global HTTP/S entry, anycast acceleration, global load balancing and edge WAF.
- **Application Gateway WAF:** Regional layer-7 routing, TLS termination, path-based routing and web-application protection.
- **Azure Load Balancer:** Layer-4 TCP/UDP load balancing for private or public workloads.
- **Traffic Manager:** DNS-based global routing when DNS-level endpoint selection is required.

A common enterprise pattern is Front Door Premium globally, private connectivity to regional Application Gateways, and private backends.

### Outbound services

- Use Azure Firewall when centralized inspection, FQDN filtering, threat intelligence and audit are required.
- Use NAT Gateway when a subnet primarily needs scalable, predictable outbound SNAT without full firewall inspection.
- Do not rely on implicit default outbound access for production designs.

### Hybrid connectivity

- **ExpressRoute** for predictable private enterprise connectivity.
- **VPN Gateway** for encrypted Internet-based connectivity, branch backup or smaller sites.
- Use redundant circuits, gateways and diverse paths based on criticality.

### Private connectivity and DNS

For PaaS services:

1. Disable public network access where supported and required.
2. Create Private Endpoints in dedicated subnets.
3. Link the appropriate Private DNS zones to spoke or hub networks.
4. Use Azure DNS Private Resolver for hybrid name resolution.
5. Control DNS forwarding between Azure and on-premises.

Private Link controls the private service exposure model; a Private Endpoint is the network interface with a private address in the consumer VNet.

### DDoS and public IPs

- DDoS Network Protection is associated with protected VNets where risk justifies it.
- Public IPs are minimized, Standard SKU and centrally inventoried.
- Internet-facing applications use WAF and DDoS controls appropriate to their layer.
- Administrative access uses Bastion, JIT access or privileged access workstations rather than direct RDP/SSH exposure.

---

## 8. Workload service-selection guidance

A landing zone supports many services, but an architect selects only those needed by the workload.

### Storage

| Service | Use case | Enterprise controls |
|---|---|---|
| Blob Storage | Object storage, artifacts, logs, backups | Private endpoint, lifecycle management, versioning, soft delete, immutable storage when required |
| Azure Files | SMB/NFS file shares | Identity-based access, private endpoint, backup |
| Queue Storage | Simple asynchronous queue | Managed identity, private access |
| Table Storage | Key-value NoSQL | Private access and data-retention design |
| ADLS Gen2 | Analytics data lake | Hierarchical namespace, ACL and RBAC design, private access |

### Compute

- **VMs:** Legacy or specialized workloads requiring OS control.
- **VM Scale Sets:** Horizontally scaled VM-based workloads.
- **AKS:** Container orchestration requiring Kubernetes capabilities and platform ownership.
- **Container Apps:** Serverless container platform for simpler microservices and event-driven workloads.
- **App Service:** Web applications and APIs with managed platform operations.
- **Function Apps:** Event-driven, short-running or serverless functions.
- **Azure Batch:** Large-scale parallel and high-performance batch workloads.

Availability Zones are preferred for supported production services in a zonal region. Availability Sets are mainly relevant where zones are unavailable or for older VM designs.

### Databases

| Service | Selection guidance |
|---|---|
| Azure SQL Database | Managed relational database for modern applications |
| SQL Managed Instance | High SQL Server compatibility and instance features |
| Azure Database for PostgreSQL | Managed PostgreSQL workloads |
| Azure Database for MySQL | Managed MySQL workloads |
| Cosmos DB | Globally distributed NoSQL with selectable consistency models |
| Azure Managed Redis | Low-latency cache and session/data acceleration |

Database services use private endpoints, Entra authentication where supported, encryption, auditing, backup retention and zone or geo redundancy according to the workload objective.

### Integration

- **Event Grid:** Event notification and reactive integration.
- **Event Hubs:** High-throughput event ingestion and streaming.
- **Service Bus:** Reliable enterprise messaging, queues and topics.
- **Logic Apps:** Managed workflow orchestration and connectors.
- **API Management:** API gateway, authentication, policy enforcement, throttling, versioning and developer portal.

---

## 9. Key Vault, secrets, keys and certificates

- Separate vaults by environment and sensitivity.
- Enable soft delete and purge protection.
- Prefer Azure RBAC over legacy access policies for new designs.
- Use private endpoints and firewall restrictions.
- Applications access secrets with managed identity.
- Certificates have monitored expiry and automated rotation.
- Keys use appropriate rotation and backup procedures.
- Use Managed HSM only when dedicated, highly controlled HSM-backed key management is required.
- Never place secrets in Terraform variables, state outputs, pipeline YAML or Git.

Terraform state can contain sensitive values even when outputs are marked sensitive, so backend access is treated as privileged.

---

## 10. Monitoring, observability and security operations

### Central monitoring design

The Management subscription contains central Log Analytics workspaces or a deliberate multi-workspace design based on residency, access and scale. Every supported resource has diagnostic settings deployed through policy or Terraform.

Collected data includes:

- Azure Activity Logs.
- Resource logs.
- Platform metrics.
- Firewall and WAF logs.
- Key Vault audit logs.
- Identity and sign-in logs where licensed and configured.
- Application telemetry through Application Insights and OpenTelemetry.

### Alerts and action groups

Alerts cover:

- Availability and health probes.
- Error rate and latency.
- CPU, memory, disk and saturation.
- Backup failures.
- Security events.
- Certificate expiry.
- Budget thresholds.
- Policy noncompliance.

Action groups route notifications to operations, incident-management platforms, automation runbooks or ITSM integrations. Alerts must be actionable; noisy alerts are tuned or removed.

### Defender for Cloud and Sentinel

- Defender for Cloud supplies posture management, recommendations, regulatory-compliance views and workload-protection plans.
- Microsoft Sentinel ingests selected security logs, applies analytics rules, creates incidents and drives SOAR playbooks.
- Security ownership and response runbooks are agreed before alerts are enabled.

---

## 11. Backup and disaster recovery

### Business-first design

RTO and RPO come from business impact analysis, not from whichever Azure feature is convenient.

| Tier | Example RTO | Example RPO | Typical design |
|---|---:|---:|---|
| Tier 0 | Minutes | Near zero | Active-active or rapid automated failover, zone and region resilience |
| Tier 1 | Less than 4 hours | Less than 1 hour | Warm secondary region and tested recovery automation |
| Tier 2 | Same business day | Several hours | Backup and restore with documented automation |
| Tier 3 | 24-72 hours | 24 hours | Cost-optimized backup recovery |

### Backup controls

- Recovery Services Vault or Backup Vault according to protected service.
- Vault redundancy selected from business and regulatory requirements.
- Soft delete, immutability and multi-user authorization where supported.
- Separate backup operator permissions.
- Regular restore testing, not only successful backup-job monitoring.

### Cross-region DR

- ASR for supported VM replication and recovery plans.
- Geo-redundant database capabilities for PaaS databases.
- Storage redundancy selected deliberately: ZRS, GZRS or RA-GZRS where appropriate.
- Paired or strategically selected secondary region based on capacity, residency and service availability.
- DNS or Front Door failover.
- Infrastructure recreated through Terraform and immutable artifacts.
- Recovery runbooks tested at least annually, and more frequently for critical systems.

Terraform recreates infrastructure configuration, but it does not replace data backup and replication.

---

## 12. Terraform repository and module architecture

### Recommended repository model

```text
azure-platform/
├── modules/
│   ├── management-groups/
│   ├── policy/
│   ├── subscription-vending/
│   ├── hub-network/
│   ├── spoke-network/
│   ├── firewall/
│   ├── private-dns/
│   ├── monitoring/
│   └── key-vault/
├── live/
│   ├── platform/
│   │   ├── connectivity/
│   │   ├── identity/
│   │   ├── management/
│   │   └── security/
│   └── workloads/
│       └── payments/
│           ├── dev/
│           ├── qa/
│           ├── uat/
│           └── prod/
├── policies/
├── pipelines/
├── tests/
└── docs/
```

For large enterprises, separate repositories can be used for platform modules, platform live configuration, subscription vending and workload repositories. The key requirement is clear ownership and versioned interfaces.

### Module standards

Each child module contains:

```text
main.tf
variables.tf
outputs.tf
versions.tf
README.md
examples/
tests/
```

Modules use typed variables, validation blocks, meaningful outputs and explicit provider requirements. Modules are versioned with immutable Git tags or a private registry.

### Environment separation

I prefer separate state files and normally separate root configurations per environment. Terraform workspaces are useful for genuinely identical short-lived instances, but they are not my primary security boundary for regulated Dev, QA, UAT and Production.

### Variables, locals and nested maps

```hcl
variable "environments" {
  type = map(object({
    subscription_id = string
    location        = string
    address_space   = list(string)
    tags             = map(string)
  }))
}

locals {
  common_tags = {
    ManagedBy = "Terraform"
    Owner     = "CloudPlatform"
  }
}
```

`for_each` is preferred when resources have stable business keys:

```hcl
resource "azurerm_resource_group" "environment" {
  for_each = var.environments

  name     = "rg-${each.key}-platform-${each.value.location}-001"
  location = each.value.location
  tags     = merge(local.common_tags, each.value.tags)
}
```

Dynamic blocks are used only when nested blocks are genuinely optional or repeated; overuse makes code difficult to read.

### Remote backend

```hcl
terraform {
  backend "azurerm" {}
}
```

Backend values are passed during initialization:

```bash
terraform init \
  -backend-config="resource_group_name=rg-tfstate-prod-weu-001" \
  -backend-config="storage_account_name=sttfstateprodweu001" \
  -backend-config="container_name=tfstate" \
  -backend-config="key=platform/connectivity.tfstate" \
  -backend-config="use_azuread_auth=true"
```

Backend controls include:

- Private endpoint and approved network access.
- Entra ID authentication rather than storage keys.
- Least-privilege Blob Data roles.
- Versioning, soft delete and resource lock.
- Separate state keys and, for strict isolation, separate storage accounts or subscriptions.
- No secrets committed in backend configuration.

Azure Blob Storage provides state locking through blob leases during write operations.

### Drift detection

A scheduled pipeline runs:

```bash
terraform init
terraform plan -detailed-exitcode -out=drift.tfplan
```

Exit code `0` means no difference, `2` means changes are present and `1` means an error. Drift creates an alert or pull request for review. The team decides whether to revert the manual change through Terraform or intentionally update code. Production changes are never blindly auto-applied only because drift was detected.

---

## 13. Git strategy and CI/CD workflow

### Branching strategy

For platform IaC, I prefer trunk-based development with short-lived feature branches:

```text
feature branch → pull request → protected main → deployment pipeline
```

GitFlow can be used where release branches are mandatory, but long-lived branches increase merge drift. Branch protection requires:

- Pull request.
- Two reviewers for sensitive platform code.
- Successful automated checks.
- CODEOWNERS approval for network, identity and policy code.
- No direct push to main.
- Signed commits where required.

### Pull-request pipeline

```text
Checkout
→ terraform fmt -check
→ terraform validate
→ TFLint
→ Checkov/tfsec/Terrascan
→ Gitleaks/TruffleHog
→ policy-as-code tests
→ module tests
→ Infracost estimate
→ terraform plan
→ publish plan and evidence
```

The pipeline comments a safe plan summary on the pull request. Sensitive values are redacted.

### Deployment pipeline

```text
Merge to protected main
→ verify commit and artifact
→ plan again in controlled agent context
→ approval/check for target environment
→ terraform apply saved plan
→ post-deployment policy check
→ smoke tests
→ monitoring validation
→ evidence retention
```

Development can deploy automatically after merge. QA and UAT require automated test completion. Production requires an environment approval or change-control gate and segregation of duties.

### Self-hosted agents

Self-hosted agents are used when Terraform must reach private endpoints or internal services. Agents are:

- Ephemeral where possible.
- Placed in a dedicated management subnet.
- Restricted through NSG and firewall rules.
- Patched and monitored.
- Assigned a federated identity with minimum scope.
- Prevented from accepting untrusted public pull-request code.

### Example Azure DevOps Terraform pipeline

```yaml
trigger:
  branches:
    include: [ main ]

pr:
  branches:
    include: [ main ]

stages:
- stage: Validate
  jobs:
  - job: StaticChecks
    pool: platform-private-agents
    steps:
    - checkout: self
    - script: terraform fmt -check -recursive
    - script: terraform init -backend=false
    - script: terraform validate
    - script: tflint --recursive
    - script: checkov -d . --framework terraform
    - script: gitleaks detect --source . --no-git

- stage: Plan
  dependsOn: Validate
  jobs:
  - job: TerraformPlan
    steps:
    - task: AzureCLI@2
      inputs:
        azureSubscription: sc-platform-prod-oidc
        scriptType: bash
        scriptLocation: inlineScript
        inlineScript: |
          terraform init -backend-config=backend-prod.hcl
          terraform plan -out=tfplan
    - publish: tfplan
      artifact: terraform-plan

- stage: Apply_Prod
  dependsOn: Plan
  condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/main'))
  jobs:
  - deployment: Apply
    environment: platform-production
    strategy:
      runOnce:
        deploy:
          steps:
          - download: current
            artifact: terraform-plan
          - task: AzureCLI@2
            inputs:
              azureSubscription: sc-platform-prod-oidc
              scriptType: bash
              scriptLocation: inlineScript
              inlineScript: |
                terraform init -backend-config=backend-prod.hcl
                terraform apply -auto-approve tfplan
```

In a stricter design, the saved plan is cryptographically tied to the source commit, provider lock file and execution environment, and the plan is regenerated after long approval delays.

---

## 14. DevSecOps and infrastructure security scanning

### Security layers

| Layer | Example tools | Purpose |
|---|---|---|
| Formatting and correctness | `terraform fmt`, `terraform validate`, TFLint | Syntax, provider and quality issues |
| IaC misconfiguration | Checkov, tfsec, Terrascan, Trivy IaC | Public access, weak encryption, missing logging and insecure defaults |
| Secrets | Gitleaks, TruffleHog, repository secret protection | Detect credentials and tokens |
| Application SAST | SonarQube or language-native scanners | Code-quality and security issues |
| Dependencies | SCA tools, Dependabot or equivalent | Vulnerable libraries and licenses |
| Container images | Trivy | OS and application-package vulnerabilities, secrets and SBOM |
| Policy as code | Azure Policy, OPA/Conftest, Sentinel where applicable | Enterprise guardrails |
| Compliance | Defender for Cloud and policy initiatives | Continuous control assessment |

### Enforcement model

- Critical and high-confidence violations fail the pipeline immediately.
- High vulnerabilities fail according to exploitability, asset exposure and approved threshold.
- Medium findings begin in report mode and move to enforcement through progressive adoption.
- Suppressions require documented risk acceptance, owner and expiry.
- Scanner availability issues do not silently pass production; the pipeline follows an agreed fail-open or fail-closed policy by environment and risk.

### Example violations

- Storage account permits public blob access.
- Key Vault has public network access and no purge protection.
- NSG permits `0.0.0.0/0` to RDP or SSH.
- SQL database lacks auditing or private access.
- Container runs as root.
- Terraform variable contains a hard-coded secret.

---

## 15. Production deployment, promotion and rollback

### Environment promotion

The same tested module versions and immutable application artifacts are promoted through Dev, QA, UAT and Production. Environment differences are configuration, sizing and policy—not ad hoc code forks.

```text
Dev: automated deployment and developer tests
QA: integration, security and performance tests
UAT: business validation and release approval
Prod: change gate, saved plan, deployment, smoke test and observation window
```

### Zero-touch meaning

Zero-touch means no portal-based routine provisioning and no copy-paste commands. Human governance still exists through pull-request approval, environment checks, PIM activation and change approval. The deployment itself is automated and reproducible.

### Rollback strategy

Terraform is declarative but does not provide a universal transactional rollback. The strategy is:

1. Stop the rollout when validation fails.
2. Preserve logs and the plan.
3. Revert the Git commit or create a corrective commit.
4. Run a new plan and review impact.
5. Apply the approved recovery plan.
6. Restore data from backup if the change affected stateful data.

For application deployments, use deployment slots, blue-green or canary releases and retain the previous immutable artifact. Database changes use backward-compatible migrations and a separately tested recovery strategy.

---

## 16. High availability and scalability

### High availability

- Deploy production across Availability Zones when the service and region support it.
- Use zone-redundant Application Gateway, Firewall, load balancing and databases where supported.
- Maintain at least two healthy application instances.
- Avoid single-instance self-hosted agents for production deployment.
- Use regional redundancy only where business requirements justify the cost and complexity.
- Test dependency failure, not only compute failure.

### Scalability

- Autoscale App Service, VMSS, AKS, Container Apps and supported databases from meaningful metrics.
- Use Front Door and CDN for global and static-content scale.
- Decouple with Service Bus, Event Hubs or Event Grid.
- Cache through Azure Managed Redis where appropriate.
- Load-test before Production and define scale limits and quotas.

Scaling is validated against downstream limits such as database connections, storage throughput, SNAT ports and third-party APIs.

---

## 17. Cost optimization and FinOps

### Preventive controls

- Mandatory cost-center and owner tags.
- Approved SKU policy where appropriate.
- Budgets and alerts at management-group, subscription and resource-group scopes.
- Infracost report in pull requests.
- Auto-shutdown for eligible nonproduction VMs.
- Expiry tags and cleanup automation for sandboxes.

### Continuous optimization

- Review Azure Advisor and Cost Management regularly.
- Right-size VMs, databases and App Service plans from observed utilization.
- Use reservations or savings plans only after stable usage analysis.
- Move infrequently accessed data to cooler storage tiers.
- Remove orphaned disks, NICs, snapshots, public IPs and old backups according to policy.
- Scale nonproduction environments down outside working hours where technically safe.

Cost optimization is balanced with security, reliability and performance. The cheapest architecture is not automatically the best architecture.

---

## 18. Azure Well-Architected Framework mapping

| Pillar | Landing-zone and workload implementation |
|---|---|
| Reliability | Zones, regional DR, backup, tested recovery, health probes, capacity planning |
| Security | Zero Trust, PIM, managed identity, private endpoints, WAF, Firewall, Defender and Sentinel |
| Cost Optimization | Budgets, tags, right sizing, reservations, lifecycle management and Infracost |
| Operational Excellence | IaC, CI/CD, observability, runbooks, safe deployments and incident processes |
| Performance Efficiency | Autoscaling, caching, load testing, service selection and performance telemetry |

The platform team provides the foundation, but each workload must still be reviewed against all five pillars. Landing-zone compliance does not automatically make an application well architected.

---

## 19. Production-readiness checklist

### Governance

- [ ] Subscription is under the correct management group.
- [ ] Policy compliance has no unexplained critical findings.
- [ ] Tags, budget, owners and support model are defined.
- [ ] Resource locks are applied where appropriate.

### Identity and security

- [ ] RBAC follows least privilege and PIM is enabled for privileged roles.
- [ ] Workload identities use managed identity or OIDC.
- [ ] Secrets are in Key Vault and rotation is tested.
- [ ] Public access is disabled unless explicitly required.
- [ ] WAF, firewall, Defender and vulnerability findings are reviewed.

### Reliability

- [ ] Availability-zone and redundancy design is validated.
- [ ] RTO and RPO are approved.
- [ ] Backup and restore tests are successful.
- [ ] DR runbook and failover dependencies are tested.

### Operations

- [ ] Diagnostic settings and dashboards are active.
- [ ] Alerts reach the correct team and are actionable.
- [ ] Support, incident, escalation and on-call processes are defined.
- [ ] Capacity and quota limits are checked.

### Delivery

- [ ] PR controls and security scans pass.
- [ ] Production plan is reviewed and approved.
- [ ] Rollback or recovery procedure is tested.
- [ ] Post-deployment smoke tests and observation period are defined.

---

## 20. Common interviewer follow-up questions

### Why not use one subscription for all environments?

One subscription creates a larger blast radius, mixes access and quotas, complicates policy and cost separation and increases the chance of nonproduction activity affecting Production. Separate subscriptions provide stronger isolation and clearer governance.

### Why not use workspaces for Dev, QA, UAT and Production?

Workspaces separate state but do not create the same security, access, credential and backend isolation as separate root configurations and subscriptions. I use them selectively, not as the main regulated-environment boundary.

### How do you prevent manual changes?

I combine least-privilege RBAC, PIM, policy, resource locks, activity-log alerts, scheduled drift detection and a culture where normal changes happen only through pull requests and pipelines. Emergency changes are documented and reconciled back into code immediately.

### How do you deploy policies without blocking business teams?

I test in a platform canary scope, begin with Audit, assess impact, remediate existing resources, document exemptions and then move selected controls to Deny. Policy changes use the same PR and pipeline process as other code.

### What happens if the Terraform state is lost?

The backend has versioning, soft delete and restricted access. I restore the correct blob version where possible. If required, I rebuild state carefully through import and validation. I never recreate Production blindly without confirming actual resources.

### How do you handle provider or module upgrades?

Use version constraints and commit `.terraform.lock.hcl`. Upgrade in a feature branch, run tests and plan in lower environments, review breaking changes, then promote the same tested version through environments.

### What is the biggest design mistake in a landing zone?

Treating it as a one-time deployment rather than an operating model. A landing zone requires ownership, subscription vending, policy lifecycle, identity governance, monitoring, change control, cost management and continuous improvement.

---

## 21. Final five-minute interview answer structure

Use this order when time is limited:

1. **Requirements:** Regulation, data classification, identity, connectivity, RTO/RPO and operating model.
2. **Organization:** Management groups, platform subscriptions and separate workload environment subscriptions.
3. **Governance:** Policy initiatives, RBAC, PIM, tags, budgets and locks.
4. **Network:** Hub-and-spoke or Virtual WAN, Firewall, WAF, private endpoints, DNS and hybrid connectivity.
5. **Security:** Zero Trust, managed identity, OIDC, Key Vault, Defender and Sentinel.
6. **IaC:** Versioned Terraform modules, secure remote state and separate environment roots.
7. **Pipeline:** PR validation, SAST/IaC/secret/cost scans, plan, approvals and apply.
8. **Operations:** Central monitoring, diagnostic settings, alerts and incident response.
9. **Resilience:** Zones, backup, ASR, cross-region DR and tested RTO/RPO.
10. **Optimization:** Autoscaling, Advisor, budgets, right sizing and continuous compliance.

### Closing statement

My goal is not only to deploy Azure resources. My goal is to create a governed cloud operating platform where every subscription starts secure, every change is traceable, every workload is observable, and Production can be scaled and recovered according to business requirements.

---

## Official references

- Microsoft Cloud Adoption Framework: Azure Landing Zones
- Microsoft Azure Well-Architected Framework
- Azure Landing Zone IaC Accelerator and Azure Verified Modules
- Microsoft Entra workload identity federation
- Azure Policy and management-group guidance
- HashiCorp Terraform language, state and AzureRM backend documentation
