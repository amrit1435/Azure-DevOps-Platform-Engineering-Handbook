# Azure DevOps, Terraform and Production Deployment Interview Round

This chapter contains the questions shared after the latest interview round. The answers are written in simple interview language and include practical project scenarios, troubleshooting steps and follow-up points.

> **Interview positioning:** Present Azure infrastructure, CI/CD, Terraform, PowerShell, Azure CLI, Entra ID and monitoring as hands-on areas. Present advanced AKS or application-development ownership only to the level actually performed.

---

## 1. Introduce yourself and explain your DevOps journey

### Short interview answer

I am an Azure DevOps and cloud infrastructure professional with more than 15 years of overall IT experience. I started my career in infrastructure support, where I worked on servers, networking, virtualization, Active Directory and production operations. Over time, I moved toward automation because I repeatedly saw that manual provisioning and deployment caused delays, configuration differences and avoidable incidents.

I started automating operational tasks with PowerShell, Bash and Azure CLI, then moved into Infrastructure as Code using Terraform and ARM/Bicep. I also began building Azure DevOps pipelines for application and infrastructure deployment. Today, my core focus is Azure infrastructure automation, CI/CD, Git-based delivery, identity and security, monitoring, reliability and controlled production releases.

### Detailed answer

My DevOps journey was a gradual transition rather than a sudden role change:

1. **Infrastructure foundation:** Windows and Linux servers, virtualization, storage, networking, firewalls, backup, monitoring and incident handling.
2. **Cloud adoption:** Azure VMs, VNets, NSGs, storage, load balancers, Application Gateway, Backup, Site Recovery and Azure Monitor.
3. **Automation:** PowerShell, Bash and Azure CLI for repeatable administrative work.
4. **Infrastructure as Code:** Terraform and ARM/Bicep for repeatable Dev, QA and Production environments.
5. **CI/CD:** Azure Repos, Git branching, pull requests, multi-stage Azure DevOps YAML pipelines, approvals and artifacts.
6. **Security and governance:** Entra ID, RBAC, Conditional Access, Key Vault, policy checks and secure service connections.
7. **Operations and reliability:** Log Analytics, Application Insights, dashboards, alerts, rollback planning and root-cause analysis.

### Practical project example

In one Azure automation project, the team was provisioning infrastructure and deploying releases manually. This created inconsistent environments and made rollback difficult. I helped standardize Terraform modules for networking, VMs, storage and load balancing, stored the code in Git, and created Azure DevOps pipelines with validation, plan, approval and deployment stages. This reduced manual effort, improved auditability and made deployments more predictable.

### Likely follow-up questions

- Why did you choose Terraform instead of only portal deployment?
- What percentage of your current work is operations versus DevOps?
- Which parts of the pipeline did you design yourself?
- What production incident taught you the most?

---

## 2. How did you move from infrastructure to DevOps?

### Interview answer

I moved from infrastructure to DevOps by first automating the repetitive work I was already doing. I did not leave infrastructure knowledge behind; I used it as the foundation for DevOps.

Initially, I handled provisioning, patching, monitoring, identity, backup and incident management manually. I then automated common tasks using PowerShell and Azure CLI. After that, I learned Git, Terraform and Azure DevOps pipelines so that infrastructure changes and deployments could be version-controlled, reviewed, tested and released consistently.

### Step-by-step transition

1. Identified repetitive operational tasks.
2. Automated them using scripts.
3. Stored scripts in Git instead of local machines.
4. Introduced pull requests and code review.
5. Converted infrastructure builds into Terraform modules.
6. Added CI checks such as formatting, validation and security scanning.
7. Added CD stages with approvals for higher environments.
8. Added monitoring, deployment verification and rollback procedures.

### Scenario

Earlier, creating a VM required manually selecting the subscription, VNet, subnet, disk, NSG and monitoring options. A small mistake could make QA different from Production. By moving the same configuration into Terraform and executing it through a pipeline, the build became repeatable and reviewable.

### Strong closing statement

My infrastructure background helps me understand what the automation is actually changing. That is useful during troubleshooting because I can investigate both the pipeline layer and the underlying Azure resource layer.

---

## 3. Explain one Azure DevOps CI/CD pipeline from code commit to production deployment

### Interview answer

A developer creates a feature branch, commits code and raises a pull request. The PR triggers validation such as build, unit tests, code quality and security scanning. After approval, the code is merged into the main branch. The main branch pipeline builds a versioned artifact or container image and publishes it. The release stages deploy the same immutable artifact to Dev, QA and Production. Production is protected with approvals, environment checks and post-deployment validation.

### End-to-end flow

1. **Feature development**
   - Developer creates `feature/...` branch.
   - Code is committed and pushed.

2. **Pull-request validation**
   - Restore dependencies.
   - Compile/build application.
   - Run unit tests.
   - Run SonarQube or another SAST tool.
   - Scan dependencies and secrets.
   - Block merge if mandatory quality checks fail.

3. **Merge to main**
   - Branch policy requires reviewers and successful checks.
   - Direct pushes to main are restricted.

4. **Continuous integration**
   - Build application.
   - Generate a unique version using build ID or semantic version.
   - Package files or build a container image.
   - Publish artifact to Azure Artifacts, storage or ACR.

5. **Dev deployment**
   - Download the same artifact.
   - Fetch secrets from Key Vault.
   - Deploy to Dev.
   - Run smoke tests.

6. **QA/UAT deployment**
   - Promote the same artifact, not rebuild it.
   - Run integration, functional and security tests.

7. **Production approval**
   - Change ticket and approver validation.
   - Confirm backup, health, monitoring and rollback plan.

8. **Production deployment**
   - Use rolling, slot, canary or blue-green strategy.
   - Run health checks.
   - Monitor logs, latency, error rate and infrastructure metrics.

9. **Rollback**
   - Redeploy previous successful artifact or swap back deployment slot.

### Simplified YAML structure

```yaml
trigger:
  branches:
    include:
      - main

stages:
- stage: Build
  jobs:
  - job: BuildAndTest
    steps:
    - script: dotnet restore
    - script: dotnet build --configuration Release
    - script: dotnet test --configuration Release
    - task: PublishPipelineArtifact@1
      inputs:
        targetPath: '$(Build.ArtifactStagingDirectory)'
        artifact: 'application'

- stage: Deploy_Dev
  dependsOn: Build
  jobs:
  - deployment: DeployDev
    environment: dev
    strategy:
      runOnce:
        deploy:
          steps:
          - download: current
            artifact: application
          - script: echo "Deploying to Dev"

- stage: Deploy_Prod
  dependsOn: Deploy_Dev
  jobs:
  - deployment: DeployProd
    environment: production
    strategy:
      runOnce:
        deploy:
          steps:
          - download: current
            artifact: application
          - script: echo "Deploying approved artifact to Production"
```

### Key principle

Build once and promote the same artifact across environments. Rebuilding separately for Production can produce a different binary from the one tested in QA.

---

## 4. Production deployment failed. How will you identify build versus release issue, check logs and perform rollback?

### First response during an incident

I first stop further rollout, confirm customer impact and preserve evidence. I do not immediately rerun the pipeline because that can hide the original failure or make the situation worse.

### A. Identify build issue versus release issue

#### Build issue indicators

- Compilation failed.
- Unit tests failed.
- Package restore failed.
- SonarQube quality gate failed.
- Artifact was not published.
- Docker image build failed.
- Incorrect version or missing file in artifact.

#### Release issue indicators

- Build and artifact publication completed successfully.
- Deployment task failed due to authentication or authorization.
- Target service was unavailable.
- Configuration or secret was missing.
- Database migration failed.
- Health probe failed after deployment.
- Network, DNS, firewall or private endpoint blocked connectivity.
- Application starts but returns runtime errors.

### B. Log investigation sequence

1. Open failed Azure DevOps stage, job and task.
2. Check the first meaningful error, not only the final exit-code message.
3. Enable `System.Debug=true` when more pipeline detail is required.
4. Verify service connection and agent connectivity.
5. Compare current deployment variables with the previous successful run.
6. Check artifact version and checksum.
7. Review target-platform logs:
   - App Service log stream and deployment logs.
   - Application Insights failures and traces.
   - Container logs or AKS events.
   - Azure Activity Log.
   - Key Vault audit logs.
   - Database migration logs.
8. Review health probes, dependency connectivity and application configuration.

### C. Rollback strategy

The rollback depends on the deployment target:

- **App Service slots:** swap back to the previous slot.
- **VM deployment:** redeploy the previous artifact or restore application backup/snapshot according to the approved runbook.
- **AKS:** `kubectl rollout undo deployment/<name>` or deploy the previous Helm release.
- **Container image:** point deployment to the last approved immutable image tag or digest.
- **Database:** use backward-compatible migrations; execute a tested rollback only when safe.
- **Terraform:** revert code to the last known good commit, run plan and apply. Do not manually edit the state file.

### Example incident

A pipeline successfully built version `2.4.8`, but Production returned HTTP 500 after deployment. The release task itself was green, so this was not a build failure. Application Insights showed that a new environment variable was missing. Because traffic impact was active, the deployment slot was swapped back first. The variable was then added through the approved configuration process, tested in staging and redeployed.

### Interview point

Restore service first, then complete root-cause analysis. During a live outage, rollback is often safer than debugging directly in Production for a long time.

---

## 5. Explain one infrastructure pipeline using Azure DevOps and Terraform

### Interview answer

I separate Terraform CI from Terraform CD. CI validates the code and generates a reviewed plan. CD applies the approved plan to the correct environment using a secure Azure service connection and remote state.

### Recommended stages

1. **Checkout**
2. **Terraform format check**
3. **Terraform initialization**
4. **Terraform validate**
5. **Security scan** such as tfsec or Checkov
6. **Terraform plan**
7. **Publish plan artifact**
8. **Manual approval for Production**
9. **Terraform apply using the saved plan**
10. **Post-deployment validation**

### Sample pipeline

```yaml
trigger:
  branches:
    include:
      - main
  paths:
    include:
      - terraform/*

variables:
  workingDirectory: terraform/environments/dev

stages:
- stage: ValidateAndPlan
  jobs:
  - job: TerraformPlan
    pool:
      vmImage: ubuntu-latest
    steps:
    - checkout: self

    - script: terraform fmt -check -recursive
      workingDirectory: $(workingDirectory)
      displayName: Terraform format check

    - script: terraform init -input=false
      workingDirectory: $(workingDirectory)
      displayName: Terraform init

    - script: terraform validate
      workingDirectory: $(workingDirectory)
      displayName: Terraform validate

    - script: terraform plan -input=false -out=tfplan
      workingDirectory: $(workingDirectory)
      displayName: Terraform plan

    - task: PublishPipelineArtifact@1
      inputs:
        targetPath: '$(workingDirectory)/tfplan'
        artifact: terraform-plan

- stage: Apply
  dependsOn: ValidateAndPlan
  jobs:
  - deployment: TerraformApply
    environment: infrastructure-dev
    strategy:
      runOnce:
        deploy:
          steps:
          - download: current
            artifact: terraform-plan
          - script: terraform init -input=false
            workingDirectory: $(workingDirectory)
          - script: terraform apply -input=false tfplan
            workingDirectory: $(workingDirectory)
```

### Production controls

- Remote state in a protected Azure Storage Account.
- State locking enabled through the backend.
- Separate state per environment.
- Workload identity federation or tightly protected service principal.
- Pull-request approval.
- Production environment approval.
- No secrets stored in Git or plain pipeline YAML.
- Apply the reviewed saved plan.
- Restricted permissions following least privilege.

### Scenario

A change request adds a subnet. The PR pipeline validates syntax, checks policy and produces a plan showing one subnet creation and no destructive changes. After review and Production approval, the exact saved plan is applied. Post-deployment checks verify address range, NSG association and route table association.

---

## 6. Explain Service Connection

### Interview answer

A service connection is the secure, managed connection that allows Azure DevOps pipelines to authenticate to an external platform such as Azure, Kubernetes, Docker registry, GitHub or another service.

For Azure, it normally represents an Azure Resource Manager connection backed by workload identity federation, a service principal or managed identity. The pipeline uses it to perform authorized actions without placing user credentials directly in YAML.

### Important components

- Authentication identity.
- Target tenant and subscription.
- Authorization scope, such as subscription or resource group.
- RBAC role assigned to the identity.
- Pipeline permissions controlling which pipelines may use it.

### Recommended approach

Use workload identity federation where supported because it avoids long-lived client secrets. Scope the connection only to the resources required and do not select “Grant access permission to all pipelines” unless there is a justified requirement.

### Scenario

A Terraform pipeline requires permission to create resources only in the Dev resource group. Instead of giving Owner at subscription level, create a federated service connection and grant the identity Contributor on the Dev resource group plus only the additional permissions required for state access.

### Common errors

- Expired client secret.
- Wrong tenant or subscription.
- Missing RBAC assignment.
- Role assigned at the wrong scope.
- Pipeline is not authorized to use the connection.
- Federated credential subject does not match the pipeline configuration.

---

## 7. Managed Identity versus Service Principal

| Area | Managed Identity | Service Principal |
|---|---|---|
| Purpose | Identity for an Azure resource | Application identity in Entra ID |
| Credential management | Azure manages credentials | Secret, certificate or federation must be configured |
| Secret rotation | No manual secret rotation | Required when using secrets/certificates |
| Where it works | Azure-hosted resources that support it | Azure, external systems and broader automation scenarios |
| Lifecycle | Often tied to Azure resource | Independent application identity |
| Best use | Azure resource accessing another Azure service | CI/CD, external automation, multi-platform integration |

### Interview answer

I prefer managed identity when an Azure resource, such as a VM, Function, App Service or Automation Account, needs to access Key Vault, Storage or another Azure service. It removes stored credentials.

For Azure DevOps pipelines, workload identity federation through a service connection is generally preferred. A traditional service principal with a secret is used only when federation or managed identity is not practical.

### System-assigned versus user-assigned managed identity

- **System-assigned:** lifecycle is tied to one Azure resource.
- **User-assigned:** separate Azure resource that can be attached to multiple supported resources.

### Scenario

An App Service needs to read a database password from Key Vault. Enable managed identity on the App Service and grant it the minimum Key Vault role. No secret is stored in application settings.

---

## 8. Azure-hosted agent versus self-hosted agent

| Area | Microsoft-hosted agent | Self-hosted agent |
|---|---|---|
| Management | Microsoft manages VM and image | Organization manages server, tools and security |
| Environment | Fresh environment for each job | Persistent machine unless rebuilt |
| Network access | Public connectivity by default | Can be placed inside private network |
| Custom software | Install during job or use available image | Preinstall and control exact versions |
| Maintenance | Low | Patching, scaling and monitoring required |
| Security responsibility | Shared, with ephemeral job machine | Much greater customer responsibility |
| Typical use | Standard public builds | Private endpoints, internal servers, special tools or compliance needs |

### When to use self-hosted

- Deployment target is reachable only through a private network.
- Pipeline must access private endpoints or on-premises systems.
- Large dependencies make repeated downloads inefficient.
- Special licensed software or hardware is required.
- Organization needs controlled base images and egress.

### Self-hosted agent precautions

- Use a dedicated agent identity.
- Patch OS and tools regularly.
- Do not run agents on domain controllers or critical application servers.
- Restrict outbound and inbound network access.
- Avoid sharing one agent across mutually untrusted projects.
- Clean workspaces and protect credentials.
- Monitor capacity and agent health.

### Scenario

A Terraform pipeline must reach a storage account and Key Vault through private endpoints. A Microsoft-hosted agent cannot resolve or route to those private addresses. A self-hosted agent is placed in an approved subnet with private DNS and required outbound access.

---

## 9. A developer manually changes an Azure resource after Terraform deployment. How do you detect Terraform drift?

### Interview answer

Terraform drift means the real infrastructure no longer matches the Terraform configuration and state. To detect it, I run a refresh-aware `terraform plan`. Terraform reads the current remote resource values, compares them with state and configuration, and shows the proposed action required to return to the desired configuration.

### Commands

```bash
terraform init
terraform plan
```

For a detection-only pipeline, a refresh-only plan can be useful:

```bash
terraform plan -refresh-only
```

To use exit codes in automation:

```bash
terraform plan -detailed-exitcode
```

Typical meanings:

- `0`: no difference.
- `1`: error.
- `2`: changes are present.

### Scenario

Terraform configured an NSG rule allowing HTTPS from a corporate CIDR. A developer manually changed the source to `*`. The scheduled drift pipeline runs `terraform plan -detailed-exitcode`, detects a difference and sends an alert. The team confirms the manual change was unauthorized and applies the approved Terraform configuration to restore the secure rule.

### Prevention

- Restrict portal write access.
- Use PIM for temporary elevation.
- Apply Azure Policy.
- Require all changes through Git and pipeline.
- Run scheduled drift detection.
- Review Azure Activity Logs.

---

## 10. Explain Terraform state file

### Interview answer

The Terraform state file is Terraform’s record of the infrastructure it manages. It maps Terraform resource addresses in the code to actual resource IDs in the provider platform and stores relevant attributes and dependency information.

Without state, Terraform would not reliably know which existing resource corresponds to each resource block.

### What state contains

- Resource addresses.
- Provider resource IDs.
- Resource attributes.
- Dependency information.
- Outputs.
- Metadata required by Terraform.

### Security warning

State can contain sensitive values even when an output is marked sensitive. Therefore, state should be stored in a protected remote backend, encrypted, access-controlled and never committed to Git.

### Azure backend example

```hcl
terraform {
  backend "azurerm" {
    resource_group_name  = "rg-tfstate-prod"
    storage_account_name = "sttfstateprod001"
    container_name       = "tfstate"
    key                  = "network/prod.tfstate"
  }
}
```

### Best practices

- Remote backend instead of local state.
- Separate state by environment and logical boundary.
- Enable storage protection, versioning and recovery features.
- Restrict network and RBAC access.
- Never edit state JSON manually.
- Use `terraform state` commands only with backup and peer review.

---

## 11. Explain Terraform refresh

### Interview answer

Refresh is the process in which Terraform reads the current values of managed remote objects and updates its understanding of their real condition before comparing them with configuration.

Modern `terraform plan` and `terraform apply` normally perform refresh automatically. The standalone `terraform refresh` command exists but is generally not the preferred routine workflow because it directly updates state without first presenting the complete proposed effect in the same way as a reviewed plan.

### Safer refresh-only workflow

```bash
terraform plan -refresh-only
terraform apply -refresh-only
```

### Scenario

An Azure platform updates a computed property on a resource. A refresh-only plan shows the external change without proposing to modify the configured infrastructure. The team reviews the result before deciding whether to update state or code.

### Important distinction

Refresh updates Terraform’s knowledge of remote objects. It does not automatically make configuration match the real environment. The following normal plan determines whether the desired configuration requires corrective action.

---

## 12. How does Terraform plan detect deleted resources?

### Interview answer

During planning, Terraform refreshes managed objects through the provider API. If the state says a resource exists but the provider reports that it no longer exists, Terraform marks it as missing. If the resource block is still present in configuration, the plan normally proposes to create it again.

### Example

State contains:

```text
azurerm_subnet.application
```

Someone deletes that subnet manually. On the next plan, the AzureRM provider cannot find the subnet by its resource ID. Because the subnet still exists in Terraform code, the plan shows a create action.

### Important exception

Terraform may fail before recreation when other dependencies, names, locks or platform constraints prevent the resource from being created. The plan output must be reviewed instead of assuming every deleted resource will be restored automatically.

---

## 13. How do you restore deleted resources?

### Interview answer

If Terraform manages the resource and the configuration is still correct, I first run `terraform plan` and confirm that Terraform proposes to recreate only the expected resource and related dependencies. After approval, I run `terraform apply` using the reviewed plan.

### Procedure

1. Confirm who deleted the resource and whether deletion was intentional.
2. Check impact and dependencies.
3. Review Azure Activity Log.
4. Run Terraform plan.
5. Review destructive and replacement actions carefully.
6. Restore data separately if the resource contains data.
7. Apply the approved plan.
8. Validate configuration, connectivity and monitoring.

### Resource versus data restoration

Terraform can recreate resource configuration, but it may not restore deleted business data. Examples:

- A storage account can be recreated, but deleted blobs may require soft delete, versioning or backup.
- A database server can be recreated, but data requires backup or point-in-time restore.
- A Key Vault can be recovered only according to its recovery and purge-protection state.

### Scenario

A VM is deleted manually. Terraform can recreate the VM, NIC and required associations if code still defines them. However, restoring the original application data depends on managed-disk backup, snapshot or Azure Backup. Infrastructure code alone is not a data-protection solution.

---

## 14. What is zero-drift state or equilibrium state?

### Interview answer

Zero drift or equilibrium means three views are aligned:

1. Terraform configuration represents the approved desired state.
2. Terraform state correctly maps the managed resources.
3. The actual infrastructure matches that configuration.

In this condition, `terraform plan` shows no changes.

### Important clarification

Zero drift does not mean the environment will never change. It means all approved changes are represented in code and applied through the controlled workflow, while unauthorized differences are corrected or formally adopted into code.

### Scenario

A scheduled plan returns exit code `0` for Dev, QA and Production. This indicates no detected difference at that point in time. The team still maintains monitoring, policy and activity-log review because drift can occur after the check.

---

## 15. How do multiple engineers work on the same Terraform project?

### Interview answer

Multiple engineers collaborate through Git, pull requests, modular code, remote state and state locking. Engineers do not apply independently from personal copies against the same Production state.

### Recommended workflow

1. Pull latest main branch.
2. Create a short-lived feature branch.
3. Make a small, focused change.
4. Run `fmt`, `validate`, security checks and local or pipeline plan.
5. Raise a pull request.
6. Review code and plan output.
7. Merge after approval.
8. Central pipeline applies to the target environment.

### Design practices

- Separate state by environment and component to reduce contention and blast radius.
- Use reusable modules with controlled versions.
- Protect main branch.
- Do not store `.tfstate` or secrets in Git.
- Allow only the deployment pipeline to apply to Production.
- Use state locking.
- Avoid long-running branches that create merge conflicts.

### Scenario

Engineer A adds a subnet while Engineer B changes an NSG. If both use one large state and apply manually at the same time, they may block each other or apply stale plans. With pull requests and a single controlled apply pipeline, changes are serialized and reviewed.

---

## 16. Explain state locking

### Interview answer

State locking prevents two Terraform write operations from changing the same state at the same time. Without locking, concurrent applies could overwrite each other or produce inconsistent state.

### How it works

When Terraform begins an operation that can write state, the backend attempts to acquire a lock. A second operation must wait or fail until the first operation releases it.

### Common lock scenario

A pipeline is cancelled while applying, leaving a lock record. Before force-unlocking, I verify that no Terraform operation is still running. Then I use the lock ID shown in the error:

```bash
terraform force-unlock <LOCK_ID>
```

### Safety rule

Never force-unlock only because the pipeline is taking time. First check active pipelines, agents and cloud activity. Removing a valid lock while another apply is running can corrupt operational consistency.

### Additional control

State locking does not replace branch controls or approvals. It protects concurrent state writes, but it cannot decide whether a change is correct.

---

## 17. Explain an application CI/CD pipeline

### Interview answer

An application CI/CD pipeline automates code validation, build, packaging, security checks and deployment. CI proves that the code can be integrated safely. CD promotes a tested, immutable artifact through environments using approvals and deployment controls.

### Typical CI stages

- Checkout.
- Dependency restore.
- Compile.
- Unit tests.
- Code coverage.
- SAST and quality gate.
- Dependency and secret scanning.
- Package or container build.
- Image scan where applicable.
- Publish immutable artifact.

### Typical CD stages

- Deploy to Dev.
- Smoke test.
- Deploy to QA.
- Integration and functional testing.
- UAT approval.
- Production approval.
- Rolling, canary, slot or blue-green deployment.
- Post-deployment verification.
- Rollback when health criteria fail.

### Environment configuration

The binary remains the same, while environment-specific configuration is supplied securely through variables, Key Vault, managed identity and platform configuration.

---

## 18. A developer pushes code to Git. Explain every step until Production

### Complete interview flow

1. Developer updates local branch from main.
2. Creates a feature branch.
3. Makes code changes and local tests.
4. Commits with a meaningful message.
5. Pushes branch to Azure Repos or GitHub.
6. Raises pull request.
7. PR pipeline starts automatically.
8. Build, unit tests, code quality and security checks run.
9. Reviewers inspect code and pipeline results.
10. Required comments are resolved.
11. PR is merged into main.
12. Main CI pipeline builds a versioned artifact once.
13. Artifact is stored in an artifact repository or ACR.
14. CD deploys the artifact to Dev.
15. Smoke tests verify the deployment.
16. Same artifact is promoted to QA/UAT.
17. Integration, performance or business testing runs.
18. Production change approval is obtained.
19. Backup, rollback, monitoring and deployment window are confirmed.
20. Same approved artifact is deployed using a safe strategy.
21. Health checks and telemetry are monitored.
22. Release is marked successful or rolled back.
23. Deployment evidence and release notes are retained.

### Interview emphasis

- Branch policy prevents unreviewed code from reaching main.
- Artifact is built once.
- Secrets are not stored in the repository.
- Production has explicit controls.
- Monitoring and rollback are part of deployment, not an afterthought.

---

## 19. Which Azure PaaS services have you worked on?

### Safe resume-aligned answer

My strongest hands-on work is in Azure infrastructure and automation. In the PaaS area, I have worked with or supported services such as Azure Storage, Key Vault, Azure Monitor, Log Analytics and Application Insights. For application hosting, I understand and have practiced deployment patterns using Azure App Service and related services such as deployment slots, autoscaling, managed identity and Key Vault integration.

I also understand Azure SQL Database, Azure Database for PostgreSQL, Event Hubs, Service Bus, Functions and Container Apps from an architecture and pipeline-integration perspective. I clearly distinguish services I have operated directly from those I have learned through labs or supported jointly with application teams.

### Better interview structure

Group the answer instead of listing random names:

- **Application hosting:** App Service, Functions, Container Apps.
- **Data:** Azure SQL Database, PostgreSQL, Storage.
- **Integration:** Event Hubs, Service Bus.
- **Security:** Key Vault, managed identity.
- **Observability:** Azure Monitor, Log Analytics, Application Insights.

### Honesty rule

Do not claim deep Production ownership of a service only because it appeared in an architecture diagram. Explain your exact responsibility: provisioning, pipeline deployment, access, networking, monitoring or application configuration.

---

## 20. Explain one project where you deployed an application using Azure PaaS

### Interview-ready example

In a practical Azure PaaS deployment pattern, the application was hosted on Azure App Service. Source code was stored in Git and Azure DevOps handled CI/CD.

The CI stage restored dependencies, ran tests, performed code-quality checks, packaged the application and published a versioned artifact. The CD stage deployed the artifact to a staging slot in App Service. Configuration values were supplied through App Service settings, while secrets were read from Key Vault using managed identity. Application Insights and Log Analytics collected telemetry.

After deployment, the pipeline ran smoke tests against the staging slot. Once health checks passed and approval was completed, the staging slot was swapped into Production. If errors increased, the team could swap back quickly.

### Architecture

```text
Developer -> Git -> Azure DevOps CI -> Artifact
                                  |
                                  v
                         App Service staging slot
                                  |
                         Smoke test and approval
                                  |
                                  v
                         Swap to Production slot

Key Vault -> Managed Identity -> App Service
Application Insights <- Telemetry <- Application
```

### Infrastructure elements

- App Service Plan.
- Web App.
- Staging and Production slots.
- Key Vault.
- Managed identity.
- Application Insights.
- Private endpoint or network integration where required.
- Azure DevOps service connection.

### Key benefits

- No server patching for the application team.
- Built-in scaling and health features.
- Fast rollback through slot swap.
- Secure secret access.
- Integrated monitoring.

---

## 21. Application load becomes 10x. Which Azure PaaS service will you scale?

### Interview answer

I would not choose a service only from the phrase “10x load.” I first identify which tier is saturated: web tier, API, background processing, messaging, database or cache. Then I scale the relevant bottleneck and validate dependent limits.

### Examples

- **Azure App Service:** scale out instances or scale up the App Service Plan; configure autoscale.
- **Azure Functions:** use an appropriate hosting plan and validate concurrency, downstream limits and cold-start requirements.
- **Container Apps:** increase replicas and configure event- or HTTP-based scaling.
- **Azure SQL Database:** increase compute tier, use elastic pools where suitable, optimize queries and consider read scale patterns.
- **Cosmos DB:** increase or autoscale throughput and verify partition-key design.
- **Service Bus/Event Hubs:** increase messaging capacity or throughput units and scale consumers.
- **Redis:** scale tier/capacity if cache is the bottleneck.

### Investigation metrics

- CPU and memory.
- Requests per second.
- Response time and failure rate.
- Queue depth.
- Database DTU/vCore, connections, locks and query duration.
- Dependency latency.
- Throttling responses.

### Scenario

Traffic to an App Service API increases tenfold. CPU reaches 90%, request latency rises and the database remains below 40%. I configure scale-out based on CPU or HTTP queue, verify the App Service Plan supports the required instance count, and perform load testing. I also confirm that database connections, downstream APIs and rate limits can support the additional instances.

### Strong point

Autoscaling the front end alone can transfer the bottleneck to the database or another dependency. Scaling must be end-to-end.

---

## 22. How will you achieve high availability?

### Interview answer

High availability is achieved by removing single points of failure across compute, networking, data, identity, deployment and operations. The exact design depends on required availability, recovery objectives, application state and budget.

### Core design areas

#### Compute

- Run multiple instances.
- Use availability zones where supported.
- Configure autoscaling.
- Use health probes and automatic replacement.

#### Traffic management

- Application Gateway or Load Balancer distributes regional traffic.
- Front Door or Traffic Manager can provide multi-region routing.
- Health probes remove unhealthy endpoints.

#### Application

- Keep application tier stateless where possible.
- Store sessions externally.
- Use retry, timeout, circuit-breaker and graceful-degradation patterns.

#### Data

- Use zone-redundant or geo-redundant options where supported.
- Configure database high availability, backups and point-in-time restore.
- Test restore procedures.

#### Networking

- Avoid one firewall, DNS dependency or gateway becoming the only path.
- Use zone-redundant SKUs where available.
- Design private DNS and connectivity with redundancy.

#### Deployment

- Use rolling, blue-green, canary or deployment slots.
- Keep previous artifact available.
- Automate health validation and rollback.

#### Monitoring and operations

- Monitor availability, latency, errors, saturation and dependencies.
- Configure actionable alerts.
- Maintain runbooks and incident ownership.
- Test failover instead of only documenting it.

### Example Azure PaaS design

```text
Users
  |
Azure Front Door + WAF
  |-----------------------------|
  v                             v
Region A                      Region B
App Service instances         App Service instances
  |                             |
  |------- Data replication ----|

Key Vault, monitoring, backup and automated deployment support both regions.
```

### Difference between HA and DR

- **High availability:** keeps the service running during local component failures, usually with minimal interruption.
- **Disaster recovery:** restores or fails over service after a major regional or site-level event.

### Interview scenario

For a critical web application, I use Front Door with health-based routing across two regions, multiple App Service instances per region, zone-capable services where available, a database with an appropriate replication/failover design, Key Vault and monitoring. CI/CD deploys the same version to both regions using controlled rollout. Failover is tested periodically against agreed RTO and RPO.

---

# Rapid Revision

1. **Journey:** infrastructure -> scripting -> Git -> Terraform -> CI/CD -> security and reliability.
2. **Build versus release:** build creates and validates artifact; release deploys it to target environment.
3. **Rollback:** restore service first using previous immutable artifact, slot swap or platform rollback.
4. **Infrastructure pipeline:** fmt -> init -> validate -> scan -> plan -> approval -> apply -> verify.
5. **Service connection:** secure pipeline identity and authorization to external service.
6. **Managed identity:** Azure-managed credential for Azure resources.
7. **Hosted agent:** easy and ephemeral; self-hosted agent is needed for private access or custom control.
8. **Drift:** real resource differs from code/state; detect with plan and scheduled checks.
9. **State:** mapping between Terraform addresses and real resources; protect it like sensitive data.
10. **Refresh:** read current remote values; plan normally performs it automatically.
11. **Deleted resource:** provider reports missing; plan proposes recreation when code still requires it.
12. **Zero drift:** code, state and actual infrastructure agree; plan shows no changes.
13. **Teamwork:** Git PRs, remote state, locking, modular boundaries and centralized apply.
14. **PaaS scaling:** identify the bottleneck before scaling.
15. **HA:** redundancy, health-based routing, resilient data, safe deployment, monitoring and tested failover.
