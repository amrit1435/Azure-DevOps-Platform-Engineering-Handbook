# 02 - Azure Administrator and Networking Interview Questions

---

## 1. Management has mandated removing all public IPs. How do you maintain access and outbound traffic?

### Short interview answer

I would remove public IPs from workload resources and separate **inbound administration**, **application publishing** and **outbound internet access**.

- Administration: Azure Bastion, VPN or ExpressRoute.
- Application inbound: Application Gateway, Front Door or internal load balancer, depending on the requirement.
- Outbound: NAT Gateway for predictable outbound SNAT, or Azure Firewall when inspection and policy control are required.
- PaaS access: Private Endpoints and private DNS.

### Detailed answer

First, I would identify why each public IP exists. A VM public IP used for RDP/SSH should be removed and replaced by Azure Bastion or private corporate connectivity. A public application should normally be exposed through a controlled entry point such as Application Gateway with WAF or Azure Front Door rather than a public IP directly on a VM.

For private VMs that still need to download patches or call external APIs, I would attach a NAT Gateway to the subnet. NAT Gateway gives outbound-only connectivity through one or more controlled public IPs or a public IP prefix. It does not open inbound access to the VMs.

When the organization needs URL filtering, TLS inspection, central network rules or detailed egress logging, Azure Firewall is normally a better fit than NAT Gateway. In some designs, traffic is routed through Azure Firewall and NAT behavior is handled as part of the egress architecture.

For Azure Storage, SQL, Key Vault and similar services, I would use Private Endpoints and disable public network access after validating DNS and application connectivity.

### Scenario

> Ten application VMs had direct public IPs for administration and outbound package downloads. We removed the VM public IPs, enabled Bastion for administration, added NAT Gateway to the application subnet for outbound traffic, and used Azure Policy to deny new public IP creation except in an approved shared-services scope.

### Validation

- Confirm the VM NIC has no public IP.
- Test RDP/SSH through Bastion or VPN.
- Use `curl ifconfig.me` or an approved external endpoint to confirm the expected egress IP.
- Verify UDR, NSG and firewall logs.
- Test Private Endpoint DNS before disabling public access.

---

## 2. A Storage Account has a Private Endpoint, but the VM resolves the public IP. What may be wrong?

### Short interview answer

The most likely problem is private DNS. The private DNS zone may be missing, not linked to the VM's VNet, missing the A record, or custom DNS may not be forwarding the private-link zone correctly.

### Detailed troubleshooting order

1. Confirm the private endpoint is approved and has a private IP.
2. Confirm the correct subresource was created, such as `blob`, `file`, `queue` or `dfs`.
3. Check the required zone. For Blob it is normally:

```text
privatelink.blob.core.windows.net
```

4. Confirm the zone has an A record for the storage account.
5. Confirm the VM's VNet is linked to the private DNS zone.
6. Check whether the VNet uses Azure-provided DNS or a custom DNS server.
7. If custom DNS is used, configure forwarding or conditional forwarding for the private-link zone to Azure DNS Private Resolver or the correct Azure DNS path.
8. Clear local DNS cache and retest.

### Commands

Linux:

```bash
nslookup mystorage.blob.core.windows.net
getent hosts mystorage.blob.core.windows.net
```

Windows:

```powershell
Resolve-DnsName mystorage.blob.core.windows.net
ipconfig /flushdns
```

### Scenario

> The private endpoint and A record existed, but the private DNS zone was linked only to the hub VNet. The VM was in a spoke VNet and DNS forwarding was not configured. After linking the spoke or implementing central DNS forwarding, the normal storage FQDN resolved to the private endpoint IP.

### Common mistake

Applications should normally continue using the standard storage endpoint such as `mystorage.blob.core.windows.net`. Do not hard-code the `privatelink` hostname in application configuration.

---

## 3. Application Gateway returns 502. How do you troubleshoot it?

### Short interview answer

I start with **Backend Health**. A 502 usually means the gateway could not get a valid response from the backend. I check the probe, backend address, port, protocol, hostname, NSG, UDR, DNS, TLS certificate and application health.

### Step-by-step method

1. Open Application Gateway **Backend health**.
2. Identify whether every backend is unhealthy or only one instance.
3. Review the probe status and message.
4. Confirm backend pool IP/FQDN.
5. Confirm backend setting protocol and port.
6. Confirm probe path, host header, timeout and accepted status codes.
7. Test the backend directly from a VM in a network with similar reachability.
8. Review effective NSG and routes on the backend NIC.
9. Check custom DNS resolution.
10. For end-to-end TLS, verify certificate chain, expiry, SNI and hostname match.
11. Review Application Gateway access, firewall and performance logs.
12. Review backend application logs.

### Useful tests

```bash
curl -vk https://backend.example.internal/health
nc -vz backend.example.internal 443
```

### Scenario

> The application responded correctly on `/health`, but the gateway probe used `/`, which returned 401. The backends were therefore marked unhealthy. We changed the probe to `/health`, configured the expected host header and validated a 200 response.

### Common causes

- Empty or incorrect backend pool.
- Application not listening on the configured port.
- NSG or UDR blocks traffic.
- DNS resolves to the wrong address.
- Probe path requires authentication.
- TLS certificate does not match the backend hostname.
- Request timeout is too low.
- Backend process is down or overloaded.

---

## 4. Walk me through configuring Azure Front Door for a web application

### Interview answer

I would configure Azure Front Door in the following order:

1. Select Standard or Premium based on WAF, Private Link and security requirements.
2. Create a Front Door profile and endpoint.
3. Create an origin group.
4. Add one or more origins, such as App Service, Application Gateway or another web endpoint.
5. Configure health probes and load-balancing settings.
6. Create a route that maps domain, protocol and path patterns to the origin group.
7. Configure forwarding protocol and origin host-header behavior.
8. Add a custom domain and validate DNS ownership.
9. Enable managed TLS.
10. Attach a WAF policy.
11. Add caching and rule sets only where appropriate.
12. Enable diagnostic logs, metrics and alerts.
13. Test health, failover, redirects and custom-domain behavior.

### Scenario

> A customer-facing web application ran in two Azure regions. Front Door used both regional Application Gateways as origins. Health probes detected a regional failure and routed users to the healthy region. WAF protected the public endpoint, while the origins accepted traffic only from the approved Front Door path.

### Important checks

- Origin certificate must match the origin hostname.
- Health probe path must be lightweight and unauthenticated.
- Cache only safe, cacheable content.
- Do not expose a private origin publicly when a supported private origin design is required.
- Set WAF initially in detection mode, tune false positives, then move to prevention mode.

---

## 5. When would you use a NAT Gateway and what is it used for?

### Short answer

NAT Gateway is used when private resources need reliable outbound internet access through predictable public IP addresses without receiving inbound internet access.

### Typical use cases

- Private VMs download patches.
- Applications call external APIs.
- Vendors need to allowlist a fixed source IP.
- A subnet needs scalable SNAT capacity.
- Direct VM public IPs must be removed.

### NAT Gateway versus Azure Firewall

| NAT Gateway | Azure Firewall |
|---|---|
| Outbound source NAT | Stateful network security and filtering |
| Predictable egress IP | Network/application rules and threat intelligence |
| No inbound publishing | Can participate in centralized ingress/egress design |
| No URL/FQDN inspection policy by itself | Central policy, logs and inspection features |
| Attached to subnets | Usually deployed in a secured hub |

### Scenario

> A payment integration provider allowed traffic only from approved public IPs. We attached NAT Gateway with a static public IP to the application subnet and gave that address to the provider for allowlisting.

---

## 6. A client shuts down a development VM every night but still gets charged. What is wrong?

### Interview answer

The user may be shutting down the operating system, leaving the Azure VM in **Stopped** rather than **Stopped (deallocated)**. To release compute allocation and stop normal compute billing, the VM should be deallocated through Azure control-plane operations such as the portal, Azure CLI, PowerShell, an automation runbook or the auto-shutdown feature.

Even after deallocation, charges can continue for:

- Managed disks.
- Snapshots.
- Backup storage.
- Monitoring data ingestion.
- Reserved/static networking resources depending on SKU and configuration.
- Other dependent services.

### Commands

```bash
az vm get-instance-view -g rg-dev -n vm-dev --query instanceView.statuses -o table
az vm deallocate -g rg-dev -n vm-dev
```

### Scenario

> The developer used `shutdown -h now` inside Linux. The portal showed `Stopped`, and compute allocation remained. We configured Azure auto-shutdown and a morning start schedule through automation, then reviewed disks and backup costs separately.

---

## 7. A Linux VM root filesystem is running out of space. Explain the full process

### First principle

Before changing storage, identify whether the root filesystem is a normal partition or LVM. Also determine whether space is consumed by logs, deleted-open files, container layers or application data. Extending a disk without investigating may only delay the problem.

### Diagnosis

```bash
df -hT
lsblk -f
sudo fdisk -l
sudo du -xhd1 / | sort -h
sudo lsof +L1
sudo pvs
sudo vgs
sudo lvs
```

### Option A - Extend the existing OS disk

1. Take a backup or snapshot according to change policy.
2. Increase the managed OS disk size in Azure.
3. Rescan or restart if the operating system does not detect the new size.
4. Confirm the device layout with `lsblk`.
5. Grow the correct partition.
6. Grow the filesystem or LVM logical volume.
7. Validate with `df -hT` and application health checks.

Example for a normal partition:

```bash
sudo growpart /dev/sda 2
```

For ext4:

```bash
sudo resize2fs /dev/sda2
```

For XFS:

```bash
sudo xfs_growfs /
```

### Option B - Root filesystem uses LVM

The exact device names must be confirmed before executing:

```bash
sudo growpart /dev/sda 3
sudo pvresize /dev/sda3
sudo lvextend -r -l +100%FREE /dev/mapper/rootvg-rootlv
```

The `-r` option grows the filesystem together with the logical volume when supported.

### Option C - Add a new data disk

A new disk is useful for moving application data, logs or container storage. It does not automatically enlarge a non-LVM root filesystem.

```bash
lsblk
sudo parted /dev/sdc --script mklabel gpt mkpart primary 0% 100%
sudo mkfs.xfs /dev/sdc1
sudo mkdir -p /data
sudo blkid /dev/sdc1
sudo mount /dev/sdc1 /data
```

Add the UUID to `/etc/fstab`, then test:

```bash
sudo mount -a
```

### Scenario

> `/var/lib/docker` consumed the root disk. We attached and mounted a managed data disk, stopped Docker, moved its data directory, updated configuration and restarted the service. This was safer than continuously increasing the OS disk.

### Risks

- Expanding the wrong partition.
- Editing `/etc/fstab` with an invalid device path.
- No backup or recovery plan.
- Growing a filesystem with the wrong tool.
- Ignoring deleted files still held open by a process.

---

## 8. A VM has high CPU. Which Azure-native tools do you use?

### Interview answer

I would use Azure Monitor Metrics for host-level CPU history, VM Insights for guest and dependency visibility, Log Analytics for performance queries, and Performance Diagnostics/PerfInsights for deeper analysis. I would also check Activity Log, Resource Health and Service Health to correlate platform changes or incidents.

### Troubleshooting order

1. Determine when CPU increased and whether it is constant or periodic.
2. Check CPU with memory, disk latency, IOPS and network metrics.
3. Identify recent deployments, patches, scaling or configuration changes.
4. Use VM Insights or guest tools to find the process.
5. Check whether the VM is undersized or a process is abnormal.
6. Review autoscale options or application tuning.
7. Create an alert and capture evidence for recurrence.

### Guest commands

Linux:

```bash
top
ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head
pidstat 1
```

Windows:

```powershell
Get-Process | Sort-Object CPU -Descending | Select-Object -First 10
```

### Scenario

> CPU reached 95% every night. Azure Monitor showed a repeatable pattern, and VM Insights identified an antivirus scan overlapping with a backup job. We changed the schedules and created an alert for sustained CPU above the agreed threshold.

---

## 9. You have ten VMs and want to update all of them centrally. What do you use?

### Interview answer

For operating-system patch assessment and deployment, I would use **Azure Update Manager**. It can assess and schedule updates for Windows and Linux machines in Azure and for supported Azure Arc-enabled machines.

### Implementation approach

- Enable periodic assessment.
- Group machines by environment, tag, subscription or maintenance requirement.
- Create maintenance windows.
- Patch Dev first, then QA, then Production.
- Exclude or separately handle highly sensitive systems.
- Review compliance and failed updates.
- Integrate alerts and change records.

### Scenario

> We had ten VMs across Dev, QA and Production. We created separate maintenance configurations, patched Dev first, monitored for 24 hours, then promoted the same patch baseline to QA and Production during approved windows.

---

## 10. Are you familiar with Azure Automation Accounts and Azure Update Manager?

### Interview answer

Yes. They solve different problems.

**Azure Automation Account** is used for operational automation through PowerShell/Python runbooks, schedules, webhooks, managed identities and Hybrid Runbook Workers.

**Azure Update Manager** is the dedicated service for update assessment, scheduling and compliance of supported Windows and Linux machines. The current Update Manager service does not require the older Automation Account plus Log Analytics architecture.

### Example use

- Automation Account: Start/stop non-production VMs, produce reports, remediate tags or run a custom operational task.
- Update Manager: Assess missing patches, create maintenance schedules and track update compliance.

### Security practice

Use managed identity for runbooks, grant only required RBAC, avoid stored credentials, and log runbook output without exposing secrets.

---

## 11. You have Contributor access but Blob Storage returns access denied. Why?

### Short answer

Contributor is primarily a management-plane role. It allows management of the storage account but does not automatically grant access to blob data. Blob access requires a data-plane role or another valid data access method.

### Possible fixes

Assign the minimum required role at the correct scope:

- Storage Blob Data Reader.
- Storage Blob Data Contributor.
- Storage Blob Data Owner.

Also check:

- Correct identity is being used.
- Role assignment has propagated.
- Storage firewall or private endpoint blocks the client.
- Public network access is disabled.
- SAS token has expired or lacks permission.
- Shared-key access is disabled.
- DNS resolves to the expected endpoint.

### Scenario

> A pipeline service principal had Contributor on the resource group and could create the storage account. Terraform backend initialization still failed because the identity could not access the state blob. We assigned the required Blob data role on the state container or storage account and used Entra ID authentication.

---

## 12. Is an API key in an environment variable a secret? Build-time or runtime? Where do you store it in GitHub?

### Interview answer

Yes. An API key is a secret regardless of whether it is stored in an environment variable.

- **Build-time secret:** needed only while building, such as access to a private package feed.
- **Runtime secret:** needed by the running application to call an external service.

In GitHub, CI/CD secrets can be stored as repository, environment or organization secrets. Production secrets should normally use a protected GitHub Environment with approvals. For Azure authentication, prefer OpenID Connect/workload identity federation instead of a long-lived client secret.

For application runtime, prefer Azure Key Vault plus managed identity or workload identity. Do not bake secrets into container images, source code or plain pipeline variables.

### GitHub example

```yaml
env:
  API_KEY: ${{ secrets.API_KEY }}
```

### Scenario

> A build argument containing an API key was written into a Docker image layer. We removed it from the Dockerfile, used a secure build-secret mechanism for build-time access, and retrieved the runtime key from Key Vault through workload identity.

---

## 13. How would you design a highly available Azure environment?

### Interview answer

I start with the required SLA, RTO, RPO and failure scenarios. High availability within a region is different from disaster recovery across regions.

A common web architecture includes:

- Multiple application instances.
- Availability Zones where supported.
- Load Balancer or Application Gateway.
- Autoscaling.
- Zone-redundant PaaS services.
- Database high availability and backups.
- Front Door for multi-region routing where required.
- Central monitoring and health probes.
- Infrastructure as Code for repeatable recovery.
- Tested backup and disaster-recovery procedures.

### Scenario

> For a production application, we deployed at least two instances across zones behind Application Gateway, used a zone-redundant managed database, stored static content in redundant storage, and used Front Door for regional failover. We tested health probes and documented the failover procedure.

### Interview distinction

- Availability Set protects against fault/update domains but not a complete zone failure.
- Availability Zones provide datacenter-level separation within a region.
- Multi-region design addresses a regional outage but adds complexity and cost.

---

## 14. Which CI/CD tools have you used besides Azure DevOps?

### Safe interview answer

My strongest hands-on CI/CD experience is with Azure DevOps, and I also have experience or familiarity with GitHub Actions. I understand Jenkins pipeline concepts and can work with declarative Jenkinsfiles, credentials, agents and stages. I focus on the common principles: source trigger, build, test, scan, artifact publication, deployment, approval, validation and rollback.

### Why this answer works

It is honest and shows transferable knowledge. Do not claim production ownership of Jenkins or another tool unless you can answer deep follow-ups on agents, plugins, shared libraries, upgrades and credentials.

---

## 15. What is a workflow file and what is it used for?

### Interview answer

In GitHub Actions, a workflow file is a YAML file stored in `.github/workflows`. It defines automated jobs that run on events such as push, pull request, schedule or manual dispatch.

A workflow normally contains:

- Name.
- Trigger under `on`.
- Permissions.
- Jobs.
- Runner selection.
- Steps and reusable actions.
- Variables and secrets.
- Environment and approval configuration.

### Example

```yaml
name: validate

on:
  pull_request:

permissions:
  contents: read

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: echo "Run validation"
```

---

## 16. If you need to create a CI/CD pipeline, which file do you edit and where?

### Answer by platform

| Platform | File/location |
|---|---|
| GitHub Actions | `.github/workflows/<name>.yml` |
| Azure DevOps YAML | Commonly `azure-pipelines.yml` or another configured YAML path |
| Jenkins | `Jenkinsfile` |
| GitLab CI/CD | `.gitlab-ci.yml` |

### Interview note

The file name is only part of the answer. Also explain triggers, stages, agents/runners, secrets, artifacts, environments, approvals and deployment strategy.

---

## 17. Do you have experience configuring Azure Web Apps?

### Interview answer

I am familiar with configuring Azure App Service Web Apps. The normal areas are:

1. App Service Plan and region.
2. Runtime stack or container image.
3. Application settings and connection strings.
4. Managed identity and Key Vault references.
5. Deployment source and CI/CD.
6. Custom domain and TLS.
7. Health check and Always On where required.
8. Scaling and autoscale.
9. Application Insights and diagnostic logs.
10. Deployment slots and slot swap.
11. VNet Integration for private outbound access.
12. Private Endpoint or access restrictions for inbound control.
13. Backup and recovery configuration.

### Important networking distinction

- **VNet Integration:** outbound access from the Web App into a VNet.
- **Private Endpoint:** private inbound access to the Web App.
- **Access restrictions:** control which sources can reach the public endpoint.

### Scenario

> We deployed a new version to a staging slot, validated health and dependencies, then swapped it into Production. The application used managed identity to retrieve secrets from Key Vault, and Application Insights monitored exceptions and dependency latency.

---

## Official references

- Azure NAT Gateway overview: https://learn.microsoft.com/azure/nat-gateway/nat-overview
- Azure Storage private endpoints: https://learn.microsoft.com/azure/storage/common/storage-private-endpoints
- Application Gateway 502 troubleshooting: https://learn.microsoft.com/troubleshoot/azure/application-gateway/application-gateway-troubleshooting-502
- Azure Front Door documentation: https://learn.microsoft.com/azure/frontdoor/
- Azure Update Manager: https://learn.microsoft.com/azure/update-manager/overview
- GitHub Actions workflow syntax: https://docs.github.com/actions/reference/workflows-and-actions/workflow-syntax
