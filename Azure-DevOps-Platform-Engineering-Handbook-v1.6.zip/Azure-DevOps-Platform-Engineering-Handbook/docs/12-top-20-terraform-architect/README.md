# Top 20 Azure + Terraform + DevSecOps Architect Interview Questions

> Priority-1 preparation bank for Senior Azure DevOps Engineer, Terraform SME, DevSecOps Lead, Cloud Platform Engineer, Azure Landing Zone Architect and Principal Cloud Architect interviews.

## How to use this chapter

For every question, start with the **Short Interview Answer**. If the interviewer asks a follow-up, expand using the architecture, implementation, security, troubleshooting and production-scenario sections. The goal is to show design thinking, not only Terraform syntax.

---

# 1. How would you design Terraform architecture for enterprise Azure infrastructure?

## Short Interview Answer

I would design Terraform as a layered, modular and environment-isolated platform. I keep reusable child modules separate from environment root modules, store state remotely in a secured Azure Storage backend, authenticate pipelines through workload identity federation instead of long-lived secrets, and enforce all changes through pull requests and CI/CD. Platform layers such as management groups, connectivity, identity and monitoring are separated from application landing zones so teams can deploy independently without sharing one large state file.

## Detailed Architect Answer

For an enterprise Azure environment I avoid one monolithic Terraform repository and one state file. I normally divide the platform into logical layers:

1. **Bootstrap layer** - state storage, deployment identities and minimum prerequisites.
2. **Tenant/governance layer** - management groups, subscriptions, policies, policy initiatives, RBAC and diagnostics.
3. **Connectivity layer** - hub/vWAN, firewall, DNS, DDoS, ExpressRoute/VPN and shared networking.
4. **Identity/security layer** - role assignments, Key Vault, managed identities and security controls.
5. **Management layer** - Log Analytics, Azure Monitor, Defender for Cloud, Sentinel integration and backup foundations.
6. **Application landing zones** - workload subscriptions and application-specific infrastructure.

Each independently deployable layer gets its own root module and state. Reusable child modules contain standard patterns such as VNet, subnet, NSG, Key Vault, App Service, AKS, Storage, SQL and monitoring.

A representative repository is:

```text
terraform-platform/
├── modules/
│   ├── network/
│   ├── nsg/
│   ├── key-vault/
│   ├── storage/
│   ├── app-service/
│   └── aks/
├── live/
│   ├── platform/
│   │   ├── governance/
│   │   ├── connectivity/
│   │   ├── identity/
│   │   └── management/
│   └── landing-zones/
│       ├── dev/
│       ├── qa/
│       ├── uat/
│       └── prod/
└── pipelines/
```

## State Architecture

I keep state small and aligned to ownership boundaries. A connectivity state should not contain 200 application resources. State keys can look like:

```text
platform/governance.tfstate
platform/connectivity-eastus.tfstate
platform/connectivity-centralindia.tfstate
workloads/payments/dev.tfstate
workloads/payments/prod.tfstate
```

The backend storage account is protected with RBAC, private endpoints, firewall rules, versioning/soft delete where appropriate, monitoring and restricted administrative access.

## CI/CD Architecture

Pull request pipeline:

```text
terraform fmt -check
        ↓
terraform init
        ↓
terraform validate
        ↓
TFLint
        ↓
Checkov / tfsec
        ↓
Gitleaks
        ↓
terraform plan
        ↓
Publish plan + PR review
```

After approval and merge:

```text
Approved commit
   ↓
Re-initialize exact environment
   ↓
Re-plan or use controlled saved plan
   ↓
Environment approval for production
   ↓
terraform apply
   ↓
Post-deployment validation
   ↓
Monitoring / drift check
```

## Security Principles

- No credentials in source code or `tfvars` committed to Git.
- OIDC/workload identity federation for Azure DevOps or GitHub Actions where supported.
- Least-privilege RBAC per pipeline and per layer.
- Private networking for sensitive backends and services.
- Policy-as-code and security scanning before `apply`.
- Production applies only from protected branches and controlled pipelines.
- Break-glass access is separate from normal deployment identity.

## Production Scenario

Suppose the organization runs 40 applications across Dev, QA, UAT and Prod. If all 40 applications use one Terraform state, a networking change can lock the entire platform and a failure can affect unrelated teams. I separate state by platform capability and workload. The networking team owns connectivity states, while application teams consume approved network outputs or platform interfaces. This reduces blast radius and allows parallel deployments.

## Troubleshooting Thinking

If an enterprise Terraform pipeline becomes slow or risky, I check:

1. Is the state too large?
2. Are unrelated resources coupled in one root module?
3. Are providers or data sources causing slow refresh?
4. Are modules versioned?
5. Is ownership unclear?
6. Are teams running `apply` from laptops instead of controlled pipelines?
7. Are manual changes creating drift?

## Interview Follow-ups

- Monorepo or multiple repositories?
- Terraform workspaces or separate environment roots?
- How do you bootstrap the backend?
- How do you version modules?
- How do you promote changes across environments?

## Quick Revision

**Enterprise Terraform = modular code + small isolated states + remote backend + federated identity + PR controls + security scanning + controlled apply + drift detection.**

---

# 2. What is Terraform State? How do you implement Remote Backend, State Locking and State Management in production?

## Short Interview Answer

Terraform state is Terraform's record of the relationship between configuration and real infrastructure. In production I never depend on a local state file. I use an Azure Storage `azurerm` backend, restrict access using Azure RBAC and private networking, use backend locking to prevent concurrent writes, separate state by environment and workload, and protect state through storage recovery controls and tightly controlled pipeline access.

## What Terraform State Contains

State records resource addresses, provider-managed attributes, dependencies and identifiers needed to compare desired configuration with deployed infrastructure. Because state can contain sensitive values, it must be treated as a sensitive operational asset.

Typical backend configuration:

```hcl
terraform {
  backend "azurerm" {
    resource_group_name  = "rg-tfstate-prod"
    storage_account_name = "sttfstateprod001"
    container_name       = "tfstate"
    key                  = "payments/prod.tfstate"
  }
}
```

In larger environments I prefer passing backend details at `terraform init` rather than hardcoding environment-specific values:

```bash
terraform init \
  -backend-config="resource_group_name=rg-tfstate-prod" \
  -backend-config="storage_account_name=sttfstateprod001" \
  -backend-config="container_name=tfstate" \
  -backend-config="key=payments/prod.tfstate"
```

## State Locking

The AzureRM backend coordinates state access using Azure Blob lease-based locking. When one operation owns the lock, another write operation should not proceed against the same state. This protects against two engineers or two pipeline runs modifying the same state concurrently.

I do not casually use `terraform force-unlock`. First I confirm that no legitimate apply is still running. A stale lock is cleared only after investigation.

## Production Controls

- Dedicated state subscription or tightly controlled platform subscription.
- Storage account public access disabled when practical.
- Private endpoint and private DNS for sensitive environments.
- RBAC instead of shared storage keys.
- Separate identities for read/plan and production apply where required.
- Storage logging and activity monitoring.
- Blob recovery/versioning/soft-delete capabilities according to organization policy.
- No state file committed to Git.
- No routine `terraform state` manipulation from engineer laptops.

## State Management Commands

Useful commands include:

```bash
terraform state list
terraform state show <address>
terraform state mv <source> <destination>
terraform state rm <address>
terraform import <address> <resource-id>
terraform plan -refresh-only
```

State commands are powerful. I back up or rely on backend recovery controls and always review the impact before changing state references.

## Production Scenario

Two pipelines accidentally start for the same production state. Pipeline A acquires the backend lock. Pipeline B fails/waits instead of writing simultaneously. I let Pipeline A finish and then rerun B from the latest commit. I do not bypass the lock to make the pipeline green.

## Quick Revision

**State is the source of Terraform's resource mapping. Production state must be remote, isolated, access-controlled, recoverable and locked during writes.**

---

# 3. How do you isolate Terraform State for Dev, QA, Prod and multiple workloads?

## Short Interview Answer

I isolate state according to security boundary, lifecycle and ownership. Dev, QA, UAT and Prod should not share one state. Different workloads also normally get separate state files. For enterprise Azure I prefer separate root modules and backend keys, often combined with separate subscriptions and deployment identities, rather than relying only on Terraform workspaces.

## Recommended Pattern

```text
state container
├── platform/governance.tfstate
├── platform/connectivity.tfstate
├── payments/dev.tfstate
├── payments/qa.tfstate
├── payments/uat.tfstate
├── payments/prod.tfstate
├── reporting/dev.tfstate
└── reporting/prod.tfstate
```

Environment code can be organized as:

```text
live/
├── dev/payments/
├── qa/payments/
├── uat/payments/
└── prod/payments/
```

Each root has its own backend key and environment inputs.

## Why Not One State?

One large state causes:

- Larger blast radius.
- More lock contention.
- Slower plan/refresh.
- Difficult ownership boundaries.
- Risk that a Dev change affects Prod resources.
- Harder RBAC separation.

## Workspaces

Terraform workspaces can be useful when the configuration and lifecycle are genuinely identical and the environment boundary is lightweight. For regulated production environments I normally prefer explicit directories/root modules and separate backend keys because the separation is visible and easier to govern.

## Scenario

A developer should be able to deploy a Dev application without obtaining write access to the Prod state. I therefore give the Dev pipeline identity access only to Dev subscription resources and its Dev state blob/container scope. The production identity is separate and only runs from the protected production pipeline.

## Quick Revision

**State separation should follow blast radius, ownership, security and deployment lifecycle - not convenience.**

---

# 4. How do you design Terraform Root Modules and Child Modules? How do you create reusable enterprise modules?

## Short Interview Answer

A child module is a reusable building block, while a root module assembles those building blocks for a specific environment or workload. I keep child modules opinionated but configurable, version them, document inputs/outputs, avoid environment-specific hardcoding, and test them before adoption. Root modules own environment composition, provider configuration, backend, module versions and environment-specific variables.

## Child Module Example

```text
modules/vnet/
├── main.tf
├── variables.tf
├── outputs.tf
├── versions.tf
├── README.md
└── tests/
```

Example:

```hcl
resource "azurerm_virtual_network" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = var.address_space
  tags                = var.tags
}
```

A root module calls the child module:

```hcl
module "app_vnet" {
  source  = "git::https://example/modules.git//vnet?ref=v2.3.0"

  name                = "vnet-payments-prod"
  location            = local.location
  resource_group_name = azurerm_resource_group.network.name
  address_space       = ["10.40.0.0/16"]
  tags                = local.tags
}
```

## Enterprise Module Rules

A reusable module should:

- Have a single clear purpose.
- Expose only meaningful variables.
- Validate critical inputs.
- Produce useful outputs.
- Apply organization defaults such as tags and diagnostics when appropriate.
- Avoid embedding secrets.
- Avoid hardcoding subscription IDs or environment names.
- Pin compatible Terraform/provider versions.
- Be versioned using tags/releases.
- Include examples and automated tests/validation.

## Anti-pattern

I avoid a giant module called `complete-enterprise-platform` that creates every Azure service. It becomes difficult to upgrade and forces unrelated resources into the same lifecycle.

## Scenario

The platform team publishes `network`, `key-vault`, `storage`, `app-service` and `aks` modules. Application teams consume approved versions. A security improvement to the storage module is released as `v3.1.0`, tested in Dev, and promoted after validation rather than silently changing every workload.

## Quick Revision

**Child module = reusable building block. Root module = environment composition and deployment boundary.**

---

# 5. count vs for_each - when do you use each in production and why?

## Short Interview Answer

I use `count` when resources are naturally indexed and interchangeable, especially simple optional resources. I use `for_each` when each resource has a stable business key such as subnet name, NSG name or application name. In production, `for_each` is usually safer for collections because removing one item does not renumber all later resources.

## Example: count

```hcl
resource "azurerm_public_ip" "example" {
  count = var.enable_public_ip ? 1 : 0
  # ...
}
```

## Example: for_each

```hcl
variable "subnets" {
  type = map(object({
    address_prefix = string
  }))
}

resource "azurerm_subnet" "this" {
  for_each = var.subnets

  name                 = each.key
  address_prefixes     = [each.value.address_prefix]
  virtual_network_name = azurerm_virtual_network.this.name
  resource_group_name  = var.resource_group_name
}
```

Resource addresses are stable:

```text
azurerm_subnet.this["app"]
azurerm_subnet.this["data"]
```

With `count`, addresses look like indices:

```text
azurerm_subnet.this[0]
azurerm_subnet.this[1]
```

Removing an item from the middle of an indexed list may change address-to-object mappings and can create unexpected changes.

## Interview Rule

- Boolean/identical N instances -> `count` can be fine.
- Named resources with stable identities -> prefer `for_each`.

---

# 6. How do you implement nested maps/objects with for_each in Terraform?

## Short Interview Answer

I model enterprise configuration as typed maps of objects and transform nested structures into a flat map when a resource needs one `for_each` instance per nested item. Stable compound keys such as `vnet1.app` make resource addresses deterministic.

## Example Input

```hcl
variable "vnets" {
  type = map(object({
    address_space = list(string)
    subnets = map(object({
      prefix = string
      nsg    = optional(string)
    }))
  }))
}
```

Example value:

```hcl
vnets = {
  hub = {
    address_space = ["10.0.0.0/16"]
    subnets = {
      firewall = { prefix = "10.0.0.0/24" }
      bastion  = { prefix = "10.0.1.0/26" }
    }
  }
  app = {
    address_space = ["10.10.0.0/16"]
    subnets = {
      web = { prefix = "10.10.1.0/24" }
      api = { prefix = "10.10.2.0/24" }
    }
  }
}
```

## Flatten for subnet creation

```hcl
locals {
  subnet_map = merge([
    for vnet_key, vnet in var.vnets : {
      for subnet_key, subnet in vnet.subnets :
      "${vnet_key}.${subnet_key}" => {
        vnet_key   = vnet_key
        subnet_key = subnet_key
        prefix     = subnet.prefix
      }
    }
  ]...)
}
```

Then:

```hcl
resource "azurerm_subnet" "this" {
  for_each = local.subnet_map

  name                 = each.value.subnet_key
  virtual_network_name = azurerm_virtual_network.this[each.value.vnet_key].name
  resource_group_name  = var.resource_group_name
  address_prefixes     = [each.value.prefix]
}
```

## Best Practices

- Define strong object types instead of `map(any)`.
- Use stable keys.
- Keep transformation logic in `locals`.
- Do not build unreadable one-line expressions.
- Add variable validation for CIDR, environment and naming rules.

---

# 7. How would you architect and implement an Azure Landing Zone with Terraform from scratch to production?

## Short Interview Answer

I build an Azure Landing Zone in layers: tenant and management groups, subscription organization, governance policies, identity and RBAC, connectivity, management/monitoring, security and application landing zones. Terraform is deployed through controlled pipelines using reusable modules and isolated states. I bootstrap only the minimum prerequisites manually or through an approved bootstrap process, then all repeatable platform changes go through Git and CI/CD.

## Target Management Group Structure

```text
Tenant Root
└── Enterprise
    ├── Platform
    │   ├── Identity
    │   ├── Connectivity
    │   └── Management
    ├── Landing-Zones
    │   ├── Corp
    │   └── Online
    ├── Sandbox
    └── Decommissioned
```

Subscriptions are placed below the correct management group. Dev/QA/UAT/Prod workload subscriptions can be separated to enforce isolation and cost ownership.

## Implementation Sequence

### Phase 1 - Bootstrap

- Deployment identity/workload federation.
- Terraform state storage.
- Pipeline/service connection.
- Repository branch protection.

### Phase 2 - Tenant and Governance

- Management groups.
- Subscription placement.
- Azure Policy definitions and initiatives.
- Mandatory tags/naming guardrails.
- Allowed locations/SKUs where required.
- Diagnostic settings and security baselines.
- RBAC and PIM model.

### Phase 3 - Platform Subscriptions

**Connectivity:** hub/vWAN, Azure Firewall, DNS, DDoS, Bastion, ExpressRoute/VPN.

**Management:** Log Analytics, Azure Monitor, alerting, Defender/Sentinel integration.

**Identity/shared services:** only where required by design.

### Phase 4 - Application Landing Zones

Subscription vending/onboarding creates:

- Subscription placement.
- Standard RBAC groups.
- Policy inheritance.
- Spoke VNet and hub connectivity.
- Diagnostic settings.
- Budget and tags.
- Optional standard resource groups.

## Terraform Layers

```text
live/platform/governance
live/platform/connectivity
live/platform/management
live/landing-zones/app01-dev
live/landing-zones/app01-prod
```

Each layer owns its own state and deployment identity scope.

## Security

- PIM for privileged human access.
- Managed identities for Azure workloads.
- OIDC for CI/CD.
- No standing Owner access for engineers.
- Azure Policy for continuous governance.
- Defender for Cloud for posture management.
- Private endpoints for sensitive PaaS services.
- Central logging and SIEM forwarding.

## Production Scenario

A new regulated application requests Dev and Prod subscriptions. Instead of engineers creating them manually, an approved onboarding request triggers a pipeline. Terraform places subscriptions under the correct management group, assigns policy initiatives and RBAC groups, creates network connectivity, configures diagnostics/budgets and exposes the landing zone to the application team. Production still requires controlled approval, but resource creation is automated and reproducible.

## Troubleshooting

If landing-zone deployment fails I identify the failed layer first. Common causes are:

- Management-group or tenant-level permissions missing.
- Policy denying a platform resource before required exceptions are in place.
- Provider registration not complete.
- Peering or address-space overlap.
- DNS/private endpoint dependencies.
- Wrong state/backend key.
- Subscription not placed under the expected management group.

## Quick Revision

**Landing Zone = governance + identity + connectivity + management + security + subscription automation, delivered as version-controlled platform code.**

---

# 8. How do you implement Hub-and-Spoke Azure networking with Terraform - VNet, Subnet, NSG, UDR, Firewall and Peering?

## Short Interview Answer

I create a dedicated connectivity layer. The hub contains shared services such as Azure Firewall, Bastion, DNS and gateways. Workload spokes contain application subnets. Terraform creates non-overlapping VNets, subnet delegations, NSGs, route tables, UDRs, peering and firewall policy. Spoke traffic is forced through the hub when inspection is required, and private DNS is centrally governed.

## Architecture

```text
                    Internet / On-prem
                           |
              ExpressRoute / VPN Gateway
                           |
                    +-------------+
                    |    HUB VNet  |
                    | Firewall     |
                    | Bastion      |
                    | DNS Resolver |
                    +------+------+ 
                           |
              +------------+------------+
              |                         |
        +-----+------+            +-----+------+
        | Spoke App1 |            | Spoke App2 |
        | Web/API/DB |            | AKS/PaaS   |
        +------------+            +------------+
```

## Terraform Design

I normally use child modules such as:

```text
modules/
├── vnet/
├── subnet/
├── nsg/
├── route-table/
├── peering/
├── firewall/
└── private-dns/
```

Spokes are driven through maps:

```hcl
module "spoke" {
  for_each = var.spokes
  source   = "../../modules/vnet"

  name          = each.value.name
  address_space = each.value.address_space
  subnets       = each.value.subnets
}
```

## Routing

For inspection, a spoke subnet route table can send default traffic to the firewall private IP:

```hcl
route {
  name                   = "default-to-firewall"
  address_prefix         = "0.0.0.0/0"
  next_hop_type          = "VirtualAppliance"
  next_hop_in_ip_address = var.firewall_private_ip
}
```

I review special Azure service routing and ensure the design does not break required platform traffic.

## Peering

Hub-to-spoke and spoke-to-hub peerings are separate resources. Settings such as forwarded traffic and gateway transit must match the intended topology.

## Security Design

- NSGs provide subnet/NIC-level filtering.
- ASGs can simplify grouping of VM NICs.
- Azure Firewall provides central L3-L7 filtering and egress controls.
- UDRs control traffic path.
- Private endpoints remove public data-plane exposure where required.
- DDoS protection is enabled according to risk and enterprise standard.
- DNS is designed before private endpoint rollout.

## Production Scenario

An application spoke must reach Azure SQL through a private endpoint, on-premises through ExpressRoute and the internet only through Azure Firewall. Terraform creates the spoke, peering, SQL private endpoint and DNS zone link, then applies a route table that sends approved egress to the firewall. A missing private DNS link would cause the SQL hostname to resolve publicly, so DNS validation is part of post-deployment tests.

## Troubleshooting Sequence

1. Check effective routes.
2. Check effective security rules/NSG.
3. Verify peering status and flags.
4. Verify firewall network/application rules.
5. Check DNS resolution.
6. Check private endpoint approval/state.
7. Check address overlap.
8. Check UDR next-hop reachability.
9. Use Network Watcher connection troubleshoot where appropriate.

---

# 9. How do you securely implement Azure authentication for Terraform? Service Principal vs Managed Identity vs OIDC?

## Short Interview Answer

My first choice depends on where Terraform runs. For GitHub Actions or modern Azure DevOps pipelines, I prefer workload identity federation/OIDC because it avoids stored client secrets. For Terraform running on an Azure-hosted workload, managed identity is preferred. A service principal with a client secret is a legacy/fallback pattern and should be tightly controlled and rotated if unavoidable.

## Comparison

| Method | Best fit | Secret stored? | Main consideration |
|---|---|---:|---|
| Service Principal + secret | Legacy/external automation | Yes | Rotation and secret leakage risk |
| Managed Identity | Workload running in Azure | No | Tied to Azure resource/runtime |
| Workload Identity Federation/OIDC | Azure DevOps/GitHub/CI systems | No long-lived secret | Trust configuration must be correct |

## OIDC Flow

```text
Pipeline
   ↓ requests short-lived identity token
CI identity provider
   ↓ federated trust
Microsoft Entra ID
   ↓ short-lived Azure token
Terraform AzureRM provider
   ↓
Azure Resource Manager
```

## RBAC

Authentication proves who the pipeline is. Authorization controls what it can do. I scope permissions to the minimum required subscription/resource group/management group. A networking pipeline does not need Global Administrator or permanent Owner rights.

## Security Controls

- Separate deployment identities by environment and blast radius.
- Production identity usable only from protected pipeline/environment.
- No credentials in YAML or repository variables.
- Use Key Vault only for secrets that truly must exist; do not create a secret simply because the older pipeline pattern used one.
- Audit service principal/federated credential usage.
- Use PIM for human privilege, not as a substitute for workload identity.

## Production Scenario

A GitHub Actions workflow deploys a Dev subscription. Instead of storing `ARM_CLIENT_SECRET`, I configure a federated credential that trusts only the approved repository and environment/branch claim. GitHub requests a short-lived token, Azure validates the trust, and Terraform receives a temporary Azure access token. If the workflow comes from an untrusted fork or wrong branch, the trust condition should not match.

## Quick Revision

**CI/CD: OIDC first. Azure-hosted automation: managed identity. Secret-based SP only when required. Always combine authentication with least-privilege RBAC.**

---

# 10. How do you manage secrets/passwords in Terraform and integrate Azure Key Vault?

## Short Interview Answer

I avoid putting secrets in Terraform code, Git, plain `tfvars`, pipeline YAML or outputs. Applications normally retrieve secrets directly from Key Vault using managed identity. Terraform should provision the vault, access model and secret references where necessary, but I minimize secret values passing through Terraform because values handled by Terraform can be written to state even when marked sensitive.

## Important Interview Point

`sensitive = true` prevents casual display in CLI/UI, but it does **not** automatically mean the value is absent from Terraform state. Therefore, the safest pattern is often to keep application secret material outside Terraform state entirely.

## Preferred Application Pattern

```text
Application
   ↓ Managed Identity
Azure Key Vault
   ↓
Secret / Certificate / Key
```

Terraform configures:

- Key Vault.
- RBAC role assignment.
- Private endpoint.
- Private DNS.
- Managed identity.
- Application setting that references Key Vault where the service supports it.

## CI/CD Secrets

If a pipeline requires a secret that cannot be removed:

- Store it in Azure Key Vault or secure CI secret store.
- Fetch it at runtime.
- Mask logs.
- Never echo it.
- Rotate it.

## Production Scenario

An App Service requires a database credential. Instead of writing the password into `terraform.tfvars`, I use a managed identity and Key Vault reference or native identity-based database authentication when supported. Terraform deploys the managed identity and permissions. The application reads the value at runtime. This avoids putting the password in Git and minimizes state exposure.

## Common Mistakes

- Committing `.tfvars` containing passwords.
- Printing sensitive outputs in pipeline logs.
- Using Key Vault but then reading the secret through a Terraform data source and storing it in state unnecessarily.
- Giving the pipeline broad Key Vault Administrator access.

---

# 11. What is the complete Terraform DevSecOps CI/CD flow - fmt -> validate -> lint -> security scan -> plan -> approval -> apply?

## Short Interview Answer

My Terraform pipeline separates validation from deployment. Pull requests run formatting, initialization, validation, linting, secret and IaC security scans, then generate a plan. Reviewers approve the code and plan. After merge, the deployment stage revalidates the approved commit, authenticates through OIDC, applies to lower environments automatically and uses protected environment approvals for production. Post-deployment checks and drift monitoring close the loop.

## Recommended Flow

```text
Developer branch
   ↓
Pull Request
   ↓
terraform fmt -check
   ↓
terraform init -backend=false (or safe init)
   ↓
terraform validate
   ↓
TFLint
   ↓
Gitleaks / secret scan
   ↓
Checkov / tfsec / Terrascan
   ↓
terraform plan
   ↓
Publish plan + cost/security result
   ↓
Code owner review
   ↓
Merge to protected branch
   ↓
Deploy Dev → QA → UAT
   ↓
Production environment approval
   ↓
terraform apply
   ↓
Post validation / monitoring / drift
```

## Azure DevOps Example

```yaml
stages:
- stage: Validate
  jobs:
  - job: TerraformChecks
    steps:
    - script: terraform fmt -check -recursive
    - script: terraform init
    - script: terraform validate
    - script: tflint --recursive
    - script: checkov -d .
    - script: gitleaks detect --source .
    - script: terraform plan -out=tfplan

- stage: Apply_Prod
  dependsOn: Validate
  condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/main'))
  jobs:
  - deployment: TerraformApply
    environment: production
    strategy:
      runOnce:
        deploy:
          steps:
          - script: terraform apply -auto-approve tfplan
```

In a real implementation I also make sure the exact plan/commit relationship is controlled. I do not blindly apply an old plan after the target environment has changed.

## Enforcement

Typical policy:

- Formatting/validation/lint failure -> fail.
- Secret detected -> fail.
- Critical/high IaC misconfiguration -> fail unless documented time-bound exception policy allows otherwise.
- Unexpected delete in production -> require additional review or fail based on policy.
- Cost increase beyond threshold -> warning or approval requirement.

## Progressive Enforcement

If introducing security tooling into a legacy platform, I may start in report-only mode to establish a baseline, then enforce critical findings, then high findings, and gradually tighten the gate. New code should meet the stronger standard immediately.

## Production Scenario

A PR opens public network access on a Storage Account. Checkov flags the issue and the pipeline fails before Terraform reaches production. The developer changes the design to use a private endpoint and restricted network access. The next plan is reviewed and approved.

## Troubleshooting

If the pipeline fails:

1. Identify which stage failed - syntax, provider init, lint, security, plan or apply.
2. Read the first meaningful error rather than only the final exit code.
3. Reproduce safely in an isolated environment if needed.
4. Confirm tool versions and provider lock file.
5. Confirm authentication and RBAC.
6. Check Azure Policy or resource-provider constraints.
7. Never disable a security gate just to make a production deployment pass without approved exception handling.

---

# 12. How do you implement Terraform security scanning? Where do Checkov, tfsec, TFLint and secret scanning fit?

## Short Interview Answer

I use different tools for different failure classes. `terraform validate` checks Terraform configuration semantics, TFLint catches Terraform/provider-specific quality issues, Checkov/tfsec/Terrascan look for infrastructure security misconfigurations, and Gitleaks or TruffleHog detect secrets. These scans run before `plan`/`apply`, with policy thresholds and exception governance.

## Tool Responsibilities

- **TFLint** - linting, conventions and provider-aware rules.
- **Checkov** - IaC security/compliance policies across Terraform and other IaC formats.
- **tfsec** - Terraform-focused static security analysis; many organizations now also consider Trivy IaC capabilities.
- **Terrascan** - policy-based IaC scanning.
- **Gitleaks / TruffleHog** - secret detection.
- **Trivy** - container/image/filesystem/IaC scanning depending on pipeline design.
- **SonarQube** - application source quality/SAST concerns, not a replacement for Terraform-specific checks.

## Pipeline Placement

```text
Commit → fmt → validate → lint → secret scan → IaC security scan → plan → approval → apply
```

## Policy as Code

For organization-specific requirements I add custom policies, for example:

- Storage must disable public access.
- SQL must use private connectivity.
- Required tags must exist.
- Production resources must use approved regions/SKUs.
- Key Vault must enable organization-required protection controls.

## False Positives

A finding is not ignored informally. The engineer documents why it is not applicable, gets the required security approval, creates a narrowly scoped exception, and assigns an expiry/review date.

---

# 13. What is Terraform Drift? If someone changes a production resource from Azure Portal, how do you detect and resolve it?

## Short Interview Answer

Terraform drift means the real infrastructure no longer matches the desired Terraform configuration/state relationship, usually because of manual changes or external automation. I detect it through scheduled `terraform plan -detailed-exitcode` or refresh-only reviews and resolve it by either reverting the manual change through Terraform or deliberately updating the code if the new setting is approved.

## Detection

A scheduled pipeline can run:

```bash
terraform init
terraform plan -detailed-exitcode
```

Typical exit meanings:

- `0` - no changes.
- `2` - changes present.
- `1` - error.

A refresh-only plan can help inspect changes to tracked remote objects:

```bash
terraform plan -refresh-only
```

## Resolution Decision

### Manual change was unauthorized

Keep code as desired state and run approved Terraform apply to restore the compliant value.

### Manual change was valid and should become standard

Update Terraform code to represent the new approved value, review through PR, then plan/apply so code, state and Azure converge again.

## Do Not Do

- Do not immediately add `ignore_changes` to hide every drift.
- Do not edit the state JSON manually.
- Do not run random `terraform state rm` without understanding ownership.

## Production Scenario

Terraform defines a Storage Account with public network access disabled. Someone enables public access in the portal during troubleshooting. The scheduled drift job produces a non-empty plan showing Terraform will disable it again. Security verifies that the portal change was temporary, a change record is created if required, and the approved pipeline restores the Terraform-defined configuration.

## Preventing Drift

- Restrict direct production write access.
- Use PIM/JIT for emergency operations.
- Azure Policy can deny prohibited settings.
- All standard changes through Git/CI/CD.
- Scheduled drift detection and alerting.
- Activity logs to identify who changed the resource.

## Quick Revision

**Detect drift with plan. Decide whether code or real infrastructure is correct. Converge through reviewed code and pipeline. Prevent recurrence with RBAC, Policy and change controls.**

---

# 14. Terraform plan shows unexpected destruction/recreation. How do you identify the root cause?

## Short Interview Answer

I stop before apply and inspect the plan at resource and attribute level. I identify which property is forcing replacement, compare code/provider/state changes, check resource addressing changes caused by `count` or `for_each`, review module/provider upgrades and verify whether a resource was renamed or moved in code without a `moved` block/state migration.

## Investigation Checklist

1. Read `-/+` replacement details in the plan.
2. Identify the `forces replacement` attribute.
3. Compare recent Git changes.
4. Review provider version changes and `.terraform.lock.hcl`.
5. Check module version change.
6. Check resource address changes.
7. Check `count` list re-indexing.
8. Check changed `for_each` keys.
9. Check immutable Azure property changes.
10. Check whether resource was manually replaced outside Terraform.
11. Check whether a rename needs a `moved` block.

## Example: Resource Rename

Old:

```hcl
resource "azurerm_resource_group" "app" { }
```

New:

```hcl
resource "azurerm_resource_group" "workload" { }
```

Without migration, Terraform may interpret this as delete old/create new. A `moved` block can preserve intent:

```hcl
moved {
  from = azurerm_resource_group.app
  to   = azurerm_resource_group.workload
}
```

## Production Rule

Unexpected destroy in production is a stop condition until the reason is understood. `-auto-approve` does not remove the need for plan governance.

---

# 15. How do you import existing Azure infrastructure into Terraform and align configuration/state afterward?

## Short Interview Answer

Import only adds an existing resource to Terraform's state/address relationship; it does not magically produce a complete maintainable configuration. I first write or generate the intended Terraform configuration, import the resource using the correct resource ID/address, run plan, then iteratively align the code until the plan is empty or only contains intentional changes.

## Classic Import

```bash
terraform import \
  azurerm_resource_group.example \
  /subscriptions/<sub>/resourceGroups/rg-existing
```

## Declarative Import Block

Modern Terraform also supports import blocks, for example:

```hcl
import {
  to = azurerm_resource_group.example
  id = "/subscriptions/<sub>/resourceGroups/rg-existing"
}
```

## Migration Process

1. Inventory existing infrastructure.
2. Decide ownership boundaries and target modules.
3. Back up/verify remote state protections.
4. Write Terraform resource/module configuration.
5. Import into the exact resource address.
6. Run `terraform plan`.
7. Align optional/default properties carefully.
8. Repeat until no unexpected change remains.
9. Enable normal CI/CD and drift controls.

## Important Risk

If code does not reflect the current resource, the first apply after import can modify or replace production infrastructure. Therefore I never import and immediately apply without a clean plan review.

---

# 16. What are Terraform lifecycle, prevent_destroy, create_before_destroy and ignore_changes used for in production?

## Short Interview Answer

Lifecycle settings change how Terraform handles updates. `prevent_destroy` protects critical resources from accidental Terraform destruction, `create_before_destroy` can reduce downtime when replacement is supported, and `ignore_changes` intentionally delegates specific attributes to another controller. They are targeted controls, not substitutes for correct design.

## prevent_destroy

```hcl
lifecycle {
  prevent_destroy = true
}
```

Useful for selected critical resources such as stateful data resources, but it can also block legitimate planned replacement. It should be accompanied by backup and governance, not treated as a backup solution.

## create_before_destroy

```hcl
lifecycle {
  create_before_destroy = true
}
```

Useful when Azure allows two instances to coexist and naming/dependency constraints permit it. It is not always possible for globally unique names or singleton resources.

## ignore_changes

```hcl
lifecycle {
  ignore_changes = [
    tags["LastPatched"]
  ]
}
```

Use only when another approved system owns that attribute. Overuse hides drift.

## Production Scenario

An autoscaling platform adjusts an instance count that Terraform defines initially. If the service architecture intentionally delegates runtime scaling to the autoscaler, an appropriate lifecycle strategy may avoid Terraform continuously fighting the runtime controller. The ownership decision must be documented.

---

# 17. Multiple developers/teams work on the same Terraform platform. How do you manage state conflicts, ownership and concurrent deployments?

## Short Interview Answer

I solve this with architecture and process: small state boundaries, clear team ownership, remote locking, protected branches, CI/CD-only applies, CODEOWNERS, environment-specific identities and serialized deployment per state. Engineers can work in parallel on separate states, but two pipelines should not apply the same state concurrently.

## Controls

### State boundaries

Split by platform capability/workload/environment.

### Git controls

- Protected main branch.
- Pull requests required.
- CODEOWNERS for critical modules/platform folders.
- Required status checks.
- No direct production commits.

### Pipeline controls

- One deployment at a time per state/environment.
- Backend locking.
- Environment approvals.
- Use latest approved commit.
- Re-plan after stale approvals or changed target environment.

### Ownership

Example:

```text
platform/connectivity → Network Platform Team
platform/governance   → Cloud Governance Team
workloads/payments    → Payments Platform Team
modules/*             → Cloud Engineering Team
```

## Production Scenario

Developer A changes the hub firewall while Developer B deploys a payments App Service. If both are in one state, they contend for one lock and increase blast radius. With separate connectivity and workload states, both can proceed independently. A deliberate interface such as remote outputs, resource IDs or platform catalog data connects the layers.

## Conflict Scenario

If two PRs both modify the same Terraform file, Git conflict is resolved before merge. If two pipelines target the same state, backend locking/deployment concurrency control prevents unsafe simultaneous apply. If one pipeline has already changed the target after another plan was generated, the second deployment should re-plan.

## Quick Revision

**Parallelize by state boundary, not by bypassing locks. One owner and one controlled writer per state at a time.**

---

# 18. How would you architect production-grade Private AKS with Terraform - networking, identity, Key Vault, private endpoint, ingress, WAF and monitoring?

## Short Interview Answer

I place AKS in a dedicated workload subscription/spoke with private API access, private connectivity to ACR/Key Vault/data services, controlled egress through Azure Firewall or an approved egress design, Microsoft Entra integration and workload identity, multiple node pools across availability zones, WAF-protected ingress, Azure Monitor/Container Insights or managed Prometheus/Grafana, policy/Defender controls and separate Terraform states for platform network versus the AKS workload.

## Architecture

```text
Internet Users
     |
Azure Front Door (optional global edge/WAF)
     |
Application Gateway WAF / approved ingress tier
     |
Private AKS ingress
     |
AKS Private Cluster
├── system node pool
├── application node pools
├── autoscaling
└── workload identity
     |
+----+-------------------+
|                        |
Private ACR         Key Vault
Private Endpoint    Private Endpoint
|                        |
Private DNS Zones / DNS Resolver
     |
Hub Firewall / controlled egress
```

## Networking

- Private AKS API server.
- Azure CNI/CNI Overlay or enterprise-approved network plugin.
- Non-overlapping pod/service/VNet ranges.
- Network policies where required.
- Private endpoints for ACR, Key Vault and databases.
- Private DNS zone linking/resolution through central DNS design.
- UDR/firewall egress if forced tunneling is part of the architecture.

## Identity

- Microsoft Entra integrated access.
- Azure RBAC/Kubernetes authorization according to organization standard.
- Workload Identity for pods accessing Azure resources.
- No service-principal secrets inside Kubernetes manifests.
- PIM-controlled cluster administration.

## Secrets

Use Azure Key Vault provider/CSI integration or application-native Key Vault access through workload identity. Do not store production secrets in Helm values committed to Git.

## Ingress and WAF

Depending on the enterprise standard I use Application Gateway WAF v2 with a supported ingress integration, Application Gateway for Containers, or another approved ingress architecture. For global applications, Front Door can provide global routing and edge WAF before regional ingress.

## Availability and Scaling

- Node pools distributed across Availability Zones where region/SKU supports it.
- Multiple replicas and pod anti-affinity/topology spread.
- HPA for pods.
- Cluster Autoscaler for nodes.
- Pod disruption budgets.
- Multiple regions when business RTO/RPO requires regional resilience.

## Monitoring and Security

- Azure Monitor and Log Analytics/Container Insights as required.
- Managed Prometheus/Grafana where adopted.
- Application Insights/OpenTelemetry for app telemetry.
- Defender for Containers/Defender for Cloud.
- Azure Policy for Kubernetes where required.
- ACR image scanning and CI Trivy scanning.
- Audit logs and alerting.

## Terraform Structure

```text
platform/connectivity.tfstate
workloads/app01/aks.tfstate
workloads/app01/data.tfstate
```

The AKS root consumes network IDs created by the connectivity layer instead of owning the enterprise hub.

## Production Scenario

A payment API runs on private AKS. Pods access Key Vault and Storage using workload identity and private endpoints. Inbound traffic reaches WAF, then ingress. Outbound traffic is inspected by the hub firewall. A node pool autoscaler expands during peak load. If the primary region becomes unavailable and the RTO/RPO requires region-level DR, traffic is redirected to a pre-provisioned or suitably automated secondary regional stack.

## Troubleshooting

Private AKS failures are often DNS/routing/identity related. I check:

1. API private DNS resolution.
2. Network path from build agent/management plane.
3. UDR/firewall rules.
4. ACR private DNS and pull permissions.
5. Workload identity subject/audience/federated trust.
6. Key Vault RBAC/private endpoint.
7. Ingress health probe and backend health.
8. Pod events and container logs.
9. Node readiness and autoscaler events.

---

# 19. Terraform apply partially fails or Azure API/resource creation fails. What is your recovery and troubleshooting strategy?

## Short Interview Answer

I do not assume the whole deployment rolled back because Terraform is not a transactional database. I read the exact error, inspect which resources were successfully recorded in state and which Azure resources exist, correct the root cause, run a fresh plan, and let Terraform converge from the current reality. I only use import or state operations when Terraform and Azure ownership genuinely need reconciliation.

## Failure Categories

- Authentication/RBAC failure.
- Azure Policy denial.
- Quota/SKU/region availability.
- Resource provider not registered.
- Naming conflict.
- Dependency/timing issue.
- Network/DNS path from self-hosted agent.
- Azure API transient error.
- Resource created in Azure but provider did not persist state due to interruption.

## Recovery Process

1. Stop repeated blind retries.
2. Read pipeline and provider error.
3. Check Azure Activity Log/operation details.
4. Run `terraform state list` and inspect relevant resources.
5. Check Azure actual resource existence.
6. Fix prerequisite/policy/quota/permissions.
7. Run a new `terraform plan`.
8. If Terraform recognizes created resources, apply the remaining delta.
9. If a resource exists but is not in state, import only after confirming it is the intended resource.
10. If a failed resource must be recreated, ensure dependencies and destructive impact are understood.

## Scenario

Terraform creates a resource group, VNet and two subnets, then fails while creating Application Gateway because the subnet does not meet a requirement. The resources already created remain. I fix the subnet/configuration, run plan again, and Terraform proposes only the missing/corrective changes. I do not delete everything manually unless the design requires a clean rebuild and it is safe.

## State Safety

Never hand-edit the JSON state in routine troubleshooting. Prefer supported state/import/moved operations and remote state recovery capabilities.

---

# 20. Design a multi-subscription, multi-region Azure Landing Zone + Terraform + DevSecOps platform from scratch. What is your complete architecture and implementation approach?

## Short Interview Answer

I start with business, regulatory, RTO/RPO and connectivity requirements, then build a management-group and subscription model, regional connectivity hubs, centralized identity/governance/monitoring, and application landing zones. Terraform is split into reusable modules and independently owned state layers. All changes flow through protected Git branches, OIDC-authenticated CI/CD, IaC/security/cost policy gates, approvals and automated deployment. Production has least privilege, private connectivity, high availability, multi-region DR where justified, continuous monitoring, drift detection and tested recovery procedures.

## 1. Requirements and Guardrails

Before writing Terraform I confirm:

- Regions and data residency.
- Regulatory controls.
- Internet/on-prem connectivity.
- RTO and RPO.
- Expected workload scale.
- Subscription isolation requirements.
- Identity model.
- Logging/SIEM retention.
- Cost allocation model.

## 2. Management Group and Subscription Design

```text
Tenant Root
└── Enterprise
    ├── Platform
    │   ├── Identity
    │   ├── Connectivity
    │   └── Management
    ├── Landing-Zones
    │   ├── Corp
    │   └── Online
    ├── Sandbox
    └── Decommissioned
```

Platform subscriptions can include connectivity and management. Workloads use separate subscriptions based on environment/business boundary. Production is isolated from non-production.

## 3. Multi-Region Connectivity

For each strategic region:

- Regional hub or vWAN hub.
- Azure Firewall/Firewall Policy.
- DNS resolver design.
- ExpressRoute/VPN connectivity.
- Bastion/management access as needed.
- DDoS protection according to standard.
- Spoke landing zones with controlled peering/routing.

Global traffic can use Front Door or Traffic Manager depending on protocol and routing requirements.

## 4. Identity and Zero Trust

- Microsoft Entra ID groups drive human RBAC.
- PIM provides time-bound privileged access.
- Managed identity for Azure workloads.
- OIDC/workload federation for CI/CD.
- Conditional Access for human administrators.
- Separate break-glass process.
- Least privilege at management-group/subscription/resource scope.

## 5. Governance and Compliance

Azure Policy initiatives enforce standards such as:

- Approved locations.
- Diagnostic settings.
- Required tags.
- Encryption/security configurations.
- Public-access restrictions.
- Private endpoint requirements for selected services.
- Defender plans where required.

Policies are tested progressively. Exceptions are documented, scoped and time bound.

## 6. Terraform Architecture

```text
modules/
├── management-groups/
├── policy/
├── subscription-vending/
├── hub-network/
├── spoke-network/
├── private-endpoint/
├── monitoring/
├── key-vault/
├── aks/
└── app-service/

live/
├── platform/
│   ├── governance/
│   ├── connectivity-eastus/
│   ├── connectivity-centralindia/
│   └── management/
└── workloads/
    ├── payments/dev/
    ├── payments/prod-eastus/
    └── payments/prod-centralindia/
```

Each root module has independent state and minimum required deployment permissions.

## 7. DevSecOps Pipeline

```text
Feature branch
   ↓
Pull Request
   ↓
fmt / validate / TFLint
   ↓
Gitleaks / TruffleHog
   ↓
Checkov / tfsec / Terrascan
   ↓
terraform plan
   ↓
Infracost / policy checks
   ↓
CODEOWNER review
   ↓
Merge
   ↓
Dev apply
   ↓
QA/UAT promotion
   ↓
Production approval
   ↓
Prod apply
   ↓
Post-deployment tests
   ↓
Monitoring + drift detection
```

Production pipeline authentication uses OIDC and protected environments. No long-lived deployment secrets are stored in Git.

## 8. Application Architecture

Workloads choose services based on requirements:

- App Service/Functions/Container Apps for managed PaaS use cases.
- Private AKS for Kubernetes workloads needing orchestration flexibility.
- Azure SQL/PostgreSQL/Cosmos DB based on data model.
- Key Vault for secrets/keys/certificates.
- Private endpoints for sensitive PaaS.
- Front Door/Application Gateway WAF for controlled ingress.
- Service Bus/Event Hubs/Event Grid for decoupled integration.

The platform offers approved modules rather than forcing every application onto the same runtime.

## 9. High Availability and DR

Within a region:

- Availability Zones where supported.
- Zone-redundant PaaS tiers where required.
- Autoscaling.
- Redundant network/security components according to Azure service design.

Across regions:

- Business-defined active-active or active-passive model.
- Data replication chosen per service.
- Front Door/Traffic Manager failover.
- Recovery Services/ASR for applicable IaaS.
- Backup copies and restore testing.
- Runbooks with tested RTO/RPO.

## 10. Observability and Security Operations

- Azure Monitor.
- Central Log Analytics strategy.
- Application Insights/OpenTelemetry.
- Activity/resource logs through diagnostic settings.
- Defender for Cloud.
- Sentinel/SIEM integration.
- Alerts and action groups.
- Audit trail for pipeline and privileged activity.

## 11. Cost / FinOps

- Budgets and alerts by subscription/team.
- Mandatory cost tags.
- Infracost in pull requests where useful.
- Advisor recommendations reviewed through governance.
- Rightsizing and autoscaling.
- Reservations/Savings Plans after stable usage analysis.
- Automated cleanup of approved ephemeral environments.

## 12. Drift and Day-2 Operations

- Scheduled drift plans.
- Restricted direct production writes.
- Provider/module upgrade process.
- State backup/recovery controls.
- Policy compliance reports.
- Patch/image lifecycle.
- DR exercises.
- Cost and security reviews.

## Real Production Example

Assume a regulated payments platform must run in two Azure regions. Terraform first deploys tenant governance and platform subscriptions. Regional hubs provide firewall, DNS and private hybrid connectivity. The payment application receives isolated Dev and Prod subscriptions. Prod runs private AKS, private ACR, Key Vault and database endpoints, with WAF ingress and centralized logging. Git PRs must pass Terraform validation, secret scanning, IaC security checks and plan review. Lower environments deploy automatically; production requires protected approval. OIDC authenticates the pipeline. Azure Policy prevents prohibited public access, and a scheduled plan detects drift. Cross-region traffic failover and data-replication design are tested against documented RTO/RPO.

## Architect Interview Closing Statement

> "My objective is not simply to make Terraform create Azure resources. I design the platform so that governance, identity, networking, security, observability, cost controls and deployment automation are part of the architecture from day one. The end state is a reproducible landing-zone platform where teams can deploy quickly, but production remains controlled, least-privileged, observable and continuously compliant."

---

# Priority-1 Architect Questions

If time is limited, prepare these ten first:

1. Enterprise Terraform architecture.
2. Remote state, locking and state management.
3. Azure Landing Zone with Terraform.
4. Hub-and-spoke networking with Terraform.
5. Secure Azure authentication - SP vs Managed Identity vs OIDC.
6. Terraform DevSecOps pipeline.
7. Terraform drift detection and remediation.
8. Multi-team state and ownership model.
9. Production private AKS architecture.
10. Multi-subscription, multi-region landing-zone platform.

# 60-Second Architect Framework

For any architecture question, answer in this order:

```text
Requirements
   ↓
Subscription / ownership boundary
   ↓
Identity and RBAC
   ↓
Network and private connectivity
   ↓
Terraform modules and state
   ↓
CI/CD and security gates
   ↓
HA / scaling / DR
   ↓
Monitoring and operations
   ↓
Cost and governance
   ↓
Troubleshooting / recovery
```

This structure keeps the answer organized and demonstrates Senior/Architect-level thinking.
