# 07 - VS Code se GitHub Repository me Handbook Push Karne ka Exact Guide

Repository URL:

```text
https://github.com/amrit1435/Azure-DevOps-Platform-Engineering-Handbook.git
```

## Recommended and safest method: clone first, then copy files

This method avoids unrelated-history and remote-README conflicts.

### Step 1 - ZIP extract karein

Download ki gayi handbook ZIP ko kisi temporary location par extract karein, for example:

```text
C:\Users\<username>\Downloads\Azure-DevOps-Platform-Engineering-Handbook
```

### Step 2 - VS Code me parent working folder open karein

VS Code -> **File -> Open Folder**.

For example:

```text
D:\GitHub
```

### Step 3 - VS Code terminal open karein

Menu:

```text
Terminal -> New Terminal
```

PowerShell me run karein:

```powershell
git --version
git config --global user.name
git config --global user.email
```

Agar name/email blank ho to configure karein:

```powershell
git config --global user.name "Amritpal Singh"
git config --global user.email "<your-github-email>"
```

### Step 4 - GitHub repository clone karein

```powershell
cd D:\GitHub
git clone https://github.com/amrit1435/Azure-DevOps-Platform-Engineering-Handbook.git
cd Azure-DevOps-Platform-Engineering-Handbook
```

Check:

```powershell
git remote -v
git branch --show-current
git status
```

### Step 5 - Generated files copy karein

Extracted ZIP ke **andar ke files and folders** ko cloned repository folder ke andar copy karein.

Correct result:

```text
D:\GitHub\Azure-DevOps-Platform-Engineering-Handbook\README.md
D:\GitHub\Azure-DevOps-Platform-Engineering-Handbook\docs\
D:\GitHub\Azure-DevOps-Platform-Engineering-Handbook\examples\
```

Wrong result, because an unnecessary nested folder was created:

```text
D:\GitHub\Azure-DevOps-Platform-Engineering-Handbook\Azure-DevOps-Platform-Engineering-Handbook\README.md
```

### Step 6 - Review changes

```powershell
git status
git diff --stat
```

Optional: VS Code left sidebar me **Source Control** icon open karke changed files review karein.

### Step 7 - Stage and commit

```powershell
git add .
git status
git commit -m "Add complete Azure DevOps interview handbook"
```

### Step 8 - Push

```powershell
git push -u origin main
```

Agar repository ka default branch `master` ho, first check:

```powershell
git branch -a
```

Normally new GitHub repositories use `main`.

### Step 9 - Verify on GitHub

Browser me repository open karke confirm karein:

- README render ho raha hai.
- `docs` folders visible hain.
- Word document accidentally repository me push nahi hua unless you intentionally add it.
- Koi secret, `.tfstate`, `.tfvars`, token or client document upload nahi hua.

---

# Existing local directory ko directly use karna ho

Use this only when the folder already contains your files and you do not want to clone into a fresh folder.

```powershell
cd "D:\path\to\your\directory"
git init
git branch -M main
```

Check remote:

```powershell
git remote -v
```

Agar `origin` nahi hai:

```powershell
git remote add origin https://github.com/amrit1435/Azure-DevOps-Platform-Engineering-Handbook.git
```

Agar `origin` already hai but URL wrong hai:

```powershell
git remote set-url origin https://github.com/amrit1435/Azure-DevOps-Platform-Engineering-Handbook.git
```

Then:

```powershell
git add .
git commit -m "Add complete Azure DevOps interview handbook"
git push -u origin main
```

## Push rejected because remote already contains README

Error may look like:

```text
rejected - fetch first
```

Run:

```powershell
git pull origin main --allow-unrelated-histories
```

If conflict appears:

1. VS Code Source Control me conflicted file open karein.
2. Keep Current, Keep Incoming or manually combine content.
3. Conflict markers remove karein:

```text
<<<<<<<
=======
>>>>>>>
```

4. Then run:

```powershell
git add .
git commit -m "Merge remote repository and handbook content"
git push -u origin main
```

The clone-first method is simpler and avoids most of these issues.

---

# Daily update workflow

Har new question-answer update ke baad:

```powershell
cd D:\GitHub\Azure-DevOps-Platform-Engineering-Handbook
git pull --rebase origin main
git status
git add .
git commit -m "Add new interview questions and answers"
git push origin main
```

## Specific files only

```powershell
git add docs/05-devsecops-persistent/README.md
git commit -m "Expand Persistent DevSecOps interview answers"
git push origin main
```

---

# Useful troubleshooting commands

## Check current folder

```powershell
Get-Location
Get-ChildItem
```

## Check Git state

```powershell
git status
git log --oneline -5
git remote -v
git branch -a
```

## Authentication problem

Because GitHub is already connected to VS Code, pushing should open the normal authentication flow when required. Do not paste a personal access token into a Markdown file or terminal command that will remain in history.

## Wrong file committed

Before push:

```powershell
git restore --staged path\to\file
```

After a normal non-secret file was pushed, remove it in a new commit:

```powershell
git rm path\to\file
git commit -m "Remove unnecessary file"
git push
```

If a secret was committed, removing the file is not enough. Revoke/rotate the secret immediately and clean Git history using an approved method.

---

# VS Code graphical method

1. Open the cloned repository folder.
2. Click **Source Control** on the left.
3. Review all changed files.
4. Click `+` to stage selected files or **Stage All Changes**.
5. Enter commit message.
6. Click **Commit**.
7. Click **Sync Changes** or **Push**.

Terminal commands are still useful because interviewers expect basic Git troubleshooting knowledge.


---

# Git Fundamentals - Interview Question Bank
This section contains the Git foundation questions commonly asked in Azure DevOps and core DevOps interviews. Answers are intentionally simple and include a practical example.
## Quick mental model

```text
Working Directory -> git add -> Staging Area -> git commit -> Local Repository -> git push -> Remote Repository
```
## 1. What is Git?

**Simple interview answer**

Git is a distributed version control system. It tracks changes in files, mainly source code, and lets developers work safely on the same project.

**Practical example**

In a Terraform repository, Git can track every change to main.tf, variables.tf and pipeline YAML so the team can review, compare and roll back changes.
## 2. Why do we use Git?

**Simple interview answer**

We use Git for version tracking, collaboration, branching, code review, rollback and controlled change management. It also integrates with CI/CD tools such as Azure DevOps and GitHub Actions.

**Practical example**

A developer creates a feature branch for a new Azure module, raises a pull request, gets it reviewed, and only then merges it into main.
## 3. What is version control?

**Simple interview answer**

Version control is a system that records changes to files over time so we can see what changed, who changed it and restore an earlier version when required.

**Practical example**

Instead of keeping files named final-v1, final-v2 and final-latest, Git keeps one project with a reliable commit history.
## 4. What problem does Git solve?

**Simple interview answer**

Git solves change tracking, parallel development, collaboration, rollback and auditability problems. It prevents teams from overwriting each other's work and gives a history of every meaningful change.

**Practical example**

If a production pipeline breaks after a code change, Git history helps identify the exact commit and restore or revert it.
## 5. What is a Git repository?

**Simple interview answer**

A Git repository is a project directory whose files and history are tracked by Git. A local repository contains a hidden .git directory that stores commits, branches, references and metadata.

**Practical example**

A Terraform repo may contain modules, environment folders and pipeline files, while .git stores their version history.
## 6. How do you create a Git repository?

**Simple interview answer**

For a new local repository, go to the project folder and run git init. To create a local copy of an existing remote repository, use git clone <URL>.

**Practical example**

Commands: mkdir demo; cd demo; git init. For an existing GitHub repo: git clone https://github.com/org/repo.git
## 7. What is the working directory?

**Simple interview answer**

The working directory is the checked-out project folder where you open, create and modify files. These changes are not committed automatically.

**Practical example**

When you edit main.tf in VS Code, that edited file exists in the working directory until you stage and commit it.
## 8. Where do changes exist when you first modify a file?

**Simple interview answer**

They first exist in the working directory as unstaged changes. git status normally shows them under 'Changes not staged for commit'.

**Practical example**

Edit network.tf, run git status, and Git shows network.tf as modified but not yet staged.
## 9. What is the staging area?

**Simple interview answer**

The staging area, also called the index, is an intermediate area where you select the exact changes that should go into the next commit.

**Practical example**

You changed main.tf, README.md and test.tf, but only main.tf is ready. git add main.tf stages only that file.
## 10. Why do we need a staging area?

**Simple interview answer**

It gives us control over the content of the next commit. We can prepare one logical change instead of committing every modified file together.

**Practical example**

A documentation change can remain unstaged while the tested Terraform change is staged and committed separately.
## 11. What does git add do?

**Simple interview answer**

git add copies selected changes from the working directory into the staging area. It does not create a commit and it does not upload anything to GitHub.

**Practical example**

git add main.tf stages one file; git add . stages all relevant changes under the current directory.
## 12. What is a commit?

**Simple interview answer**

A commit is a saved snapshot of staged changes in the local Git history. It has a unique hash, author, timestamp and message.

**Practical example**

A commit such as 'Add production NSG rules' creates a traceable point that can later be reviewed or reverted.
## 13. Why do we create commits?

**Simple interview answer**

Commits create meaningful checkpoints, provide traceability, support rollback and make reviews easier. A good practice is one logical change per commit.

**Practical example**

Separate 'Add VNet module' and 'Update README' into different commits when they are unrelated changes.
## 14. What does git commit do?

**Simple interview answer**

git commit records the currently staged changes in the local repository history. It does not send the commit to the remote repository.

**Practical example**

git commit -m "Add Azure VNet module" saves the staged change locally; git push is still required to share it.
## 15. Why is a commit message important?

**Simple interview answer**

A commit message explains the purpose of a change. Good messages make history, reviews, troubleshooting and rollback much easier.

**Practical example**

'Restrict web subnet inbound traffic to Application Gateway' is much more useful than 'update'.
## 16. What does git status show?

**Simple interview answer**

git status shows the current branch and the state of files: untracked, modified, staged or clean. It also shows whether the branch is ahead of or behind its remote tracking branch.

**Practical example**

Before committing Terraform changes, run git status to confirm only the intended files are staged.
## 17. What is Git history?

**Simple interview answer**

Git history is the ordered record of commits made in a repository. It shows how the project evolved and usually includes commit hash, author, date and message.

**Practical example**

During an incident, history can show which recent infrastructure commit introduced a breaking change.
## 18. How can you view Git history?

**Simple interview answer**

Use git log. Useful forms are git log --oneline for a compact list and git log --oneline --graph --all --decorate for a branch graph.

**Practical example**

git log --oneline -10 shows the latest ten commits for quick investigation.
## 19. What is a branch?

**Simple interview answer**

A branch is an independent line of development that points to a series of commits. It lets you work on a change without modifying the stable main branch directly.

**Practical example**

Create feature/add-private-endpoint, implement and test the change, then merge it after review.
## 20. Why do we use branches?

**Simple interview answer**

Branches isolate features, fixes and experiments, allow parallel work and support pull-request reviews before changes reach the main code line.

**Practical example**

One engineer works on networking while another works on monitoring, each in a separate branch.
## 21. What is the main branch?

**Simple interview answer**

main is normally the primary branch that represents the stable or integration-ready codebase. Teams often protect it so changes require pull requests, reviews and passing checks.

**Practical example**

Production Terraform code may be deployed only from protected main after approval.
## 22. How do you create a new branch?

**Simple interview answer**

Use git switch -c <branch-name>. The older equivalent is git checkout -b <branch-name>.

**Practical example**

Example: git switch -c feature/storage-private-endpoint
## 23. What does it mean to switch branches?

**Simple interview answer**

Switching branches changes which branch is checked out in your working directory. Git updates the working tree to match that branch's committed content.

**Practical example**

git switch feature/network moves you from main to the feature/network branch so new commits go there.
## 24. What is merging?

**Simple interview answer**

Merging combines changes from one branch into another. Git finds the common history and integrates the source branch changes into the target branch.

**Practical example**

After a pull request is approved, the feature branch is merged into main.
## 25. Why do we merge branches?

**Simple interview answer**

We merge after a feature or fix has been reviewed and tested so that its changes become part of the shared target branch.

**Practical example**

A tested Terraform module change is merged into main before the production pipeline can use it.
## 26. What is a merge conflict?

**Simple interview answer**

A merge conflict happens when Git cannot automatically combine competing changes, usually because both branches changed the same lines or one branch deleted something another changed. A developer must resolve it manually and then commit the resolution.

**Practical example**

Two engineers edit the same NSG rule differently; Git marks the conflicting section and asks for a manual decision.
## 27. What is a remote repository?

**Simple interview answer**

A remote repository is a Git repository hosted somewhere accessible to the team, such as GitHub, Azure Repos, GitLab or Bitbucket. It is used to share commits and collaborate.

**Practical example**

Your laptop has a local clone while origin points to the team's GitHub repository.
## 28. What is GitHub?

**Simple interview answer**

GitHub is a cloud platform for hosting Git repositories and adding collaboration features such as pull requests, code review, issues, branch protection and GitHub Actions.

**Practical example**

A team can host Terraform code in GitHub and trigger a GitHub Actions validation workflow for every pull request.
## 29. What is the difference between Git and GitHub?

**Simple interview answer**

Git is the version control system that runs locally and tracks changes. GitHub is a hosted platform that stores Git repositories and provides collaboration and automation features.

**Practical example**

You can use Git without GitHub. GitHub relies on Git repositories but adds remote hosting, PRs, permissions and CI/CD integrations.
## 30. What does git push do?

**Simple interview answer**

git push sends local commits and branch references to a remote repository. It is how you share committed work with the team.

**Practical example**

git push -u origin feature/storage publishes the local feature/storage branch to the remote named origin.
## 31. What does git pull do?

**Simple interview answer**

git pull brings remote changes into the current local branch. In common use it performs a fetch and then integrates the fetched changes, usually by merge or rebase depending on configuration.

**Practical example**

Before starting work, git pull --rebase origin main can update your local main branch while keeping history clean.
## 32. What does git clone do?

**Simple interview answer**

git clone creates a new local repository from an existing remote repository. It downloads project files, commit history and remote configuration.

**Practical example**

git clone https://github.com/org/platform-iac.git creates a local working copy and configures origin automatically.
## 33. What is the difference between git push and git pull?

**Simple interview answer**

git push sends your local commits to the remote. git pull brings remote changes to your local branch.

**Practical example**

Think: push = local to remote; pull = remote to local.
## 34. What is the difference between git clone and git pull?

**Simple interview answer**

git clone is normally used the first time to create a local copy of a repository. git pull is used later inside an existing local repository to bring in newer remote changes.

**Practical example**

First day: git clone. Daily sync after that: git pull or git fetch plus rebase/merge.
## 35. What is the difference between git add and git commit?

**Simple interview answer**

git add stages selected changes for the next commit. git commit records those staged changes in the local repository history.

**Practical example**

Working directory -> git add -> staging area -> git commit -> local repository.
## 36. Can you explain the Git workflow from making a change to creating a commit?

**Simple interview answer**

Modify the file, check git status, review with git diff, stage the intended change with git add, verify the staged set, then run git commit with a meaningful message.

**Practical example**

Example: edit main.tf; git status; git diff; git add main.tf; git diff --staged; git commit -m "Add private endpoint".
## 37. Can you explain how a local repository communicates with a remote repository?

**Simple interview answer**

A local repository stores a remote URL, commonly named origin. Git communicates with that remote over HTTPS or SSH using commands such as fetch, pull and push, with authentication handled by credentials, tokens, SSH keys or enterprise identity.

**Practical example**

git remote -v shows the configured remote; git fetch origin downloads remote references without changing your working branch.
## 38. Can you explain Git to someone who has never used it before?

**Simple interview answer**

Git is like a professional change-history system for a project. It remembers meaningful versions, lets people work independently in branches, shows who changed what, and helps recover from mistakes. Developers save checkpoints as commits and can share them through a remote platform such as GitHub.

**Practical example**

Instead of keeping project-final, project-final2 and project-final-final, Git keeps one project with a searchable, auditable history.
## Basic Git workflow to remember

```bash
git status
git diff
git add .
git commit -m "Describe the logical change"
git push origin <branch-name>
```

For team development, normally add: branch -> pull request -> review -> merge -> main.
## 30-second interview answer

> Git is a distributed version control system used to track changes and support collaboration. When I modify a file, the change is first in the working directory. I review it, stage the required changes with `git add`, create a local checkpoint with `git commit`, and share the commit through a remote repository using `git push`. For team work, I normally create a feature branch, raise a pull request, get the change reviewed and merge it into the protected main branch.
