# 04 - TCS Platform Engineering, Azure and DevOps Interview Questions

---

## 1. How will you migrate a monolithic application to microservices?

### Short interview answer

I would migrate gradually, not rewrite everything at once. I would first understand the business domains and dependencies, select a low-risk capability, extract it behind an API using the Strangler pattern, give the service clear data ownership, add independent CI/CD and observability, and then move additional capabilities in controlled phases.

### Detailed approach

#### Step 1 - Assess the monolith

Identify:

- Business modules and domain boundaries.
- Code and database coupling.
- High-change and high-failure areas.
- Integration points.
- Current traffic and performance.
- Test coverage.
- Operational dependencies.
- Compliance and data requirements.

The first question is not “How many microservices should we create?” It is “Which business capability can be separated with acceptable risk?”

#### Step 2 - Define service boundaries

Use business capabilities or bounded contexts such as:

```text
Customer
Product Catalogue
Inventory
Order
Payment
Notification
Reporting
```

Avoid splitting only by technical layers such as one frontend service, one business-logic service and one data service, because that often creates a distributed monolith.

#### Step 3 - Use the Strangler pattern

```mermaid
flowchart LR
    Client --> Gateway[API Gateway / Routing Layer]
    Gateway --> New[Extracted Microservice]
    Gateway --> Mono[Existing Monolith]
```

Requests for the extracted capability are routed to the new service, while the remaining functionality continues in the monolith.

#### Step 4 - Select a suitable first service

Start with a capability that:

- Has a clear boundary.
- Has fewer dependencies.
- Provides business value.
- Can be independently tested.
- Is not the most critical financial transaction.

Notification or reporting is often a safer first extraction than payment processing.

#### Step 5 - Manage data ownership

The target model is database ownership per service. During transition, temporary shared-database access may be unavoidable, but it should be treated as technical debt with a plan to remove it.

For distributed transactions, consider:

- Eventual consistency.
- Saga pattern.
- Transactional outbox.
- Idempotent consumers.
- Dead-letter queues.

#### Step 6 - Choose communication carefully

- REST or gRPC for synchronous requests.
- Azure Service Bus, Event Grid, Event Hubs or Kafka for asynchronous events.

Use timeouts, retries with backoff, circuit breakers and idempotency. Too many synchronous dependencies can cause cascading failures.

#### Step 7 - Independent delivery and observability

Each service should have:

- Independent build and deployment.
- Versioned artifact or container image.
- Unit and integration tests.
- Security scanning.
- Health checks.
- Logs, metrics and traces.
- Service owner and runbook.

### Scenario-based example

> A monolithic monitoring application contained notification logic that delayed releases. We extracted notification processing into a separate service consuming events from Azure Service Bus. The service had its own repository, container image and pipeline. We first mirrored events and compared results, then moved production traffic and removed the old notification component after a stable period.

### Risks to mention

- Wrong service boundaries.
- Shared database remaining forever.
- Increased network latency.
- Distributed transaction complexity.
- More operational overhead.
- Poor observability.
- Too many small services without a business reason.

---

## 2. How will you design a platform for 50 applications without reducing developer productivity?

### Short answer

I would build a self-service platform with secure golden paths, reusable templates, standard pipelines, approved infrastructure modules, centralized observability and automated guardrails. Developers should not need to understand every Azure, Kubernetes, networking and security detail to deploy a standard application.

### Platform design

```mermaid
flowchart TB
    Dev[Developer] --> Portal[Developer Portal / Service Catalogue]
    Portal --> Template[Golden Path Templates]
    Template --> Git[Git Repository]
    Git --> CI[Reusable CI Pipeline]
    CI --> Registry[Artifact / Container Registry]
    CI --> CD[Deployment Pipeline or GitOps]
    CD --> Runtime[AKS / App Service / Container Apps / VMs]
    Runtime --> Obs[Central Observability]
    Runtime --> Sec[Policy, Identity and Security Controls]
```

### Capabilities

1. **Service templates** for web apps, APIs, workers and scheduled jobs.
2. **Self-service environment creation** through Terraform or approved APIs.
3. **Reusable CI/CD workflows** with testing and scanning built in.
4. **Standard secrets integration** with Key Vault and workload identity.
5. **Central logging, metrics and traces** with automatic dashboards.
6. **Service catalogue** with owner, repository, runtime, dependencies and runbook.
7. **Policy guardrails** instead of repeated manual reviews.
8. **Documentation and examples** next to each golden path.
9. **Platform support model** and clear escalation path.
10. **Feedback and product metrics** to improve the platform.

### Developer productivity principle

The platform should provide a paved road, not a locked road. Standard use cases should be very easy. Exceptional use cases can follow an exception process with security and platform review.

### Scenario

> A new API previously required separate tickets for repository, pipeline, namespace, identity, Key Vault access and dashboard. The platform template created all approved components through one request and produced a working development deployment in under an hour.

---

## 3. Have you designed an isolated environment with proper security controls?

### Sample interview answer

Yes. I have worked with architectures where Production and non-production were separated through subscriptions, VNets, subnets, identities and policy boundaries. A typical design used a hub-spoke model with centralized connectivity and security.

```mermaid
flowchart TB
    Corp[Corporate Network] --> ER[VPN / ExpressRoute]
    ER --> Hub[Hub VNet]
    Hub --> FW[Azure Firewall]
    Hub --> DNS[Private DNS Resolver]
    Hub --> Bastion[Azure Bastion]
    FW --> Spoke[Application Spoke VNet]
    Spoke --> App[Application Subnet]
    Spoke --> AKS[AKS Subnet]
    Spoke --> PE[Private Endpoint Subnet]
    PE --> DB[(Private PaaS Database)]
```

### Security measures

#### Subscription and resource isolation

- Separate Production and non-production subscriptions.
- Separate resource groups by lifecycle and ownership.
- Policy and budgets at management-group/subscription scope.

#### Network isolation

- Hub-spoke networking.
- NSGs and UDRs.
- Azure Firewall for controlled egress and inter-spoke flows.
- Private Endpoints for PaaS.
- No public IPs on workload VMs.
- Bastion/VPN/ExpressRoute for administration.
- Private DNS and controlled name resolution.

#### Identity

- Entra ID groups and least-privilege RBAC.
- PIM for elevated access.
- Managed identities/workload identity.
- MFA and Conditional Access.
- No shared administrator accounts.

#### Data and workload

- Key Vault for secrets and certificates.
- Encryption at rest and TLS in transit.
- Backup, retention and recovery testing.
- Private registry and image scanning for containers.

#### Governance and monitoring

- Azure Policy.
- Central diagnostic settings.
- Defender for Cloud.
- Activity Logs and security alerts.
- Change-management and incident procedures.

### Scenario

> A development team needed temporary vendor access. Instead of adding a public IP and broad NSG rule, we used a controlled private access path, time-bound RBAC/PIM and an approved jump mechanism. Access was removed automatically after the support window.

---

## 4. How will you manage multiple environments using Terraform and CI/CD?

### Interview answer

I use reusable, versioned modules and separate deployable root configurations or stacks for Dev, QA, staging and Production. Each environment has separate state, identity, variables and approval controls. The same tested artifact and module version are promoted through environments.

### Repository example

```text
infrastructure/
├── modules/
│   ├── network/
│   ├── aks/
│   ├── app-service/
│   └── monitoring/
└── live/
    ├── dev/
    ├── qa/
    ├── staging/
    └── prod/
```

### Pull-request stages

```text
Format -> Validate -> Lint -> IaC Scan -> Plan -> Review
```

### Deployment stages

```text
Dev Apply -> Test -> QA Apply -> Test -> Production Approval -> Prod Apply -> Validation
```

### Controls

- Separate backend keys/state.
- OIDC or managed identity.
- Environment-specific service connections.
- Protected branches.
- Production approvals.
- No manual environment-specific code copies.
- Drift detection.
- Rollback/recovery plan.

### Scenario

> A module version was tested in Dev, then referenced by QA and Production through an explicit release tag. Production used larger instance sizes through variables but the module logic remained identical.

---

## 5. How will you set up an Internal Developer Platform (IDP)?

### Definition

An Internal Developer Platform is the combination of tools, APIs, templates and workflows that allows developers to build, deploy and operate services through self-service. A developer portal is the user interface; the platform includes all the automation behind it.

### Step-by-step approach

1. Interview developers and measure current delays.
2. Select the highest-value use cases.
3. Define supported golden paths.
4. Build a service catalogue.
5. Create repository and application templates.
6. Build reusable infrastructure modules and pipeline workflows.
7. Integrate identity, Key Vault and short-lived credentials.
8. Integrate monitoring and default alerts.
9. Add policy-as-code and security scans.
10. Document ownership, support and exceptions.
11. Pilot with a few teams.
12. Measure adoption and improve continuously.

### Golden path example

A developer selects “Python API on AKS” and receives:

- Repository.
- Dockerfile.
- Unit-test structure.
- CI pipeline.
- Helm chart.
- Namespace and service account.
- Workload identity.
- Key Vault access pattern.
- Dashboard and alerts.
- Runbook template.

### Platform technology examples

- Backstage or a custom portal.
- Terraform/Bicep and Azure Deployment Environments.
- Azure DevOps or GitHub Actions.
- AKS, App Service or Container Apps.
- Argo CD/Flux for GitOps where appropriate.
- Azure Monitor, Prometheus, Grafana and OpenTelemetry.

### Success measures

- Time to create an environment.
- Lead time for changes.
- Deployment frequency.
- Change failure rate.
- Mean time to recovery.
- Platform adoption.
- Developer satisfaction.
- Number of manual tickets removed.

---

## 6. How will you create a common dashboard for 50 applications?

### Interview answer

I would first define a common telemetry standard. A dashboard cannot be reliable if every application uses different field names, labels and severity formats.

All applications should include metadata such as:

```text
service.name
environment
team
region
version
business_unit
severity
correlation_id
```

### Dashboard layers

#### Executive view

- Overall availability.
- SLO status.
- Critical incidents.
- Production health.
- Deployment/change status.

#### Platform view

- Cluster/node health.
- VM and App Service capacity.
- Network and gateway errors.
- Shared database or messaging health.
- Cost and capacity trends.

#### Application view

- Request rate.
- Error rate.
- P95/P99 latency.
- Dependency failures.
- Exceptions.
- Queue depth.
- Current version.
- Business transaction metrics.

### Tools

- Azure Monitor Workbooks.
- Log Analytics.
- Application Insights.
- Azure Managed Grafana.
- Azure Monitor managed service for Prometheus.
- OpenTelemetry.

### Scenario

> We created a reusable dashboard template that filtered by application, environment and team. Onboarding automation registered the new service, applied standard diagnostic settings and created alerts from the same template.

---

## 7. What metrics will you monitor, and which tools will you use?

### Four golden signals

1. **Latency** - average, P95 and P99 response time.
2. **Traffic** - requests per second, transactions and message rate.
3. **Errors** - 4xx, 5xx, exceptions and dependency failures.
4. **Saturation** - CPU, memory, disk, network, connection pool and queue depth.

### Additional metrics

#### Availability and reliability

- Health-check success.
- Uptime.
- SLI/SLO compliance.
- Error-budget burn.

#### Kubernetes

- Pod restart and CrashLoopBackOff.
- Pending pods.
- OOMKilled.
- CPU throttling.
- Node readiness.
- Replica availability.
- HPA and cluster autoscaler activity.

#### Database

- Query latency.
- Connections.
- Deadlocks.
- Storage growth.
- Replication lag.
- Failed transactions.

#### CI/CD

- Build success rate.
- Pipeline duration.
- Deployment frequency.
- Change failure rate.
- Rollback count.

#### Business

- Orders, alerts, payments or other domain transactions.

### Tools

- Azure Monitor and Log Analytics.
- Application Insights.
- Prometheus and Grafana.
- OpenTelemetry.
- Container Insights.
- Microsoft Sentinel for security signals.
- Teams, ServiceNow or PagerDuty for notifications.

### Interview note

Do not alert on every metric. Alert on conditions that are actionable and tied to user or service impact.

---

## 8. Best practices for managing multiple environments and CI/CD pipelines

### Environment practices

- Separate Production from non-production.
- Use infrastructure as code.
- Maintain separate state and identities.
- Keep naming, tagging and monitoring consistent.
- Store configuration outside application binaries.
- Use Key Vault and workload identity.
- Avoid manual Production changes.
- Define backup, RTO and RPO.
- Control cost with budgets and tagging.

### CI/CD practices

- Pull requests and branch protection.
- Peer review.
- Automated unit, integration and security tests.
- Build once and promote the same immutable artifact.
- Separate build and deploy permissions.
- Short-lived credentials/OIDC.
- Environment approvals.
- Health checks and automatic rollback where supported.
- Reusable pipeline templates.
- Audit logs and artifact retention.

### Build-once principle

```text
Commit -> Build immutable artifact -> Dev -> QA -> Staging -> Production
```

Rebuilding separately in every environment can produce different binaries and weakens traceability.

---

## 9. How will you create a CI/CD pipeline from scratch?

### Step 1 - Understand the application

Determine language, build system, tests, artifact type, target platform, environments, security requirements and rollback method.

### Step 2 - Define source-control rules

- Branching strategy.
- Pull-request requirements.
- Code owners.
- Tagging/versioning.
- Protected branches.

### Step 3 - Create Continuous Integration

```text
Checkout
Restore dependencies
Lint
Unit tests
SAST
Software composition analysis
Build
Package
Container build if required
Image scan
Publish artifact
```

### Step 4 - Create Continuous Delivery/Deployment

```text
Authenticate
Download immutable artifact
Deploy to Dev
Smoke test
Deploy to QA
Integration test
Approval
Deploy to Production
Health validation
Rollback if required
```

### Step 5 - Add security and governance

- OIDC or managed identity.
- Key Vault integration.
- Environment approvals.
- Separation of duties.
- Scan results and evidence retention.
- Change-management integration where required.

### Step 6 - Add observability

Record deployment version, commit SHA, pipeline run ID and release time. Confirm dashboards and alerts after deployment.

### Scenario

> For a Python API, CI ran linting, unit tests, SonarQube analysis, dependency scanning and Docker build. The image was tagged with the commit SHA and pushed to ACR. CD deployed the same image to Dev and QA, then required approval for Production.

---

## 10. How will you troubleshoot CI/CD pipeline logs?

### Systematic approach

1. Find the first failed stage and task.
2. Read upward to the first meaningful error, not only the final summary.
3. Compare with the last successful run.
4. Review the exact commit and pipeline YAML change.
5. Check variables, secret scope and environment selection.
6. Check authentication, RBAC and service connections.
7. Check agent/runner disk, network and tool versions.
8. Check external services such as registries and package feeds.
9. Reproduce the exact command locally or in the same container image.
10. Enable debug logging temporarily without printing secrets.
11. Fix the root cause and add a preventive validation.

### Common categories

- YAML syntax or condition error.
- Wrong working directory.
- Dependency version change.
- Expired secret/certificate.
- OIDC trust mismatch.
- Insufficient RBAC.
- Agent unavailable or disk full.
- Firewall/DNS failure.
- Artifact not found.
- Environment approval waiting.
- Terraform state lock.

### Scenario

> Terraform init failed with 403. The service connection had Contributor but lacked Blob data access to the state container. We assigned the required data-plane role and documented the backend permission requirement.

---

## 11. How will you design centralized monitoring from scratch?

### Step 1 - Define outcomes

Clarify applications, platforms, SLOs, retention, compliance, on-call process, severity model and cost constraints.

### Step 2 - Define telemetry standards

- Structured logs.
- Metrics.
- Distributed traces.
- Health endpoints.
- Correlation IDs.
- Standard application/environment labels.

### Step 3 - Collection architecture

```mermaid
flowchart LR
    Apps[Apps / VMs / AKS / Azure Resources] --> Collect[Azure Monitor Agent / OpenTelemetry / Prometheus]
    Collect --> LA[Log Analytics]
    Collect --> AI[Application Insights]
    Collect --> Prom[Managed Prometheus]
    LA --> Dash[Workbooks / Grafana]
    AI --> Dash
    Prom --> Dash
    Dash --> Alert[Azure Monitor Alerts]
    Alert --> Notify[Teams / ITSM / PagerDuty]
```

### Step 4 - Configure data sources

- Azure Activity Logs.
- Resource diagnostic settings.
- Azure Monitor Agent and Data Collection Rules.
- VM Insights.
- Application Insights/OpenTelemetry.
- AKS control-plane and container logs.
- Managed Prometheus metrics.

### Step 5 - Design workspaces and access

Choose workspace boundaries based on data residency, access isolation, retention, ownership and cost. Do not create one workspace per small app without a valid need.

### Step 6 - Dashboards and alerts

Create platform, application, security, cost and executive views. Route alerts by owner, environment and severity. Every alert should have an owner and runbook.

### Step 7 - Cost and retention

Filter noisy logs, use sampling where appropriate, review ingestion, archive long-term data and protect critical audit sources from accidental caps.

### Step 8 - Test

Inject controlled failures, validate alert timing and routing, and run incident simulations.

---

## 12. How will you implement security for an AKS cluster?

### Layer 1 - Identity and cluster access

- Integrate with Entra ID.
- Use Kubernetes RBAC or Azure RBAC as designed.
- Disable or restrict local accounts where appropriate.
- Use PIM and least privilege.
- Use workload identity for pods.
- Avoid static service-principal secrets.

### Layer 2 - Private networking

- Use a private cluster for sensitive workloads.
- Restrict API server access.
- Use separate subnets/node pools as required.
- Apply network policies.
- Use Private Link for ACR/Key Vault and other services where required.
- Control outbound traffic through firewall or approved egress design.
- Use internal load balancers for private services.

### Layer 3 - Workload isolation

- Namespaces by team/application/environment.
- ResourceQuota and LimitRange.
- NetworkPolicy.
- Pod Security standards or equivalent admission controls.
- Separate system and user node pools.

### Layer 4 - Secrets

- Azure Key Vault.
- Secrets Store CSI Driver.
- Workload identity.
- Rotation and no secrets in manifests or images.

### Layer 5 - Container and pod security

- Private ACR.
- Scan images.
- Use minimal trusted base images.
- Run as non-root.
- Read-only root filesystem where possible.
- Drop unnecessary Linux capabilities.
- No privileged containers unless specifically approved.
- Resource requests and limits.
- Seccomp/AppArmor where supported.

### Layer 6 - Admission and policy

Use Azure Policy for AKS, Gatekeeper or Kyverno to enforce requirements such as:

- Approved registries only.
- No privileged containers.
- Required resource limits.
- Required labels.
- Non-root execution.
- No host networking/hostPath without exception.

### Layer 7 - Node and lifecycle security

- Supported Kubernetes version.
- Planned cluster and node-image upgrades.
- Restricted SSH.
- No public node IPs.
- Backup and recovery tests.
- Defender for Containers.

### Layer 8 - Monitoring

- Kubernetes audit and control-plane logs.
- Container Insights.
- Prometheus/Grafana.
- Alerts for new cluster-admin bindings, privileged pods, unusual restarts and suspicious outbound traffic.

### Scenario

> A pod needed access to a Storage Account. Instead of placing an account key in a Kubernetes Secret, we created a federated identity, assigned the minimum storage data role and configured workload identity. The pod received a short-lived token without storing a client secret.

---

# TCS Azure Infrastructure, Terraform and Core DevOps Round

The following questions were collected from a TCS Azure DevOps interview round. They are kept in this same chapter so that all TCS questions remain in one place. The answers are written in simple language, but they also include the design points and troubleshooting order expected from an experienced engineer.

---

## 13. Once you design an Azure Landing Zone, what are the components?

### Short interview answer

An Azure Landing Zone is not one Azure resource. It is the complete governed foundation used to host workloads. Its main components are tenant and billing setup, management groups, subscriptions, identity and access, network connectivity, security, Azure Policy, monitoring, management services, and infrastructure automation.

### Detailed answer

I normally explain the Landing Zone through the following components:

1. **Microsoft Entra tenant and billing scope**
   - Tenant structure, billing ownership and administrative boundaries.
   - Emergency-access accounts and tenant-level security controls.

2. **Management-group hierarchy**
   - Platform, Landing Zones, Sandbox and Decommissioned management groups.
   - Used to inherit policy and RBAC consistently across subscriptions.

3. **Subscription design**
   - Connectivity subscription.
   - Management or operations subscription.
   - Identity/shared-services subscription when required.
   - Separate workload subscriptions for Production and non-production.

4. **Identity and access management**
   - Entra ID groups rather than direct user assignments.
   - Least-privilege RBAC.
   - PIM for elevated roles.
   - Managed identities for workloads.
   - Conditional Access and MFA for administrators.

5. **Network topology and connectivity**
   - Hub-and-spoke or Azure Virtual WAN.
   - VPN or ExpressRoute for hybrid access.
   - Azure Firewall, NAT Gateway, Private DNS Resolver and Bastion.
   - Private Endpoints for PaaS services.
   - Non-overlapping IP address plan.

6. **Governance**
   - Azure Policy definitions and initiatives.
   - Allowed regions and SKUs.
   - Mandatory tags and diagnostic settings.
   - Public-access restrictions.
   - Resource locks where justified.

7. **Security**
   - Defender for Cloud.
   - Key Vault and encryption controls.
   - Network segmentation.
   - Vulnerability and compliance monitoring.
   - Central security logging and incident integration.

8. **Management and operations**
   - Azure Monitor, Log Analytics, alerts and Service Health.
   - Backup, disaster recovery, patching and automation.
   - Cost Management, budgets and ownership tags.

9. **Platform automation and DevOps**
   - Terraform or Bicep modules.
   - CI/CD pipelines, pull requests and approvals.
   - Subscription vending and automated workload onboarding.
   - Drift detection and controlled remediation.

10. **Application landing zones**
    - Workload subscriptions connected to the shared platform.
    - Application-specific networking, compute, data, identity and monitoring.

### Architecture example

```mermaid
flowchart TB
    Tenant[Microsoft Entra Tenant] --> Root[Organization Management Group]
    Root --> Platform[Platform]
    Root --> LZ[Landing Zones]
    Root --> Sandbox[Sandbox]
    Platform --> Conn[Connectivity Subscription]
    Platform --> Mgmt[Management Subscription]
    Platform --> Identity[Identity / Shared Services]
    LZ --> Corp[Corp Workload Subscriptions]
    LZ --> Online[Online Workload Subscriptions]
    Conn --> Hub[Hub VNet / vWAN / Firewall / DNS]
    Mgmt --> Monitor[Monitor / Log Analytics / Automation]
    Corp --> Spoke1[Application Spoke]
    Online --> Spoke2[Internet-facing Application Spoke]
```

### Scenario-based example

> A company had every application in one subscription with inconsistent NSGs and no central logging. We created a management-group hierarchy, separate platform subscriptions, workload subscriptions, hub-spoke networking, policy initiatives and a central Log Analytics workspace. Terraform and a pipeline then applied the same controls whenever a new subscription was onboarded.

### Interview tip

Do not describe Landing Zone only as a VNet, resource group or subscription. It is an operating model and governed Azure foundation covering all major design areas.

---

## 14. After the Landing Zone is designed and created, what is the next step before deployment?

### Short interview answer

Before deploying business workloads, I validate that the Landing Zone is operationally ready. I test policy, identity, network routes, DNS, security, logging, backup, cost controls and the deployment pipeline in a pilot subscription. After sign-off, I onboard the workload subscription and deploy through the approved IaC pipeline.

### Readiness sequence

1. **Architecture and security approval**
   - Confirm that the implementation matches the approved design.
   - Record accepted risks and required exceptions.

2. **Policy validation**
   - Check inherited policies at management-group and subscription scope.
   - Test both compliant and non-compliant deployments.
   - Verify remediation identities for `DeployIfNotExists` policies.

3. **Identity validation**
   - Test platform, security and workload-team RBAC.
   - Confirm PIM activation and emergency-access procedure.
   - Ensure pipeline identity has only the permissions it requires.

4. **Network and DNS testing**
   - Validate VNet peering or Virtual WAN connectivity.
   - Test UDRs, firewall rules, private endpoints and DNS resolution.
   - Verify inbound, outbound and on-premises connectivity.

5. **Operational controls**
   - Confirm diagnostic settings, Log Analytics ingestion and alerts.
   - Validate backup, update management, recovery procedures and budgets.
   - Ensure owner, environment and cost-centre tags are present.

6. **IaC and pipeline validation**
   - Run formatting, validation, security scanning and a reviewed plan.
   - Test deployment first in a non-production or pilot subscription.
   - Confirm state backend, locking, approvals and rollback procedure.

7. **Subscription vending and workload onboarding**
   - Place the subscription under the correct management group.
   - Apply standard RBAC, budgets, policies, networking and logging.
   - Hand over the approved landing zone to the workload team.

8. **Deployment readiness sign-off**
   - Obtain platform, networking, security and application-team approval.
   - Deploy the workload using the same tested pipeline and module versions.

### Scenario

> Before deploying a Production application, our pilot found that the private DNS zone was linked only to the hub VNet and not resolvable through the custom DNS path used by the spoke. We corrected the forwarding rule and tested resolution before deployment. This avoided a Production outage on the first release.

### Strong answer line

“Creation of the Landing Zone is not the end. The next step is validation, operational readiness and controlled workload onboarding.”

---

## 15. What is Azure Application Gateway?

### Short interview answer

Azure Application Gateway is a managed Layer 7 web traffic load balancer. It routes HTTP and HTTPS requests using host names, URL paths and headers. It supports TLS termination, health probes, autoscaling, zone redundancy and Web Application Firewall protection.

### Main components

- **Frontend IP configuration:** Public, private, or both depending on the design.
- **Listener:** Receives traffic for a protocol, port, host name and certificate.
- **Backend pool:** Contains VM, VMSS, IP address, FQDN or supported PaaS targets.
- **Backend settings:** Defines protocol, port, timeout, host-name behaviour and probe.
- **Health probe:** Determines which backend targets are healthy.
- **Routing rule:** Connects a listener to a backend pool and backend settings.
- **WAF policy:** Protects against common web attacks when using WAF_v2.
- **Rewrite, redirect and path rules:** Modify or route requests based on application requirements.

### When I use it

- Web applications that need Layer 7 routing.
- TLS termination or end-to-end TLS.
- Path-based routing such as `/api` and `/images`.
- Multi-site hosting for multiple domains.
- WAF protection.
- Cookie-based session affinity when an application requires it.

### Application Gateway versus Azure Load Balancer

| Application Gateway | Azure Load Balancer |
|---|---|
| Layer 7 | Layer 4 |
| HTTP, HTTPS and web-aware routing | TCP and UDP distribution |
| Host/path-based rules | IP, port and protocol rules |
| WAF support | No web application firewall |
| TLS termination | Not an HTTP/TLS termination service |

### Scenario

> A company hosts `portal.contoso.com` and `api.contoso.com` on different backend pools. I create multi-site listeners, associate TLS certificates and route each host to the correct healthy backend. WAF is enabled for internet-facing traffic.

### Current interview note

For new Production designs, discuss the v2 generation, such as Standard_v2 or WAF_v2. Application Gateway v1 support ended in April 2026.

---

## 16. What are the steps to configure Azure Application Gateway?

### Interview-ready sequence

1. **Collect requirements**
   - Public or private frontend.
   - Domains, ports, protocols and certificate ownership.
   - Backend targets, health endpoint, expected traffic and WAF requirement.

2. **Prepare networking**
   - Create or select a VNet.
   - Create a dedicated Application Gateway subnet.
   - Confirm address capacity, DNS, UDR and NSG design.
   - Do not place ordinary workload resources in the gateway subnet.

3. **Choose the SKU and capacity model**
   - Standard_v2 for Layer 7 load balancing without WAF.
   - WAF_v2 when web application firewall protection is required.
   - Configure autoscaling and availability-zone settings where supported.

4. **Configure frontend IP**
   - Public IP for internet-facing access.
   - Private IP for internal access.
   - Both when the design requires separate listeners.

5. **Create the backend pool**
   - Add VM NICs, VMSS, private IPs, FQDNs or supported App Service targets.
   - Confirm that DNS resolves from the Application Gateway environment.

6. **Create backend settings**
   - HTTP or HTTPS protocol.
   - Backend port.
   - Request timeout.
   - Host-name override and SNI settings when required.
   - Trusted root certificates for private CA backends when required.

7. **Create a custom health probe**
   - Use an endpoint such as `/health` that checks application readiness.
   - Set protocol, host, path, interval, timeout and unhealthy threshold.
   - Do not use a path that redirects to login or depends on external services unnecessarily.

8. **Create listeners**
   - Select frontend IP, port and protocol.
   - Add host name for multi-site routing.
   - Bind the TLS certificate for HTTPS.

9. **Create routing rules**
   - Basic rule for one backend.
   - Path-based rule for routes such as `/api/*` and `/static/*`.
   - Associate listener, backend pool, backend settings and probe.

10. **Configure WAF and TLS security**
    - Attach a WAF policy.
    - Start in Detection mode for tuning, then move to Prevention after review.
    - Configure exclusions only with evidence and approval.

11. **Configure DNS**
    - Point the application DNS record to the gateway public IP or private frontend name/IP as appropriate.

12. **Enable diagnostics and alerts**
    - Send access, performance, firewall and health data to Log Analytics.
    - Alert on unhealthy backends, failed requests and capacity issues.

13. **Test before go-live**
    - Check Backend Health.
    - Test each listener, host and path.
    - Validate certificate chain, redirects, headers and WAF behaviour.
    - Test backend failure and recovery.

### Troubleshooting checks

```bash
# Test the backend directly from a permitted test host
curl -vk https://backend.example.internal/health

# Confirm name resolution
nslookup backend.example.internal
```

In Azure Portal, review:

```text
Application Gateway -> Backend health
Application Gateway -> Diagnostic settings
Log Analytics -> ApplicationGatewayAccessLog / Firewall logs
```

### Scenario

> Backend Health showed `Unhealthy` because the probe used `/`, which redirected to an authentication page and returned an unexpected response. We created a dedicated `/health` endpoint returning HTTP 200, updated the custom probe and validated the backend before enabling Production traffic.

---

## 17. What are the types of Azure Load Balancer?

### Direct interview answer

By traffic exposure, Azure Load Balancer has two main types:

1. **Public Load Balancer**, sometimes called an external load balancer.
2. **Internal Load Balancer**, which uses a private frontend IP.

For modern Production workloads, use **Standard Load Balancer**. Basic Load Balancer was retired in September 2025. Azure also provides **Gateway Load Balancer** for chaining supported network virtual appliances.

### Types by exposure

#### Public Load Balancer

- Has a public frontend IP.
- Distributes internet-originated TCP or UDP traffic.
- Can also participate in explicit outbound connectivity when correctly configured.
- Used for non-HTTP workloads or simple Layer 4 balancing.

#### Internal Load Balancer

- Has a private frontend IP from a subnet.
- Reachable from the VNet, peered networks or connected on-premises networks.
- Used for internal APIs, middleware and private application tiers.

### Other classification interviewers may expect

- **Standard Load Balancer:** Production-grade regional load balancer.
- **Gateway Load Balancer:** Inserts and scales network virtual appliances transparently.
- **Regional or global tier:** Public Standard Load Balancer can be used in regional designs, and cross-region load-balancing capabilities are available for supported global designs.

### Scenario

> For a public website needing WAF and URL routing, I would choose Application Gateway rather than Load Balancer. For a TCP service listening on port 8443 across two VMs, a Standard Public Load Balancer can be appropriate. For an internal database proxy tier, I would use a Standard Internal Load Balancer.

---

## 18. What are the types of Azure Storage Account?

### Current recommended account types

1. **Standard general-purpose v2 (StorageV2)**
   - Recommended for most workloads.
   - Supports Blob, Data Lake Storage capabilities, Queue, Table and Azure Files.
   - Supports several redundancy choices depending on region and feature.

2. **Premium block blobs (BlockBlobStorage)**
   - Premium SSD-backed account for block and append blobs.
   - Suitable for high transaction rates, small objects and consistent low latency.

3. **Premium file shares (FileStorage)**
   - Premium account for Azure Files.
   - Supports high-performance SMB and supported NFS file-share scenarios.

4. **Premium page blobs**
   - Premium account focused on page-blob workloads requiring low latency and high performance.

### Do not confuse three different concepts

| Concept | Examples |
|---|---|
| Storage account type | GPv2, premium block blob, premium file share, premium page blob |
| Redundancy | LRS, ZRS, GRS, RA-GRS, GZRS, RA-GZRS |
| Blob access tier | Hot, Cool, Cold, Archive where supported |

### Legacy types

General-purpose v1 and legacy Blob Storage accounts should not be selected for new deployments. Modern designs normally use GPv2 unless a premium specialized account is required.

### Scenario

> A general application needs blobs, queues and file shares. I choose Standard GPv2. A latency-sensitive workload performs a large number of small block-blob operations, so I evaluate Premium Block Blob Storage. A high-performance shared file system requirement may justify Premium File Shares.

### Security points to mention

- Disable public network access when not required.
- Use Private Endpoints and correct Private DNS zones.
- Use Entra ID and data-plane RBAC instead of long-lived account keys where possible.
- Enable soft delete, versioning and lifecycle management according to recovery requirements.
- Send diagnostic logs and security alerts to central monitoring.

---

## 19. What is the difference between `terraform plan` and `terraform apply`?

### Short answer

`terraform plan` previews the changes Terraform proposes. It does not normally change infrastructure. `terraform apply` executes an approved plan and changes the real infrastructure and state.

### Detailed comparison

| `terraform plan` | `terraform apply` |
|---|---|
| Reads configuration, state and provider data | Executes create, update and delete operations |
| Shows expected changes | Changes real resources |
| Used during pull request and review | Used after approval in a controlled deployment stage |
| Can save a plan using `-out` | Can apply that saved plan file |
| Helps find unexpected replacement or deletion | Must be protected by permissions and approvals |

### Recommended pipeline pattern

```bash
terraform init
terraform fmt -check -recursive
terraform validate
terraform plan -out=tfplan
terraform show tfplan
terraform apply tfplan
```

Applying the reviewed saved plan is stronger than running a fresh unreviewed `terraform apply -auto-approve`, because the saved plan represents the exact actions that were approved. However, the plan file can contain sensitive values and must be stored as a protected short-lived artifact.

### Scenario

> A plan showed that changing a subnet property would force replacement of a dependent resource. Because the plan ran during the pull request, we stopped the deployment, redesigned the change and avoided Production downtime. If we had run apply directly, the destructive action might have started before review.

### Interview tip

State that `terraform apply` without a saved plan creates a fresh plan and asks for confirmation. In automation, use a reviewed saved plan or a tightly controlled apply stage.

---

## 20. What is `provider.tf`, and what is configured in it?

### Short answer

`provider.tf` is a common file name used to keep provider requirements and provider configuration. The name is only a convention; Terraform loads all `.tf` files in the root module together.

### Typical content

```hcl
terraform {
  required_version = ">= 1.8.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 3.0"
    }
  }
}

provider "azurerm" {
  features {}

  # Prefer workload identity, managed identity or environment variables.
  # Do not hard-code client secrets here.
}

provider "azuread" {}
```

### What can be configured

- Required Terraform version.
- Required provider source and version constraints.
- AzureRM provider features.
- Subscription or tenant selection when the authentication model requires it.
- Provider aliases for multiple subscriptions or regions.
- Special provider settings.

### Multi-subscription example

```hcl
provider "azurerm" {
  features {}
  alias           = "connectivity"
  subscription_id = var.connectivity_subscription_id
}

provider "azurerm" {
  features {}
  alias           = "workload"
  subscription_id = var.workload_subscription_id
}

module "hub" {
  source = "../../modules/hub"

  providers = {
    azurerm = azurerm.connectivity
  }
}
```

### What should not be hard-coded

- Client secrets.
- Passwords.
- Access tokens.
- Storage account keys.
- Production tenant details in a reusable public module.

Use workload identity federation, managed identity, Azure CLI authentication for local development, or protected pipeline variables as appropriate.

### Important distinction

Backend configuration is commonly kept in `backend.tf`, although Terraform does not require that filename either. Provider configuration tells Terraform how to interact with Azure; backend configuration tells Terraform where to store state.

---

## 21. Is a Public IP associated at the Subnet level or the VNet level?

### Correct answer

A Public IP is not directly associated with a VNet or subnet.

It is associated with a specific Azure resource or frontend configuration, for example:

- A VM network-interface IP configuration.
- A Public Load Balancer frontend.
- An Application Gateway frontend.
- A NAT Gateway.
- Azure Firewall.
- VPN Gateway.
- Azure Bastion.

### Important NAT Gateway clarification

A public IP or public IP prefix is attached to the **NAT Gateway**. The NAT Gateway is then associated with one or more subnets. Therefore, outbound internet access is applied at subnet level through NAT Gateway, but the Public IP is still attached to the NAT Gateway resource, not directly to the subnet.

### Scenario

> Ten private VMs should use one predictable outbound address. I do not attach a public IP to every NIC. I attach a Public IP Prefix to a NAT Gateway and associate the NAT Gateway with the VM subnet.

### Strong one-line answer

“VNets and subnets hold private address ranges; public IP resources attach to resource frontends or IP configurations.”

---

## 22. What is a branching strategy in DevOps?

### Short interview answer

A branching strategy defines how a team creates, protects, merges and releases Git branches. Its purpose is to support parallel development while keeping the main branch stable and making releases traceable.

### Common strategies

#### Trunk-based development

- Developers create short-lived feature branches from `main`.
- Changes merge frequently through pull requests.
- Main remains buildable and deployable.
- Feature flags hide incomplete functionality.
- Suitable for frequent CI/CD and modern product teams.

#### GitHub Flow

- Simple main branch plus short-lived branches.
- Pull request, review, automated checks and merge.
- Often used for continuously delivered applications.

#### GitFlow

- Uses `main`, `develop`, feature, release and hotfix branches.
- Can suit products with scheduled releases.
- Creates more branch-management and merge overhead.

#### Release-branch strategy

- Main is used for ongoing development.
- A release branch is created for stabilization and Production fixes.
- Critical fixes may be cherry-picked between release and main branches.

### Recommended Azure DevOps pattern for many teams

```text
main                     Protected and always deployable
feature/<work-item>      Short-lived development branch
release/<version>        Only when a supported release needs stabilization
hotfix/<incident>        Urgent Production fix
```

Branch policies should include:

- No direct push to `main`.
- Required reviewers.
- Successful CI build.
- Unit and security checks.
- Linked work item when required.
- Comment resolution.
- Optional code-owner approval for sensitive files.

### Scenario

> A team kept feature branches open for two months, causing large merge conflicts. We moved to short-lived branches, smaller pull requests and frequent integration. CI ran on every pull request, and feature flags allowed incomplete features to merge safely without being visible to users.

---

## 23. What is the difference between CI and CD?

### Short answer

**CI** automatically integrates, builds and tests code changes. **CD** takes the validated artifact and delivers or deploys it through environments.

### Detailed explanation

#### Continuous Integration

Typical stages:

```text
Checkout -> Restore dependencies -> Lint -> Unit test -> Security scan -> Build -> Publish artifact
```

Purpose:

- Detect code and integration problems early.
- Keep the main branch healthy.
- Produce a versioned immutable artifact.

#### Continuous Delivery

- Automatically deploys the artifact to test or staging environments.
- Keeps the release ready for Production.
- Production may require a manual approval or business decision.

#### Continuous Deployment

- Every change that passes all automated checks is automatically deployed to Production.
- Requires mature testing, observability, rollback and risk controls.

### Scenario

> A pull request triggers CI, which runs unit tests, SonarQube and a container build. After merge, CD deploys the same image digest to Dev, QA and Production. Production requires an environment approval. Because the artifact is built only once, all environments receive identical code.

### Interview wording

“CI produces confidence and a deployable artifact; CD moves that artifact safely through environments.”

---

## 24. How do you configure a Subnet in Azure? Explain the step-by-step process.

### Step 1 - Plan the address space

- Select a VNet address range that does not overlap with connected VNets or on-premises networks.
- Estimate current and future IP usage.
- Reserve dedicated ranges for services such as Application Gateway, Azure Bastion, gateways, AKS and private endpoints where appropriate.
- Remember that Azure reserves five addresses in every subnet.

Example:

```text
VNet:              10.20.0.0/16
Application:       10.20.1.0/24
Database/Private:  10.20.2.0/24
Application GW:    10.20.10.0/24
Azure Bastion:     10.20.20.0/26
```

### Step 2 - Create or select the VNet

Azure Portal:

```text
Virtual networks -> Select VNet -> Subnets -> + Subnet
```

### Step 3 - Configure subnet properties

- Name.
- IPv4/IPv6 address range as required.
- Private/default-outbound setting according to the current network design.
- Network Security Group.
- Route table.
- NAT Gateway.
- Service endpoints, only when intentionally selected.
- Delegation for services that require a delegated subnet.
- Private endpoint network policies when the design requires NSG/UDR enforcement.

### Step 4 - Review dependencies

Before saving, confirm:

- Address prefix is inside the VNet and does not overlap another subnet.
- Required service has the correct subnet name and minimum size.
- NSG rules do not block platform-required traffic.
- UDR does not create a routing loop or black hole.
- DNS and outbound path are defined.

### Step 5 - Create using Azure CLI

```bash
az network vnet subnet create \
  --resource-group rg-network-prod \
  --vnet-name vnet-hub-prod \
  --name snet-app-prod \
  --address-prefixes 10.20.1.0/24 \
  --network-security-group nsg-app-prod \
  --route-table rt-app-prod
```

### Step 6 - Create using Terraform

```hcl
resource "azurerm_subnet" "app" {
  name                 = "snet-app-prod"
  resource_group_name  = azurerm_resource_group.network.name
  virtual_network_name = azurerm_virtual_network.main.name
  address_prefixes     = ["10.20.1.0/24"]
}

resource "azurerm_subnet_network_security_group_association" "app" {
  subnet_id                 = azurerm_subnet.app.id
  network_security_group_id = azurerm_network_security_group.app.id
}

resource "azurerm_subnet_route_table_association" "app" {
  subnet_id      = azurerm_subnet.app.id
  route_table_id = azurerm_route_table.app.id
}
```

### Step 7 - Validate

- Review effective routes and effective security rules on a test NIC.
- Test DNS and connectivity using Network Watcher.
- Confirm NAT or firewall egress if the subnet is private.
- Deploy a small test resource before placing a critical workload.

### Scenario

> A subnet was created with a `/28` range and later used for a service that needed many more addresses. Expansion was difficult because the next address range was already occupied. The prevention is proper capacity planning and reserving sufficiently sized, non-overlapping ranges before deployment.

---

## 25. What is an External Load Balancer?

### Correct Azure term

In Azure, an External Load Balancer normally means a **Public Load Balancer**.

### Explanation

It is a managed Layer 4 load balancer with a public frontend IP. It distributes inbound TCP or UDP connections to healthy backend resources using load-balancing rules and health probes.

### Main components

- Public frontend IP configuration.
- Backend pool.
- Health probe.
- Load-balancing rule.
- Inbound NAT rules when administrative port mapping is required.
- Outbound rules when that design is selected.

### When to use it

- Internet-facing TCP or UDP applications.
- Non-HTTP protocols.
- Applications that do not need WAF, path routing or TLS termination at the load balancer.

### When not to use it

For a web application requiring host-based routing, path-based routing, TLS policy or WAF, use Application Gateway or Azure Front Door depending on regional/global requirements.

### Scenario

> Two VMs host a public TCP service on port 443 but TLS terminates inside the application and no Layer 7 routing is required. A Standard Public Load Balancer uses a public frontend, a TCP health probe and a rule forwarding port 443 to the healthy backend VMs.

---

## 26. What is an Internal Load Balancer, and when do you use it?

### Short interview answer

An Internal Load Balancer is an Azure Load Balancer with a private frontend IP. It distributes TCP or UDP traffic to backend instances without exposing the service directly to the public internet.

### Common use cases

- Internal APIs and middleware.
- Database proxy or application tiers.
- Private services used by other spokes.
- Applications accessed from on-premises through VPN or ExpressRoute.
- Internal Kubernetes services.

### Traffic path

```mermaid
flowchart LR
    Client[Client in VNet / Peered VNet / On-premises] --> ILB[Internal Load Balancer - Private IP]
    ILB --> VM1[Backend VM 1]
    ILB --> VM2[Backend VM 2]
```

### Configuration points

- Select an unused private frontend IP from the subnet.
- Configure backend pool membership.
- Create a health probe.
- Create TCP/UDP load-balancing rules.
- Permit required traffic in subnet/NIC NSGs.
- Ensure UDRs and firewalls allow the return path.
- Create private DNS records so clients do not depend on the raw IP.

### Scenario

> A frontend tier needs to call two backend API VMs, but the API must never be internet-accessible. We use an Internal Standard Load Balancer with a private DNS record such as `api.internal.contoso.com` and permit only the frontend subnet in the backend NSG.

---

## 27. If you need to modify an application running inside a VM, what precautions should you take?

### Strong interview answer

I avoid making an uncontrolled direct change on a Production VM. I first confirm the change request, test the change in a lower environment, create a rollback plan, protect data and configuration, remove the instance from live traffic, deploy through automation, validate health and then restore traffic gradually.

### Precautions

1. **Understand the change**
   - Confirm the exact code, package, configuration or certificate being changed.
   - Identify dependencies, ports, services and restart requirements.

2. **Follow change management**
   - Approved ticket and implementation plan.
   - Maintenance window when required.
   - Communication to application owner and support teams.

3. **Test in Dev/QA first**
   - Use the same OS, runtime and deployment process as Production.
   - Capture test evidence and expected results.

4. **Back up safely**
   - Back up application configuration and data.
   - Use Azure Backup or application-consistent backup where required.
   - A disk snapshot can help in some cases, but it is not automatically application-consistent for a busy database.

5. **Prepare rollback**
   - Previous artifact/package version.
   - Previous configuration and certificate.
   - Restore procedure and decision point.

6. **Protect live traffic**
   - Drain or remove the VM from Application Gateway/Load Balancer rotation.
   - Verify another healthy instance can handle traffic.
   - Avoid single-instance in-place changes when high availability is required.

7. **Protect secrets and permissions**
   - Do not copy secrets into scripts or logs.
   - Use Key Vault/managed identity and least privilege.
   - Verify file ownership and service-account permissions.

8. **Deploy predictably**
   - Prefer CI/CD, configuration management or an immutable-image pattern.
   - Log exact commands and versions.

9. **Validate**
   - Service status, port listening, health endpoint, logs and dependencies.
   - Functional smoke test and performance check.

10. **Return traffic gradually and monitor**
    - Add the instance back to the backend pool.
    - Confirm probe health.
    - Watch errors, latency, CPU and memory.

### Scenario

> We needed to update a Python package on two backend VMs. We updated one VM at a time. The first VM was drained from Application Gateway, backed up, updated through the pipeline and smoke-tested. After the probe became healthy and logs were normal, we repeated the process on the second VM. This preserved service availability and provided a clear rollback path.

### Modern-design note

For mature environments, rebuild and redeploy an immutable VM image or use a platform such as VMSS, containers or App Service instead of repeatedly changing long-lived Production servers by hand.

---

## 28. If a VM cannot communicate with the Internet, what could be the possible reasons?

### Possible causes

1. No explicit outbound method such as NAT Gateway, Azure Firewall, Load Balancer outbound rule or instance public IP.
2. The VM is in a private subnet and default outbound access is disabled.
3. NSG outbound rule is denying the destination or port.
4. A UDR sends `0.0.0.0/0` to an unavailable firewall/NVA.
5. Azure Firewall or NVA application/network rule denies the traffic.
6. DNS resolution is failing.
7. Guest OS firewall, proxy or route configuration is wrong.
8. NIC, IP configuration or subnet association is incorrect.
9. NAT/SNAT ports are exhausted during high connection volume.
10. The remote site blocks the Azure outbound IP.
11. A forced-tunnelling path depends on an unavailable on-premises proxy/firewall.
12. The VM is unhealthy, has no valid default route, or the required service endpoint is down.

### Troubleshooting order

#### Step 1 - Test DNS separately from TCP

Linux:

```bash
ip address
ip route
cat /etc/resolv.conf
nslookup www.microsoft.com
curl -Iv --connect-timeout 10 https://www.microsoft.com
```

Windows:

```powershell
ipconfig /all
route print
Resolve-DnsName www.microsoft.com
Test-NetConnection www.microsoft.com -Port 443
```

If DNS fails but connecting to a known IP/port works, focus on DNS. If DNS resolves but TCP fails, focus on routing, NSG, firewall or remote filtering.

#### Step 2 - Check Azure effective configuration

- NIC -> Effective security rules.
- NIC -> Effective routes.
- Subnet -> NAT Gateway association.
- Route table -> `0.0.0.0/0` next hop.
- Firewall logs and policy rules.
- Network Watcher -> Connection troubleshoot.

#### Step 3 - Confirm explicit outbound design

For new/private subnet designs, use a supported explicit path:

- NAT Gateway for scalable direct outbound SNAT.
- Azure Firewall/NVA for inspected outbound traffic.
- Standard Load Balancer outbound rules when that architecture requires them.
- Direct Public IP only when explicitly approved.

#### Step 4 - Check return path and remote allowlisting

- Confirm the remote service allows the actual outbound public IP.
- Check for asymmetric routing through multiple firewalls.
- Review SNAT usage when many short-lived connections are created.

### Scenario

> A VM lost internet access after the subnet was changed to private. NSG and DNS were correct, but no explicit outbound method existed. We associated a NAT Gateway with the subnet, verified the expected outbound public IP and updated the vendor allowlist.

### Current Azure point

Modern Azure network designs should not depend on implicit default outbound access. Explicit outbound connectivity is more predictable, auditable and secure.

---

## 29. Scenario-based Docker interview questions

### Scenario 1 - The container starts and exits immediately

**Possible cause:** The main process completed or crashed. A container runs only while its PID 1 process is running.

**Checks:**

```bash
docker ps -a
docker logs <container>
docker inspect <container>
```

**Resolution:** Correct `ENTRYPOINT`/`CMD`, run the application in the foreground, fix missing configuration and confirm exit code.

---

### Scenario 2 - The application works inside the container but is not reachable from the host

**Possible causes:**

- Port was not published.
- Application listens on `127.0.0.1` rather than `0.0.0.0`.
- Wrong container port.
- Host firewall or NSG blocks traffic.

**Checks:**

```bash
docker ps
docker port <container>
docker exec <container> ss -lntp
curl -v http://localhost:8080
```

**Correct run example:**

```bash
docker run -d --name web -p 8080:80 myimage:1.0
```

---

### Scenario 3 - The image works on a developer laptop but fails in CI

**Possible causes:**

- Files excluded by `.dockerignore`.
- Build depends on an uncommitted local file.
- Different CPU architecture.
- Missing registry credentials or proxy settings.
- Different Docker/BuildKit behaviour.
- Secret was available locally but not securely passed in CI.

**Approach:** Reproduce with the same Dockerfile, build context, target platform and build arguments used by CI. Do not solve it by copying secrets into the image.

---

### Scenario 4 - Container running as non-root gets permission denied

**Cause:** The application user cannot write to the required directory or bind to a privileged port.

**Secure fix:** Create the directory during build, set ownership, use a non-privileged port and run as a specific UID.

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY --chown=10001:10001 . /app
RUN mkdir -p /app/data && chown -R 10001:10001 /app
USER 10001
EXPOSE 8080
CMD ["python", "app.py"]
```

Do not fix it by running the entire container as root unless there is a documented exceptional requirement.

---

### Scenario 5 - Docker image is too large and deployments are slow

**Improvements:**

- Use multi-stage builds.
- Use a smaller supported runtime image.
- Copy only required files.
- Clean package-manager caches in the same layer.
- Use `.dockerignore`.
- Order layers to improve cache reuse.
- Remove compilers and build tools from the runtime stage.

```dockerfile
FROM node:22 AS build
WORKDIR /src
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /src/dist /usr/share/nginx/html
```

Minimal images reduce attack surface, but the team must still patch and scan them.

---

### Scenario 6 - Trivy blocks the image because of a critical vulnerability

**Steps:**

1. Identify the vulnerable OS package or application dependency.
2. Check whether a fixed version exists.
3. Update the base image or dependency lock file.
4. Rebuild with no stale cache when appropriate.
5. Rescan the final runtime image.
6. If no fix exists, assess exploitability and compensating controls.
7. Use a time-bound approved exception only through the formal vulnerability process.

Never disable scanning globally just to make the build green.

---

### Scenario 7 - Docker host disk is full

**Checks:**

```bash
docker system df
docker ps -a
docker images
docker volume ls
```

**Actions:**

- Confirm which images, containers, volumes and logs are safe to remove.
- Configure container log rotation.
- Remove unused build cache through controlled maintenance.
- Do not blindly prune named volumes because they may contain persistent data.

---

## 30. Scenario-based Kubernetes interview questions

### Scenario 1 - Pod is in `CrashLoopBackOff`

```bash
kubectl get pods -n <namespace>
kubectl describe pod <pod> -n <namespace>
kubectl logs <pod> -n <namespace> --previous
```

Check application exit code, missing Secret/ConfigMap, bad command, failed dependency, probe failure, permission issue and OOM termination. Fix the root cause; increasing restart count does not solve it.

---

### Scenario 2 - Pod is in `ImagePullBackOff`

Check:

- Image name and tag.
- Registry DNS/network access.
- ACR permissions or workload/kubelet identity.
- `imagePullSecrets` for external private registries.
- Whether the image exists for the required architecture.

```bash
kubectl describe pod <pod> -n <namespace>
az acr repository show-tags --name <acr-name> --repository <repo>
```

---

### Scenario 3 - Pod remains `Pending`

Possible causes:

- Insufficient CPU or memory.
- Node selector/affinity cannot be satisfied.
- Taint without matching toleration.
- PVC is not bound.
- Maximum pod/IP capacity reached.
- Cluster autoscaler cannot add a node.

```bash
kubectl describe pod <pod> -n <namespace>
kubectl get nodes
kubectl describe nodes
kubectl get pvc -n <namespace>
```

---

### Scenario 4 - Service exists but application is not reachable

Check from inside out:

1. Pod is Ready.
2. Application listens on the expected port and `0.0.0.0`.
3. Service selector matches pod labels.
4. Service `targetPort` matches container port.
5. Endpoints/EndpointSlices contain pod IPs.
6. NetworkPolicy allows traffic.
7. Ingress/Load Balancer and DNS are correct.

```bash
kubectl get svc,endpoints,endpointslices -n <namespace>
kubectl describe svc <service> -n <namespace>
kubectl get pods -n <namespace> --show-labels
```

---

### Scenario 5 - Pod is `OOMKilled`

```bash
kubectl describe pod <pod> -n <namespace>
kubectl top pod <pod> -n <namespace>
```

Determine whether there is a memory leak, undersized limit, high concurrency or unbounded cache. Fix application behaviour first, then set realistic requests and limits based on evidence. Do not simply remove limits from a shared cluster.

---

### Scenario 6 - Node is `NotReady`

Check:

```bash
kubectl describe node <node>
kubectl get events -A --sort-by=.lastTimestamp
```

Review kubelet status, disk/memory/PID pressure, network plugin, VM health, node image, certificate and connectivity to the API server. Cordon and drain safely before repair when workload availability allows it.

```bash
kubectl cordon <node>
kubectl drain <node> --ignore-daemonsets --delete-emptydir-data
```

Use drain options carefully because local `emptyDir` data can be lost.

---

### Scenario 7 - ConfigMap or Secret changed but pods still use the old value

Environment variables are read when the container starts. A mounted volume may update later, but the application might not reload it automatically.

Use a controlled rollout:

```bash
kubectl rollout restart deployment/<deployment> -n <namespace>
kubectl rollout status deployment/<deployment> -n <namespace>
```

For Production, use versioned configuration, checksum annotations in Helm and a tested restart strategy.

---

## 31. CI/CD pipeline hands-on and scenario-based questions

### How I create a pipeline from scratch

1. Understand language, build system and deployment target.
2. Define branch and pull-request policies.
3. Create a secure service connection or workload-identity federation.
4. Add CI stages: checkout, dependencies, lint, tests, SAST/SCA, build and artifact publish.
5. Add CD stages: Dev deploy, smoke test, QA/integration test, approval and Production deploy.
6. Build once and promote the same immutable artifact.
7. Store secrets in Key Vault or protected environment variables.
8. Add logs, test reports, deployment metadata and rollback.

### Simple Azure DevOps structure

```yaml
trigger:
  branches:
    include:
      - main

pr:
  branches:
    include:
      - main

stages:
- stage: CI
  jobs:
  - job: BuildAndTest
    pool:
      vmImage: ubuntu-latest
    steps:
    - checkout: self
    - script: ./scripts/test.sh
      displayName: Test
    - script: ./scripts/build.sh
      displayName: Build
    - publish: $(Build.SourcesDirectory)/dist
      artifact: application

- stage: Deploy_Dev
  dependsOn: CI
  condition: succeeded()
  jobs:
  - deployment: Deploy
    environment: development
    strategy:
      runOnce:
        deploy:
          steps:
          - download: current
            artifact: application
          - script: ./scripts/deploy.sh dev

- stage: Deploy_Prod
  dependsOn: Deploy_Dev
  jobs:
  - deployment: Deploy
    environment: production
    strategy:
      runOnce:
        deploy:
          steps:
          - download: current
            artifact: application
          - script: ./scripts/deploy.sh prod
```

Environment approval should be configured on the Production environment rather than implemented as an easily bypassed script.

### Hands-on scenarios

#### Pipeline builds successfully but deploys an old version

Check artifact version, cache key, image tag, deployment manifest and whether CD downloads the artifact from the current run. Prefer immutable versions or image digests instead of `latest`.

#### Dev succeeds but Production fails

Compare environment-specific permissions, network reachability, variables, Key Vault access, policy, quotas and configuration. Do not rebuild the artifact for Production.

#### Secret appears as empty

Check variable scope, environment approval, Key Vault task/federated identity, secret name and whether the pipeline is running from an untrusted fork. Never print the secret value to troubleshoot.

#### Deployment is successful but health check fails

Inspect application logs, endpoint path, port, DNS, firewall and dependency configuration. Automatically stop promotion and initiate rollback when the release health criteria are not met.

---

## 32. DevOps hands-on implementation questions

### Scenario - Implement Azure DevOps for a new three-tier application

I would implement it in this order:

1. **Source control**
   - Repositories for application and infrastructure.
   - Branch policies, reviewers and pull-request template.

2. **Infrastructure as Code**
   - Terraform modules for resource group, VNet, subnets, NSGs, compute, Key Vault, database connectivity and monitoring.
   - Separate state for platform and application environments.

3. **CI for application**
   - Unit tests, code quality, dependency scan, secret scan, build and artifact/container publish.

4. **CI for infrastructure**
   - `fmt`, `validate`, lint, IaC security scan and `terraform plan`.

5. **CD**
   - Deploy infrastructure first.
   - Deploy application artifact.
   - Run smoke and integration tests.
   - Use approvals and a rollback strategy for Production.

6. **Security**
   - Workload identity or managed identity.
   - Key Vault for secrets.
   - Private endpoints and least privilege.
   - No long-lived credentials in YAML.

7. **Observability**
   - Application Insights, Log Analytics, Azure Monitor alerts and release annotations.

8. **Operations**
   - Runbooks, backup, patching, incident ownership and cost budgets.

### Expected implementation result

```text
Developer PR
   -> CI and security validation
   -> Versioned artifact
   -> Dev deployment and test
   -> QA deployment and test
   -> Production approval
   -> Production deployment
   -> Health validation and monitoring
```

### Interview tip

Do not describe only a YAML file. Explain source control, identity, IaC, artifacts, approvals, security, observability and rollback as one delivery system.

---

## 33. Day-to-day DevOps project implementation questions

### Interview answer

My daily work combines operations, automation, delivery and collaboration. A normal day includes:

1. Review Azure Monitor alerts, Service Health, backup/patch status and failed pipelines.
2. Attend stand-up and confirm priorities, incidents and planned releases.
3. Work from a feature branch for Terraform, pipeline or scripting changes.
4. Run local validation and open a pull request.
5. Review another engineer's code and Terraform plan.
6. Troubleshoot infrastructure, application connectivity or deployment issues.
7. Support scheduled Dev, QA or Production releases.
8. Check post-deployment health, logs and metrics.
9. Update incident notes, runbooks and change records.
10. Identify repetitive manual work for automation.

### Day-to-day scenario

> A developer reported that a new deployment could not access Storage. I checked pipeline success first, then application identity, Storage data-plane RBAC, private endpoint DNS and the storage firewall. The managed identity had Contributor on the resource but not Storage Blob Data Contributor. We added the least-privilege data role at container scope, validated access and documented the difference between management-plane and data-plane permissions.

### Team contribution

- Reusable Terraform modules and pipeline templates.
- Pull-request reviews.
- Incident and root-cause support.
- Security remediation.
- Knowledge-sharing sessions.
- Runbook and architecture maintenance.
- Release readiness and rollback planning.

---

## 34. Troubleshooting scenarios related to CI/CD pipelines

### Standard troubleshooting method

```text
Identify failing stage
-> Read first meaningful error
-> Compare with last successful run
-> Review recent code/config changes
-> Validate identity, variables and agent
-> Reproduce the exact command
-> Check external dependencies
-> Fix root cause
-> Rerun only the required stage
-> Document prevention
```

### Scenario 1 - Pipeline cannot authenticate to Azure

Check:

- Tenant, subscription and service-connection scope.
- Federated credential subject/issuer/audience.
- Service principal or managed-identity RBAC.
- Expired secret/certificate if legacy credentials are still used.
- Environment approval and protected-resource permissions.

Use `az account show` after login, but never print tokens.

### Scenario 2 - Self-hosted agent is offline

Check agent service, disk space, CPU/memory, outbound proxy/firewall, DNS, certificate trust and pool authorization. Review agent diagnostic logs and restart only after confirming the cause.

### Scenario 3 - Package restore suddenly fails

Check package-feed availability, credentials, proxy, rate limits, lock-file changes and whether a package version was removed. Use dependency caching carefully; clear only the affected cache when evidence shows corruption.

### Scenario 4 - Terraform plan and apply differ

Possible causes:

- Apply generated a new plan instead of using the reviewed plan.
- Another deployment changed state or infrastructure.
- Data sources returned different values.
- Environment variables differed between stages.

Use state locking, serialize applies, store the reviewed plan securely and apply that exact plan.

### Scenario 5 - Pipeline passes but application is broken

The pipeline needs stronger release validation. Add smoke tests, readiness checks, synthetic transactions and automatic rollback criteria. Deployment completion is not the same as application success.

### Scenario 6 - Vulnerability scan blocks an emergency fix

Do not disable the entire gate. Determine whether the finding is introduced by the change, whether a fix exists and whether exploitability is relevant. Use an approved, time-bound exception with owner and expiry only when the business risk justifies it, then track remediation.

---

## 35. Troubleshooting scenarios related to Docker and Kubernetes

### Container troubleshooting order

```text
Image -> Entrypoint -> Environment -> Files/permissions -> Network -> Runtime limits -> Logs
```

Useful commands:

```bash
docker ps -a
docker logs <container>
docker inspect <container>
docker exec -it <container> sh
docker stats
docker system df
```

### Kubernetes troubleshooting order

```text
Deployment -> ReplicaSet -> Pod events -> Container logs -> Service/endpoints -> Ingress -> NetworkPolicy -> Node/cluster
```

Useful commands:

```bash
kubectl get deploy,rs,pods,svc,ingress -n <namespace>
kubectl describe pod <pod> -n <namespace>
kubectl logs <pod> -n <namespace> --all-containers --previous
kubectl get events -n <namespace> --sort-by=.lastTimestamp
kubectl get endpoints,endpointslices -n <namespace>
kubectl top pods,nodes
kubectl rollout status deployment/<name> -n <namespace>
kubectl rollout undo deployment/<name> -n <namespace>
```

### Scenario - New release causes repeated restarts

1. Check rollout status and pod events.
2. Compare new and previous image versions.
3. Review previous-container logs.
4. Check probes, environment variables, Secret/ConfigMap, memory limits and dependencies.
5. If customer impact is active and the previous version was healthy, roll back while investigation continues.
6. Fix the root cause in source control and deploy through the pipeline; do not patch the pod manually.

### Scenario - Only one service cannot communicate across namespaces

Check Service FQDN, namespace, selector/endpoints and NetworkPolicy. A typical FQDN is:

```text
service-name.namespace.svc.cluster.local
```

Test from a temporary approved troubleshooting pod and remove it afterward.

---

## 36. Azure networking scenario-based questions

### Scenario 1 - Two peered VNets cannot communicate

Check:

- Peering exists and is Connected in both directions.
- Address spaces do not overlap.
- NSG permits the traffic.
- UDR does not send traffic to an unavailable NVA.
- Forwarded traffic/gateway transit settings match the design.
- Guest OS firewall allows the port.

Remember that ordinary VNet peering is not automatically transitive.

### Scenario 2 - Private Endpoint exists, but the VM resolves the public IP

Check the correct Private DNS zone, VNet link, A record, custom DNS forwarder and DNS cache. For Blob Storage, the private zone normally uses the `privatelink.blob.core.windows.net` namespace.

### Scenario 3 - Application Gateway returns 502

Start with Backend Health. Check probe path, host header, backend port/protocol, NSG/UDR, DNS, TLS trust and whether the application is listening. Test the backend directly from an equivalent network path.

### Scenario 4 - NSG rule appears correct, but traffic is still denied

Review effective security rules at the NIC. A higher-priority rule, subnet NSG, NIC NSG or Azure Virtual Network Manager security-admin rule may affect the result. Check both inbound and outbound directions and the return path.

### Scenario 5 - Outbound traffic works for a while and then fails intermittently

Investigate SNAT port exhaustion, excessive short-lived connections, missing connection pooling and overloaded firewall/NAT resources. NAT Gateway provides scalable outbound SNAT, but application connection behaviour still matters.

### Scenario 6 - On-premises can reach Azure, but Azure cannot reach on-premises

Check effective routes, gateway propagation, BGP routes, UDRs, on-premises firewall, return route and asymmetric routing. Confirm that the on-premises network knows how to return traffic to the Azure subnet.

### Scenario 7 - Public application is reachable by IP but not DNS name

Check DNS record, TTL, certificate host name, listener host name and whether the client resolves the expected frontend IP. Test with `nslookup`/`Resolve-DnsName` and an explicit `Host` header when isolating the issue.

### Azure-native tools

- Network Watcher Connection troubleshoot.
- IP flow verify.
- Effective routes.
- Effective security rules.
- NSG flow logs/virtual network flow logs where configured.
- Packet capture where justified.
- Azure Firewall logs.
- Application Gateway Backend Health.

---

## 37. Terraform deployment and infrastructure troubleshooting scenarios

### Scenario 1 - State lock error

**Cause:** Another run is active, or a previous run ended without releasing the lock.

**Approach:**

1. Confirm no pipeline or engineer is still running plan/apply.
2. Identify the lock owner and timestamp.
3. Allow the active operation to finish.
4. Use `terraform force-unlock <LOCK_ID>` only after confirming the lock is stale.
5. Prevent recurrence by serializing applies and cancelling runs cleanly.

Never force-unlock an active deployment.

---

### Scenario 2 - `403 AuthorizationFailed` during apply

Check:

- Correct tenant and subscription.
- Pipeline identity and provider alias.
- RBAC action required by the resource.
- Scope of the role assignment.
- Policy denial versus RBAC denial.
- Data-plane permission when accessing Storage/Key Vault data.
- Role-assignment propagation delay.

Do not solve every error by assigning Owner. Add the least-privilege role at the correct scope.

---

### Scenario 3 - Resource already exists

Terraform is trying to create a resource not recorded in the current state.

Options:

- Import the existing resource when Terraform should own it.
- Reference it through a data source when another stack owns it.
- Rename/remove the duplicate definition.
- Confirm that the pipeline is using the correct backend and workspace/root configuration.

```bash
terraform import <resource-address> <azure-resource-id>
terraform plan
```

After import, ensure the configuration matches the real resource before applying.

---

### Scenario 4 - Unexpected destroy or replacement in plan

Stop and investigate:

- Changed immutable property.
- Resource address changed because of refactoring.
- `count` index changed.
- `for_each` key changed.
- Provider/API behaviour changed.
- Resource was manually recreated.

Use `moved` blocks when refactoring resource addresses and stable `for_each` keys for named resources. Do not approve an unexplained Production replacement.

---

### Scenario 5 - Manual Azure change causes drift

Run a normal plan to see the difference. Decide whether the manual change is valid:

- If valid, update code and review it.
- If invalid, allow Terraform to restore the approved configuration.
- If ownership changed, import or remove the resource from the appropriate state carefully.

Avoid using `ignore_changes` as a blanket way to hide drift.

---

### Scenario 6 - Provider version upgrade breaks the pipeline

- Review provider release notes and upgrade guide.
- Change version constraint intentionally.
- Run `terraform init -upgrade` in a branch.
- Review `.terraform.lock.hcl` changes.
- Test plans in lower environments.
- Promote the same tested version.

Commit the dependency lock file for root configurations so automation uses consistent provider selections.

---

### Scenario 7 - Apply partially succeeds and then fails

Terraform normally records successfully completed operations in state. Do not manually recreate everything immediately.

1. Read the exact error.
2. Confirm state backend is healthy.
3. Inspect Azure to see which resources exist.
4. Correct the root cause, such as permission, quota or invalid dependency.
5. Run `terraform plan` again.
6. Review the remaining actions and apply.

If a resource exists but is not in state because of an unusual failure, import it rather than creating a duplicate.

---

### Scenario 8 - Backend state cannot be accessed

Check:

- Storage account/container name and backend key.
- DNS/private endpoint connectivity from the agent.
- Storage firewall rules.
- Pipeline identity and Storage Blob Data permissions.
- Azure authentication context.
- Whether the backend configuration changed and requires `terraform init -reconfigure` or state migration.

### Scenario 9 - Azure Policy denies the Terraform deployment

Read the policy assignment and deny reason. Decide whether to:

- Modify Terraform to become compliant.
- Supply required tags/settings.
- Use the approved resource type/region/SKU.
- Request a documented exemption when a legitimate exception exists.

Do not bypass policy from the pipeline without governance approval.

### Scenario 10 - Plan works locally but fails in CI

Compare:

- Terraform and provider versions.
- Backend and variable files.
- Subscription/tenant and provider aliases.
- Environment variables.
- Network access from the agent.
- File-path case sensitivity.
- Uncommitted local files.
- Permissions and Key Vault access.

Use a version-pinned, repeatable toolchain and run the same commands locally and in CI.

### Production troubleshooting principle

```text
Protect state -> Stop concurrent changes -> Read the plan/error -> Verify identity and backend -> Correct root cause -> Re-plan -> Peer review -> Apply
```

---

## TCS interview collection and repeat-question tracker

To keep repeated questions proactive, record every new TCS interview using this format:

```markdown
### Interview record

- Date:
- Role:
- Round:
- Interview focus:
- Questions asked:
- Questions repeated from previous rounds:
- Questions not answered confidently:
- Topics to revise:
- Result/feedback:
```

Tag every question as one of the following:

```text
Repeated frequently
Asked twice
Asked once
Hands-on task
Scenario question
Needs lab practice
```

This makes it easy to identify the questions that repeat across candidates and prioritize revision before the next round.

---

## Official references for this TCS section

- [Azure Landing Zones](https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/)
- [Azure Application Gateway overview](https://learn.microsoft.com/azure/application-gateway/overview)
- [Application Gateway configuration overview](https://learn.microsoft.com/azure/application-gateway/configuration-overview)
- [Create Application Gateway in the Azure portal](https://learn.microsoft.com/azure/application-gateway/quick-create-portal)
- [Azure Load Balancer SKUs and types](https://learn.microsoft.com/azure/load-balancer/skus)
- [Azure Storage account overview](https://learn.microsoft.com/azure/storage/common/storage-account-overview)
- [Manage Azure subnets](https://learn.microsoft.com/azure/virtual-network/virtual-network-manage-subnet)
- [Azure public IP address associations](https://learn.microsoft.com/azure/virtual-network/ip-services/public-ip-addresses)
- [Default outbound access in Azure](https://learn.microsoft.com/azure/virtual-network/ip-services/default-outbound-access)
- [Azure Network Watcher connection troubleshoot](https://learn.microsoft.com/azure/network-watcher/connection-troubleshoot-manage)
- [Terraform plan](https://developer.hashicorp.com/terraform/cli/commands/plan)
- [Terraform apply](https://developer.hashicorp.com/terraform/cli/commands/apply)
- [Terraform providers](https://developer.hashicorp.com/terraform/language/providers)
- [Continuous integration](https://learn.microsoft.com/devops/develop/what-is-continuous-integration)
- [DevOps CI/CD concepts](https://learn.microsoft.com/azure/architecture/guide/devops/devops-get-started)
- [How Microsoft develops with Git branching](https://learn.microsoft.com/devops/develop/how-microsoft-develops-devops)


## Likely follow-up questions

1. Difference between an IDP and a developer portal.
2. What is a golden path?
3. How do you measure developer productivity without measuring individual developers unfairly?
4. Difference between Platform Engineering and DevOps.
5. Prometheus versus Azure Monitor.
6. What is OpenTelemetry?
7. How do you avoid alert fatigue?
8. How do you implement GitOps?
9. How do you upgrade AKS safely?
10. How do you define SLI, SLO and SLA?
