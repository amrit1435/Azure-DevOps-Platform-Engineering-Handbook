# 06 - Resume Skills and Missing Core Azure DevOps Questions

This chapter adds interview questions based on the resume and fills gaps needed for Azure-focused core DevOps roles.

---

## 1. What is your strongest technical area?

### Interview answer

My strongest area is Azure infrastructure and operations combined with automation. I am comfortable with virtual machines, networking, storage, backup, monitoring, identity and access, and I automate these activities with Terraform, ARM/Bicep, PowerShell, Bash, Azure CLI and CI/CD pipelines.

I also bring strong infrastructure troubleshooting and IT operations experience, so I understand both the cloud control plane and the operating-system/service-management side.

---

## 2. Explain Azure DevOps services

### Azure Boards

Work items, backlog, sprints, bugs, tasks and planning.

### Azure Repos

Git repositories, pull requests, branch policies and code review.

### Azure Pipelines

Build, test, artifact publishing and multi-stage deployment using YAML or classic pipelines.

### Azure Artifacts

Package feeds for NuGet, npm, Maven, Python and Universal Packages.

### Azure Test Plans

Manual and exploratory testing capabilities.

### Interview scenario

> A user story in Boards links to a feature branch and pull request in Repos. The pull request triggers a validation pipeline. After approval and merge, a release pipeline builds and deploys the versioned artifact, and the deployment result is linked back to the work item.

---

## 3. What are Azure DevOps environments and approvals?

### Answer

An Azure DevOps environment represents a deployment target or logical stage such as Dev, QA or Production. Environments provide deployment history, permissions, approvals and checks.

Production controls may include:

- Manual approval.
- Branch control.
- Business-hours or change-window checks.
- Exclusive lock.
- Required template or external policy check.
- Separate environment permissions.

### Scenario

> The pipeline could deploy automatically to Dev and QA. Production used an Azure DevOps Environment with two approvers and an exclusive lock to prevent overlapping releases.

---

## 4. What is a service connection?

### Answer

A service connection allows Azure DevOps to authenticate to an external service such as Azure, Kubernetes, a container registry or another platform.

For Azure, prefer workload identity federation where supported instead of storing a long-lived client secret. Grant the service connection only the permissions and scope required by the pipeline.

### Common issue

A service connection may have Contributor at subscription scope but still lack storage data-plane access or Key Vault data access. Management-plane and data-plane roles must be considered separately.

---

## 5. Microsoft-hosted agent versus self-hosted agent

| Microsoft-hosted | Self-hosted |
|---|---|
| Fresh managed runner for each job | Organization manages operating system and tools |
| Easy scaling and low maintenance | Can access private networks and custom software |
| Limited job lifetime/customization | Requires patching, security, capacity and cleanup |
| Internet-based service access | Can be placed in a VNet or controlled network |

### Selection scenario

> A Terraform pipeline needed access to a private Storage Account and private AKS API. We used an approved self-hosted agent in the required network. We hardened the host, used ephemeral agents where possible and prevented untrusted repositories from sharing it.

---

## 6. How do you manage variables and secrets in Azure DevOps?

### Answer

- Non-secret values: YAML variables, variable templates or variable groups.
- Secrets: secret variables, Key Vault-linked variable groups or runtime retrieval from Key Vault.
- Azure authentication: workload identity federation/managed identity where supported.

Do not echo secrets, place them in repository files or pass them through insecure command-line debugging. Use environment-specific variable groups and restrict who can use them.

---

## 7. What are pipeline templates and why use them?

### Answer

YAML templates allow multiple pipelines to reuse common stages, jobs, steps and variables. They improve consistency and make security controls easier to maintain.

Examples:

- Common Terraform validation template.
- Standard Docker build and scan template.
- Production deployment template.
- Central security scan template.

### Scenario

> Fifty repositories copied their own Trivy steps. We moved the scan logic into a centrally versioned template. Updating the policy in one place improved consistency across teams.

---

## 8. Explain build artifacts and immutable promotion

### Answer

A build artifact is the output of CI, such as a ZIP, package, binary, Helm chart or container image. The artifact should be versioned and immutable.

The preferred model is:

```text
Build once -> Publish -> Deploy same version to Dev -> QA -> Production
```

Rebuilding separately for every environment can produce different outputs and weakens traceability.

---

## 9. How do you handle rollback in CI/CD?

### Answer

Rollback depends on deployment type:

- App Service: swap back to the previous slot.
- Kubernetes: Helm rollback or redeploy the previous image digest.
- VM application: deploy the previous package/image.
- Database: prefer forward-compatible changes and a tested migration/recovery plan.
- Terraform: fix code and apply an approved corrective plan; do not treat source-code revert as an automatic infrastructure rollback without reviewing destructive effects.

### Scenario

> After deployment, health checks showed an increased 5xx rate. The pipeline automatically stopped promotion, and the team redeployed the previous container digest while investigating the change.

---

## 10. Explain Git branching strategies

### Trunk-based development

Developers use short-lived branches and merge frequently to main. It supports fast CI/CD and reduces long-running merge conflicts.

### GitFlow

Uses feature, develop, release and hotfix branches. It can suit formal release cycles but adds complexity.

### Interview recommendation

For frequent cloud delivery, I prefer short-lived feature branches, protected main, pull requests, automated checks and release tags. The final model depends on product and compliance requirements.

---

## 11. Merge versus rebase

### Merge

Combines histories with a merge commit and preserves the original branch structure.

### Rebase

Replays commits on a new base, creating a cleaner linear history but rewriting commit IDs.

### Safe practice

Do not rebase a shared branch without coordination. Rebase or squash is commonly used before merging a private feature branch.

---

## 12. Reset versus revert

### `git reset`

Moves the branch pointer and can rewrite local history. `--hard` also discards working-tree changes. Use carefully and generally avoid on shared branches.

### `git revert`

Creates a new commit that reverses an earlier commit. It is safer for shared branches such as main.

### Scenario

> A bad change had already been pushed to main. We used revert rather than reset so the audit trail remained intact.

---

## 13. ARM Templates, Bicep and Terraform - what is the difference?

| ARM Template | Bicep | Terraform |
|---|---|---|
| Native Azure JSON | Native Azure DSL compiled to ARM | Multi-provider declarative IaC |
| Verbose | More readable than ARM JSON | Uses HCL and provider ecosystem |
| Azure-only | Azure-only | Azure plus many other platforms |
| Azure deployment state handled by platform | Same deployment model | Uses Terraform state |

### Selection answer

Use the organization's standard, skills and operating model. Bicep is strong for Azure-native deployments. Terraform is strong when teams want a consistent multi-provider workflow, reusable modules and Terraform ecosystem integration.

---

## 14. `count` versus `for_each` in Terraform

### `count`

Good for creating a numeric number of similar instances. Resources are indexed numerically.

### `for_each`

Good when instances have stable keys such as subnet names. It usually creates clearer addresses and reduces unintended index changes.

```hcl
for_each = var.subnets
name     = each.key
```

### Interview example

Use `for_each` for named NSG rules or subnets because identity remains based on the key, not list position.

---

## 15. What is the Terraform lifecycle block?

### Common settings

- `create_before_destroy` to reduce downtime when replacement is supported.
- `prevent_destroy` for critical resources, used carefully.
- `ignore_changes` for attributes intentionally managed elsewhere.
- `replace_triggered_by` for controlled replacement dependencies.

### Warning

`ignore_changes` should not be used to hide uncontrolled drift. Document why another system owns the ignored attribute.

---

## 16. How do you import an existing Azure resource into Terraform?

### Process

1. Write the matching Terraform resource block.
2. Confirm provider and resource ID.
3. Use an import block or `terraform import` according to the Terraform version/workflow.
4. Run `terraform plan`.
5. Adjust configuration until the plan does not attempt unintended replacement.
6. Review and commit the code.

### Risk

Importing state does not automatically create perfect source configuration. The code must accurately represent the existing resource.

---

## 17. How do PowerShell, Bash and Azure CLI fit into DevOps?

### Answer

- PowerShell is strong for Microsoft administration, Azure, Windows and structured object pipelines.
- Bash is common on Linux agents and container tooling.
- Azure CLI provides cross-platform Azure automation and is easy to use in pipelines.

Use scripts for orchestration, validation and small operational tasks. Use Terraform/Bicep for declarative infrastructure ownership rather than replacing all IaC with long imperative scripts.

### Scenario

> Terraform deployed resources, and a small Azure CLI validation script confirmed private DNS resolution, backend health and required tags after deployment.

---

## 18. Explain Entra ID, RBAC and Managed Identity

### Entra ID

Identity provider for users, groups, applications and authentication.

### Azure RBAC

Authorization system defining who can perform which Azure action at which scope.

### Managed Identity

An Azure-managed identity for a resource, eliminating the need to store a client secret. System-assigned identity follows the resource lifecycle; user-assigned identity is a separate reusable resource.

### Scenario

> An App Service used managed identity to retrieve a Key Vault secret. The identity received only the required Key Vault permission, and no client secret was stored in application settings.

---

## 19. What are Conditional Access, MFA, SSPR and SSO?

### Conditional Access

Policy engine that evaluates signals such as user, location, device, application and risk before granting access.

### MFA

Requires an additional authentication factor.

### SSPR

Self-Service Password Reset allows users to reset passwords after approved verification.

### SSO

Single Sign-On allows a user to authenticate once and access integrated applications.

### DevOps relevance

Protect administrator and DevOps access, require strong authentication, control risky logins and use separate privileged identities where required.

---

## 20. Explain Azure Backup versus Azure Site Recovery

| Azure Backup | Azure Site Recovery |
|---|---|
| Protects data and restore points | Replicates supported workloads for disaster recovery |
| Used for file/VM/database recovery | Used for failover to another location/environment |
| Focus on recovery point retention | Focus on business continuity and failover orchestration |

### Scenario

> Backup recovered a deleted file or corrupted VM disk. Site Recovery was used to fail over a protected VM to the recovery region during a major site outage test.

### Interview note

Backup is not automatically a complete DR strategy. Define RPO, RTO, dependencies, network failover and regular testing.

---

## 21. Azure Monitor, Log Analytics and Application Insights - difference

### Azure Monitor

The overall monitoring platform for metrics, logs, alerts and insights.

### Log Analytics workspace

Stores and queries log data using Kusto Query Language (KQL).

### Application Insights

Application performance monitoring for requests, exceptions, dependencies, traces and distributed application behavior.

### Example KQL

```kusto
AzureActivity
| where TimeGenerated > ago(24h)
| summarize count() by OperationNameValue, ActivityStatusValue
| order by count_ desc
```

---

## 22. How do you create useful alerts?

### Answer

An alert should be actionable, owned and connected to a runbook. I define:

- Signal and threshold.
- Evaluation period.
- Severity.
- Application/environment tags.
- Action group and escalation.
- Suppression or dynamic threshold where appropriate.
- Runbook and expected response.

Avoid alerting on every short spike. Use sustained conditions, user-impact metrics and dependency health to reduce noise.

---

## 23. How do you approach incident and change management?

### Incident

Restore service first, communicate impact, collect evidence, identify root cause, document actions and create preventive tasks.

### Change

Define scope, risk, implementation, validation, rollback, owner, window and approvals before Production work.

### DevOps improvement

Automated pipelines strengthen change control by providing versioned code, review, repeatable execution and logs.

---

## 24. How does ISO 27001 experience help a DevOps role?

### Answer

ISO 27001 experience helps me understand that security requires governance, ownership, evidence and continuous improvement, not only technical tools. In DevOps this translates into controlled access, change records, asset ownership, incident management, vulnerability remediation, backup tests and auditable pipeline evidence.

---

## 25. What is your experience with Docker and AKS?

### Honest interview answer

I have working familiarity with Docker and AKS. I understand Dockerfiles, image layers, registries, container scanning, Kubernetes workloads, services, ingress, namespaces, RBAC, scaling, monitoring and AKS security concepts. My strongest production area remains Azure infrastructure, Terraform and CI/CD, and I am building deeper hands-on Kubernetes experience through labs and project work.

This answer aligns expectations and allows you to explain concepts without claiming advanced cluster administration that you have not performed.

---

## 26. Explain a multi-stage Docker build

### Answer

A multi-stage build uses one image to compile/build and a smaller runtime image for execution. Build tools and source files do not need to remain in the final image.

```dockerfile
FROM python:3.12-slim AS build
WORKDIR /app
COPY requirements.txt .
RUN pip wheel --wheel-dir /wheels -r requirements.txt

FROM python:3.12-slim
WORKDIR /app
COPY --from=build /wheels /wheels
RUN pip install --no-cache-dir /wheels/*
COPY . .
USER 10001
CMD ["python", "app.py"]
```

Benefits include smaller images, reduced attack surface and clearer build separation.

---

## 27. Explain Kubernetes Deployment, Service and Ingress

### Deployment

Manages stateless pod replicas and rolling updates.

### Service

Provides stable network access to pods, such as ClusterIP, LoadBalancer or other supported types.

### Ingress

Defines HTTP/HTTPS routing rules through an ingress controller.

### Scenario

> A Deployment runs three API pods. A ClusterIP Service selects those pods. An ingress controller routes `/api` traffic to the Service and terminates or passes TLS according to design.

---

## 28. HPA versus Cluster Autoscaler

### Horizontal Pod Autoscaler

Changes the number of pod replicas based on metrics.

### Cluster Autoscaler

Adds or removes cluster nodes when pods cannot be scheduled or nodes are underutilized according to policy.

### Interview point

HPA may create more pods, and Cluster Autoscaler provides more node capacity when required. Resource requests must be configured correctly for scheduling and scaling decisions.

---

## 29. What is Helm?

### Answer

Helm is a package manager and templating system for Kubernetes. A chart contains templates, default values and metadata. Environment-specific values can be supplied without duplicating complete manifests.

Use versioned charts, validate rendered manifests, protect secrets and avoid overly complex templates.

---

## 30. What is GitOps?

### Answer

GitOps uses Git as the declarative source of truth for deployment state. An agent such as Flux or Argo CD continuously compares the cluster with Git and reconciles approved differences.

Benefits include auditability, pull-request review and drift correction. It does not remove the need for secret management, access control, testing and safe promotion.

---

## 31. What is Zero Trust in Azure operations?

### Answer

Zero Trust follows the principles: verify explicitly, use least privilege and assume breach.

Examples:

- MFA and Conditional Access.
- PIM and time-bound privilege.
- Managed identity/OIDC.
- Network segmentation and private access.
- Device compliance.
- Continuous logging and threat detection.
- No trust based only on network location.

---

## 32. How do Intune compliance and patch management relate to cloud security?

### Answer

Intune can enforce device compliance such as encryption, supported operating-system version and security configuration. Conditional Access can then require a compliant device for sensitive applications. Endpoint patching reduces known vulnerabilities and supports the organization's Zero Trust and compliance model.

For server patching, use the appropriate server-management service such as Azure Update Manager rather than treating Intune as the only patching solution.

---

## 33. What Microsoft 365 knowledge is relevant to DevOps?

### Answer

Microsoft 365 is not the core of an Azure DevOps role, but tenant administration experience demonstrates identity, access, compliance and enterprise operations skills. Relevant areas include Entra integration, Teams notifications, SharePoint documentation, Purview governance and secure email operations.

Keep the interview focus on Azure and DevOps unless the role specifically includes M365 administration.

---

## 34. How would you demonstrate automation impact?

### Answer

Use a measurable before-and-after result:

> A recurring provisioning and reporting process required several manual steps and was prone to inconsistent execution. I automated the workflow with PowerShell/Azure CLI and integrated it with the operational process. Manual effort reduced by approximately 30-40%, execution became repeatable, and the team had clearer logs and error handling.

Only use a percentage that is supported by your actual project evidence.

---

## 35. What additional topics should you prepare for a core Azure DevOps role?

- Azure DevOps YAML templates and environments.
- GitHub Actions reusable workflows and OIDC.
- Terraform state, import, drift and module versioning.
- Docker image optimization and security.
- AKS deployment, networking, identity and troubleshooting.
- Helm and GitOps basics.
- SonarQube, Trivy, IaC and dependency scanning.
- Azure Monitor, KQL, Application Insights and SLOs.
- Key Vault, managed identity, PIM and private endpoints.
- Linux troubleshooting and scripting.
- Incident, rollback and disaster-recovery scenarios.
