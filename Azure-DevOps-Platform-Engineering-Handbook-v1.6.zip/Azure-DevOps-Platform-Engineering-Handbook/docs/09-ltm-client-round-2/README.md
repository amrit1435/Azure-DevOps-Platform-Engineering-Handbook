# 09 - LTM Client Round 2 Interview Questions

This chapter contains the questions recorded from the LTM client second-round interview. The answers are written in simple language, but they also include the design choices, security controls and practical examples expected in a senior Azure DevOps or multi-cloud DevOps interview.

> Interview tip: This round mixed AWS, Azure, Terraform and configuration-management topics. When a question is ambiguous, first state your assumption. For example: "If both subnets are in the same VPC...; if they are in separate VPCs..." This shows structured thinking.

---

## 1. How will you secure an Amazon S3 bucket?

### Short interview answer

I secure an S3 bucket by blocking public access, disabling ACL-based access, applying least-privilege IAM and bucket policies, enforcing HTTPS, enabling encryption, versioning and logging, and continuously checking the bucket with IAM Access Analyzer, AWS Config, Security Hub and CloudTrail. For private workloads, I also restrict access through an S3 VPC endpoint.

### Detailed answer

I secure the bucket in layers rather than depending on one control.

#### 1. Block unintended public access

- Enable all four **S3 Block Public Access** settings at both account and bucket level unless there is an approved public use case.
- Avoid bucket policies containing an unrestricted `"Principal": "*"`.
- For a public website, prefer CloudFront with Origin Access Control instead of making the bucket public.

#### 2. Disable ACL-based access

Use **S3 Object Ownership - Bucket owner enforced**. This disables ACLs and keeps access control in IAM policies, bucket policies and access-point policies. It removes many ownership and cross-account ACL problems.

#### 3. Apply least privilege

- Grant only the required actions, such as `s3:GetObject`, instead of `s3:*`.
- Limit access to the required bucket and prefix.
- Use IAM roles and short-lived credentials instead of long-lived IAM user access keys.
- Add conditions such as approved VPC endpoint, source account, organization ID or encryption requirement where appropriate.

#### 4. Encrypt data

- Use S3 default server-side encryption.
- Use SSE-KMS when you need customer-controlled keys, key rotation, detailed key permissions or separation of duties.
- Restrict KMS key policy so that only approved principals and services can use the key.

#### 5. Enforce encrypted transport

Deny requests that do not use TLS:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DenyInsecureTransport",
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:*",
      "Resource": [
        "arn:aws:s3:::company-prod-data",
        "arn:aws:s3:::company-prod-data/*"
      ],
      "Condition": {
        "Bool": {
          "aws:SecureTransport": "false"
        }
      }
    }
  ]
}
```

#### 6. Protect against deletion and ransomware

- Enable S3 Versioning.
- For regulated or immutable data, evaluate S3 Object Lock and retention policies.
- Use lifecycle rules to move or expire older object versions safely.
- Protect deletion permissions and require stronger controls for destructive actions.

#### 7. Use private network access when required

For workloads inside a VPC:

- Create an S3 Gateway VPC Endpoint.
- Restrict the bucket policy to the approved endpoint or VPC where the application design supports it.
- Test service integrations before applying a strict `aws:SourceVpce` deny rule, because an incorrect condition can block legitimate AWS service access.

#### 8. Monitor and audit

- Enable CloudTrail management events and S3 data events where object-level auditing is required.
- Use S3 server access logging when appropriate.
- Use IAM Access Analyzer for public or cross-account findings.
- Use AWS Config and Security Hub controls to detect public access, missing encryption or logging issues.
- Use Amazon Macie for sensitive-data discovery when required.

### Scenario-based example

> A build-artifact bucket was accessible by multiple application teams. I enabled account- and bucket-level Block Public Access, disabled ACLs, granted each pipeline role access only to its own prefix, enforced TLS, enabled SSE-KMS and versioning, and configured CloudTrail data events. A Security Hub finding later detected an overly broad test policy before it reached Production.

### Common mistake

Encryption alone does not secure the bucket. A bucket can be encrypted but still exposed through an overly broad bucket policy. Access control, network restrictions, monitoring and recovery controls are all required.

### Likely follow-up questions

- What is the difference between an IAM policy and an S3 bucket policy?
- When would you use SSE-S3 versus SSE-KMS?
- How do you provide secure cross-account bucket access?
- How would you secure a static website stored in S3?

---

## 2. How can you connect two subnets?

### Short interview answer

Subnets are connected through routing, not by attaching them directly to each other. If both subnets are in the same VPC, the VPC route tables already contain a local route, so I mainly verify route-table association, security groups and network ACLs. If they are in different VPCs, I use VPC peering for a simple one-to-one connection or Transit Gateway for a larger hub-and-spoke design, and then update routes and security rules on both sides.

### Case 1 - Both subnets are in the same AWS VPC

A VPC has an implicit router. Each route table includes a local route for the VPC CIDR. Therefore, two subnets in the same VPC can normally communicate automatically.

I verify:

1. The source and destination CIDRs are part of the VPC and do not overlap.
2. Both subnets are associated with the intended route tables.
3. The local VPC route is present.
4. Security groups allow the required source, destination, protocol and port.
5. Network ACLs allow both request and return traffic.
6. The operating-system firewall and application listener allow the traffic.
7. DNS resolves to the expected private address when an FQDN is used.

Example:

```text
VPC:        10.10.0.0/16
Web subnet: 10.10.1.0/24
DB subnet:  10.10.2.0/24
Local route in both route tables: 10.10.0.0/16 -> local
```

The database security group can allow TCP 5432 only from the web-server security group instead of allowing the entire VPC.

### Case 2 - Subnets are in different VPCs

Choose the connection based on scale and topology:

- **VPC Peering:** suitable for a small number of direct VPC-to-VPC connections. Peering is not transitive.
- **AWS Transit Gateway:** suitable for many VPCs, shared routing, hybrid connectivity and network segmentation.
- **Site-to-Site VPN or Direct Connect:** used when one network is on-premises.

For VPC peering, I:

1. Confirm the VPC CIDRs do not overlap.
2. Create and accept the peering connection.
3. Add a route in the source subnet route table for the destination VPC CIDR through the peering connection.
4. Add the return route on the destination side.
5. Configure security groups and NACLs.
6. Enable DNS resolution across the peering connection if required.
7. Test in both directions.

### Azure equivalent

In Azure, subnets in the same VNet can communicate through system routes unless NSGs, UDRs or firewalls block them. For subnets in different VNets, use VNet peering, Virtual WAN, VPN or a routed hub-and-spoke design.

### Scenario-based example

> An application subnet could not connect to a database subnet in the same VPC. The local route was correct, but the database security group allowed the web subnet CIDR on the wrong port. After allowing the actual database port from the application security group, connectivity worked without adding any new gateway.

### Troubleshooting order

```text
CIDR overlap -> Route tables -> Security groups -> NACLs -> OS firewall -> Application listener -> DNS -> Return path
```

---

## 3. What is an Azure Management Group?

### Short interview answer

An Azure Management Group is a governance scope above subscriptions. It lets an organization apply Azure Policy and RBAC once and inherit those controls across all child management groups, subscriptions, resource groups and resources.

### Detailed answer

The Azure hierarchy is:

```text
Microsoft Entra tenant
└── Root management group
    └── Management groups
        └── Subscriptions
            └── Resource groups
                └── Resources
```

A management group is used to organize subscriptions that require similar governance. It does not normally contain VMs, VNets or storage accounts directly. Those resources exist inside subscriptions.

### Main uses

- Apply Azure Policy at scale.
- Assign RBAC at a common parent scope.
- Separate Platform, Production, Non-Production, Sandbox and Decommissioned subscriptions.
- Enforce approved regions, diagnostic settings, public-network restrictions and security standards.
- Delegate administration without assigning permissions individually to every subscription.

### Example hierarchy

```text
Tenant Root Group
└── Contoso
    ├── Platform
    │   ├── Connectivity
    │   ├── Identity
    │   └── Management
    ├── Landing-Zones
    │   ├── Production
    │   └── Non-Production
    ├── Sandbox
    └── Decommissioned
```

### Scenario-based example

> The company had 20 subscriptions. Instead of assigning an "Allowed Regions" policy separately 20 times, we assigned the policy initiative to the Production management group. All current and future subscriptions placed under that group inherited the control.

### Management Group versus Subscription

| Management Group | Subscription |
|---|---|
| Governance and organization scope | Billing, quota and resource-management boundary |
| Contains child management groups and subscriptions | Contains resource groups and resources |
| Used for inherited Policy and RBAC | Used to deploy workloads |

---

## 4. How would you configure an app registration so that it connects to a pipeline?

### Short interview answer

For Azure DevOps, I create an Azure Resource Manager service connection backed by a Microsoft Entra app registration or managed identity. I prefer workload identity federation because it avoids stored client secrets. I assign the identity only the required RBAC role and scope, authorize only the required pipelines, and test the connection with a simple Azure CLI task.

### Recommended design in 2026

Use **Workload Identity Federation (OIDC)** rather than a long-lived client secret. New Azure DevOps Azure Resource Manager service connections should use the current Microsoft Entra issuer/default federation model. Older service connections that use the deprecated Azure DevOps issuer should be converted before its retirement date.

### Automatic Azure DevOps configuration

1. Open **Azure DevOps -> Project settings -> Service connections**.
2. Select **New service connection**.
3. Choose **Azure Resource Manager**.
4. Choose **App registration (automatic)** or the supported managed-identity option.
5. Select **Workload identity federation**.
6. Select the scope:
   - Management group,
   - Subscription, or
   - Resource group.
7. Give the service connection a clear name, such as `sc-prod-infra-wif`.
8. Assign only the required Azure role. For example, use Resource Group Contributor at a resource-group scope instead of Subscription Owner.
9. Under pipeline permissions, authorize only the pipelines that need the connection.
10. Verify the connection and run a test pipeline.

Azure DevOps creates or uses the Entra application/service principal and configures the federation trust. No reusable client secret needs to be stored in the pipeline.

### Manual configuration

Use manual configuration when automatic creation is not permitted or an existing enterprise app must be reused.

1. Create an app registration in Microsoft Entra ID.
2. Note the application/client ID, tenant ID and object ID.
3. Create the Azure DevOps Resource Manager service connection with manual workload-identity federation.
4. Copy the issuer, subject and audience values generated by the service connection.
5. Add a federated identity credential to the app registration using those exact values.
6. Assign the service principal the required Azure RBAC role at the smallest practical scope.
7. Save and verify the service connection.
8. Restrict pipeline permissions and protect Production environments with approvals.

The issuer, subject and audience must match exactly. A mismatch causes token exchange or login failure.

### Azure DevOps YAML example

```yaml
steps:
  - task: AzureCLI@2
    displayName: Verify Azure connection
    inputs:
      azureSubscription: sc-prod-infra-wif
      scriptType: bash
      scriptLocation: inlineScript
      inlineScript: |
        az account show --output table
        az group list --query "[].name" --output table
```

### Legacy secret-based method

If an older tool cannot use federation:

1. Create a client secret or certificate for the app registration.
2. Store it only in the secured service connection or approved secret store.
3. Set an expiry and ownership process.
4. Rotate it before expiry.

This is a fallback, not the preferred new design.

### Scenario-based example

> A Terraform pipeline used a two-year client secret and failed when the secret expired. We converted the service connection to workload identity federation, reduced its role from subscription-level Owner to resource-group-level Contributor, and limited service-connection use to the approved infrastructure pipeline. This removed secret rotation and reduced blast radius.

### Common failures

- Incorrect tenant, subscription or app ID.
- Federated issuer/subject/audience mismatch.
- RBAC assigned to the app registration object instead of the service principal object.
- Role assigned at the wrong scope.
- Service connection not authorized for the pipeline.
- Old WIF service connection still using a deprecated issuer.
- Azure task or third-party extension does not support WIF.

---

## 5. What is AWS Transit Gateway?

### Short interview answer

AWS Transit Gateway is a regional network transit hub that connects multiple VPCs and on-premises networks through a hub-and-spoke model. It provides transitive routing and centralized route tables, so organizations do not need a full mesh of VPC peering connections.

### Detailed answer

You can attach the following to a Transit Gateway:

- Multiple VPCs.
- Site-to-Site VPN connections.
- Direct Connect gateways.
- Other Transit Gateways through peering.
- Supported SD-WAN or network-appliance connections.

Each attachment is associated with a Transit Gateway route table. Route-table association and propagation decide which networks can communicate.

### When to use it

Use Transit Gateway when:

- Many VPCs need connectivity.
- You require transitive routing.
- You want a central connection to on-premises networks.
- Multiple AWS accounts share networking services.
- You need segmentation between Production, Non-Production and shared services.
- A full mesh of VPC peering connections would be difficult to manage.

### When not to use it

For only two VPCs with a simple direct requirement, VPC peering may be simpler and less expensive. Transit Gateway adds cost and centralized routing complexity.

### Example architecture

```text
                 On-premises
                      |
                VPN / Direct Connect
                      |
              AWS Transit Gateway
              /       |        \
       Prod VPC   Shared VPC   Dev VPC
```

Separate Transit Gateway route tables can prevent Development from reaching Production while still allowing both environments to reach shared DNS or inspection services.

### Scenario-based example

> The organization grew from 3 to 25 VPCs. Pairwise peering created too many route changes and had no transitive routing. We introduced Transit Gateway, attached each VPC, used separate route tables for Production and Non-Production, and routed internet-bound traffic through a central inspection VPC.

### Troubleshooting points

- Attachment state and association.
- Transit Gateway route table entries and propagation.
- VPC subnet route tables.
- Security groups and NACLs.
- Overlapping CIDRs.
- Return path and asymmetric routing.

---

## 6. When do we use an AWS Application Load Balancer?

### Short interview answer

I use an Application Load Balancer for HTTP and HTTPS applications that need Layer 7 routing, such as host-based or path-based routing, TLS termination, health checks, WAF integration and distribution across multiple application targets or Availability Zones.

### Good use cases

- Web applications and REST APIs.
- Microservices behind paths such as `/orders`, `/payments` and `/users`.
- Multiple domains routed by host name.
- ECS, EKS or EC2 application workloads.
- Blue/green or weighted target-group deployments.
- HTTPS termination and certificate management.
- AWS WAF protection and application-level routing.

### How it works

1. The client connects to the ALB listener, normally HTTP 80 or HTTPS 443.
2. Listener rules inspect host, path and other supported request information.
3. The request is sent to a target group.
4. Health checks ensure only healthy EC2 instances, IP targets, containers or supported functions receive traffic.
5. The ALB is placed across multiple Availability Zone subnets for high availability.

### Example

```text
api.example.com/orders/*   -> Orders target group
api.example.com/payments/* -> Payments target group
admin.example.com/*        -> Admin target group
```

### ALB versus NLB

| Application Load Balancer | Network Load Balancer |
|---|---|
| Layer 7 HTTP/HTTPS | Layer 4 TCP/UDP/TLS |
| Host/path routing | Very high-performance network routing |
| WAF and HTTP-aware features | Static-IP and low-latency use cases |
| Web apps and APIs | Non-HTTP protocols or extreme throughput |

### Scenario-based example

> Three microservices were running on ECS. We used one internet-facing ALB with HTTPS, an ACM certificate, WAF, host/path routing and separate target groups. Health checks prevented traffic from reaching an unhealthy orders service during a deployment.

### Common mistake

Do not choose ALB for a raw TCP database protocol or when the requirement specifically needs fixed front-end IP addresses. In those cases, evaluate NLB or another service.

---

## 7. What is Terraform drift?

### Short interview answer

Terraform drift is a difference between the infrastructure declared in Terraform, the Terraform state and the real cloud resources. It normally happens when somebody changes a managed resource manually, another automation tool changes it, or an external service updates a property.

### Example

Terraform code declares:

```hcl
resource "azurerm_network_security_rule" "https" {
  destination_port_range = "443"
  access                 = "Allow"
}
```

An administrator manually changes the rule in the Azure portal to allow port 80. The real infrastructure no longer matches the code, so drift exists.

### How to detect drift

- Run a normal `terraform plan` against the correct remote state and environment.
- Use `terraform plan -refresh-only` when you want to inspect changes detected during refresh without proposing configuration changes.
- Run scheduled plans in CI/CD.
- Use HCP Terraform drift detection where available.
- Use cloud-policy and activity logs to detect manual changes.

### How to resolve drift

Choose one approved source of truth:

1. **Manual change was not approved:** run Terraform apply to restore the configuration.
2. **Manual change is valid:** update Terraform code, review the plan and apply it.
3. **Existing resource was created outside Terraform:** import the resource and write matching configuration.
4. **Provider or platform changed a computed property:** confirm whether it is harmless, provider-managed or needs code/provider adjustment.

Do not directly edit the state file. Use supported Terraform state and import operations.

### Prevention

- Restrict manual changes to Terraform-managed resources.
- Use remote state and locking.
- Require pull requests and plan review.
- Run scheduled drift-detection pipelines.
- Apply Azure Policy, AWS Config or equivalent guardrails.
- Clearly define resource ownership between Terraform and other tools.

### Scenario-based example

> A Production NSG rule was opened manually during incident troubleshooting and was not removed. The nightly Terraform plan detected the difference. After confirming that the emergency access was no longer required, we applied the approved configuration and added a time-bound emergency-change process.

### Follow-up distinction

Drift is not the same as a normal planned change. A planned change starts in the code. Drift starts because the real infrastructure changed outside the approved Terraform configuration or state relationship.

---

## 8. What is a Terraform `data` block?

### Short interview answer

A Terraform `data` block reads information from an existing resource or external provider. It does not create, update or delete the resource. The returned values can be referenced by Terraform-managed resources so that IDs and properties do not need to be hardcoded.

### Azure example

```hcl
data "azurerm_resource_group" "shared" {
  name = "rg-shared-network-prod"
}

resource "azurerm_storage_account" "logs" {
  name                     = "stprodauditlogs001"
  resource_group_name      = data.azurerm_resource_group.shared.name
  location                 = data.azurerm_resource_group.shared.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
}
```

Terraform reads the existing resource group and uses its properties, but it does not manage that resource group.

### AWS example

```hcl
data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"]

  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd-gp3/ubuntu-noble-24.04-amd64-server-*"]
  }
}

resource "aws_instance" "app" {
  ami           = data.aws_ami.ubuntu.id
  instance_type = "t3.micro"
}
```

### Common use cases

- Look up an existing VNet, subnet, Key Vault or resource group.
- Select the latest approved machine image.
- Read the current AWS caller identity or Azure client configuration.
- Use output values from another Terraform configuration carefully.
- Query cloud regions, zones, policies or existing shared services.

### Important behavior

Terraform normally tries to read data sources during planning. If a data-source argument depends on a value that is not known until apply, the read can be deferred until the apply phase.

### `data` block versus `resource` block

| `data` block | `resource` block |
|---|---|
| Read-only lookup | Creates and manages infrastructure |
| Does not own resource lifecycle | Tracks resource lifecycle in state |
| Used to avoid hardcoded IDs | Used to declare desired resources |

### Scenario-based example

> The central networking team owned the Production VNet in a separate Terraform stack. The application stack used a data source to look up the approved subnet and deploy private endpoints into it, rather than duplicating or attempting to recreate the VNet.

### Common mistake

A data source does not import an existing resource into Terraform management. To manage that resource, write a `resource` block and use an import workflow.

---

## 9. How would you use Ansible?

### Short interview answer

I use Ansible for repeatable configuration management and application deployment after infrastructure is available. I define hosts in an inventory, write YAML playbooks using idempotent modules, organize reusable tasks as roles, protect secrets with Ansible Vault or an external secret manager, test in check mode and run the playbook from a controlled CI/CD pipeline.

### Where Ansible fits

Terraform and Ansible can complement each other:

```text
Terraform -> Creates networks, VMs, disks, identities and load balancers
Ansible   -> Configures operating systems, packages, services and application files
```

Terraform should not be used as a replacement for full configuration management through repeated remote-exec provisioners.

### Step-by-step approach

1. Install Ansible on a Linux control node or pipeline agent.
2. Configure secure connectivity:
   - SSH for Linux,
   - WinRM for Windows.
3. Create static or dynamic inventory.
4. Group hosts by role and environment.
5. Store environment variables in `group_vars` and host-specific values in `host_vars`.
6. Write playbooks with built-in or collection modules.
7. Convert reusable logic into roles.
8. Store secrets in Ansible Vault, Azure Key Vault, AWS Secrets Manager or another approved store.
9. Run syntax checks, `ansible-lint` and check mode.
10. Execute through CI/CD with approvals for Production.
11. Use `serial` for rolling updates and handlers for controlled service restarts.

### Simple inventory

```ini
[web]
10.10.1.10
10.10.1.11

[web:vars]
ansible_user=azureadmin
```

### Simple playbook

```yaml
---
- name: Configure web servers
  hosts: web
  become: true
  serial: 1

  tasks:
    - name: Install Nginx
      ansible.builtin.package:
        name: nginx
        state: present

    - name: Deploy Nginx configuration
      ansible.builtin.template:
        src: templates/nginx.conf.j2
        dest: /etc/nginx/nginx.conf
        mode: "0644"
      notify: Restart Nginx

    - name: Ensure Nginx is enabled and running
      ansible.builtin.service:
        name: nginx
        enabled: true
        state: started

  handlers:
    - name: Restart Nginx
      ansible.builtin.service:
        name: nginx
        state: restarted
```

Run commands:

```bash
ansible-inventory -i inventory.ini --graph
ansible all -i inventory.ini -m ping
ansible-playbook -i inventory.ini site.yml --syntax-check
ansible-playbook -i inventory.ini site.yml --check --diff
ansible-playbook -i inventory.ini site.yml
```

### Scenario-based example

> Terraform created ten Linux VMs behind a load balancer. Ansible used dynamic inventory to discover the VMs, installed the runtime, deployed the application configuration, pulled secrets at runtime and restarted the service only when the template changed. We used `serial: 2` so only two nodes were updated at a time.

### Security and operational best practices

- Do not store plaintext passwords or private keys in Git.
- Prefer SSH keys, managed identities and short-lived credentials.
- Use fully qualified collection names such as `ansible.builtin.package`.
- Pin collections and test changes in lower environments.
- Use idempotent modules rather than unrestricted shell commands.
- Limit target hosts and require Production approval.
- Capture playbook output and failed-host information in the pipeline.

---

## 10. Which DNS record is used to map the public IP of Azure Application Gateway?

### Direct interview answer

An **A record** maps a DNS name directly to the Application Gateway's IPv4 public IP address.

Example:

```text
app.example.com  A  20.30.40.50
```

### Important practical distinction

There are two valid patterns:

1. **A record** - maps a name directly to the static public IPv4 address.
2. **CNAME record** - maps a subdomain to the DNS name/FQDN configured on the Application Gateway public IP resource.

Example:

```text
app.example.com CNAME myappgateway.eastus.cloudapp.azure.com
```

For a subdomain, Microsoft commonly documents the CNAME-to-FQDN approach. For a root/apex domain, DNS providers normally require an A record or a provider-specific alias/ANAME feature because a standard CNAME is generally not used at the zone apex.

### What I would say in an interview

> If the question is specifically "map the public IP," the answer is an A record. If I am mapping a subdomain to the Application Gateway public DNS name, I use a CNAME. I also configure the HTTPS listener, certificate and host name to match the custom domain.

### Configuration steps

1. Assign a Standard static public IP to Application Gateway.
2. Optionally configure a DNS name label on that public IP.
3. Create the A or CNAME record in Azure DNS or the external DNS provider.
4. Configure the Application Gateway listener with the custom host name.
5. Bind a valid TLS certificate for that host name.
6. Validate DNS, listener rules, backend health and HTTPS access.

### Scenario-based example

> `portal.example.com` resolved correctly to the gateway, but users received a certificate-name error. DNS was not the problem; the HTTPS listener certificate covered a different host name. We installed the correct certificate and updated the listener binding.

---

## 11. What is an AWS IAM trust policy?

### Short interview answer

A trust policy is the resource-based policy attached to an IAM role that defines which principals are allowed to assume the role and under which conditions. It answers **who can become this role**. The permissions policies attached to the role answer **what the role can do after it is assumed**.

### Example trust policy for EC2

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "ec2.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

This allows the EC2 service to assume the role through an instance profile.

### Cross-account example

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::222233334444:role/DeploymentRole"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "approved-deployment-123"
        }
      }
    }
  ]
}
```

For cross-account access, two sides are normally required:

1. The target role trust policy trusts the source principal.
2. The source principal has permission to call `sts:AssumeRole` on the target role.

### Common principals

- AWS account.
- IAM user or role.
- AWS service such as EC2, Lambda or ECS tasks.
- Federated identity provider using SAML or OIDC.

### Security best practices

- Trust the most specific principal possible.
- Add conditions for organization ID, external ID, source account, source ARN, MFA or OIDC claims as appropriate.
- Avoid broad account-root or wildcard trust unless there is a reviewed reason.
- Review trust policies with IAM Access Analyzer.
- Use temporary credentials generated by STS.

### Scenario-based example

> A CI/CD account needed to deploy into a Production account. The Production role trusted only the deployment role from the CI/CD account and required an external ID. The deployment role had permission to assume only that specific Production role. The assumed Production role then had limited permissions to the target application resources.

### Trust policy versus permission policy

| Trust policy | Permission policy |
|---|---|
| Who can assume the role | What the role can do |
| Attached to the IAM role as its trust relationship | Attached as managed or inline permissions |
| Common action: `sts:AssumeRole` | Actions such as `s3:GetObject` or `ec2:DescribeInstances` |

---

## 12. Why are Infrastructure as Code tools such as Terraform idempotent?

### Short interview answer

Terraform is idempotent in normal declarative use because we describe the desired end state, and Terraform compares that configuration with its state and the real infrastructure. It creates, changes or deletes only what is required. If nothing has changed, running plan or apply again should produce no infrastructure change.

### Simple example

Configuration:

```hcl
resource "azurerm_resource_group" "app" {
  name     = "rg-app-prod"
  location = "Central India"
}
```

First apply:

```text
Plan: 1 to add, 0 to change, 0 to destroy
```

Second apply with no changes:

```text
No changes. Your infrastructure matches the configuration.
```

Terraform does not try to create a second resource group with the same declaration. It has a state binding between the resource block and the real Azure object.

### Why it works

Terraform combines:

1. **Declarative configuration** - what the end state should be.
2. **State** - which real object belongs to each resource address.
3. **Provider refresh/read operations** - what exists in the cloud now.
4. **Planning** - the difference between desired and actual state.
5. **Apply** - only the actions needed to reconcile the difference.

### Important caveat

Terraform is not automatically idempotent in every possible configuration. Idempotency can be weakened by:

- Non-idempotent `local-exec` or `remote-exec` scripts.
- Timestamps or random values that change every run without stable keepers.
- External systems modifying the same resource.
- Unstable provider behavior.
- APIs that return changing values.
- Poorly designed modules that force replacement unnecessarily.

For example, this can run an arbitrary command each time a replacement is triggered and must be designed carefully:

```hcl
provisioner "local-exec" {
  command = "./create-user.sh"
}
```

If the script blindly creates a new user each time, the overall workflow is not safely idempotent even though Terraform itself uses desired-state planning.

### Scenario-based example

> A pipeline applied the same approved Terraform plan to an unchanged environment. Terraform reported no changes, so no Azure API updates were made. Later, a manual NSG change created drift; the next plan showed a difference and Terraform proposed restoring the declared rule. That is desired-state reconciliation in action.

### Terraform versus an imperative script

An imperative script may say:

```text
Create resource group.
Create storage account.
Add firewall rule.
```

It must contain its own checks to avoid duplicate or failed operations. Terraform says what should exist, calculates the difference and attempts only the required actions.

---

## LTM Round 2 Rapid Revision

| Question | One-line answer |
|---|---|
| Secure S3 | Block public access, least privilege, TLS, encryption, versioning, private access and continuous audit |
| Connect subnets | Same VPC uses local routing; different VPCs use peering or Transit Gateway plus routes and security rules |
| Management Group | Azure governance scope above subscriptions with inherited Policy and RBAC |
| Pipeline app registration | Use an ARM service connection with workload identity federation and least-privilege RBAC |
| Transit Gateway | Central AWS routing hub for VPCs, VPN and Direct Connect |
| ALB | Layer 7 HTTP/HTTPS load balancing with host/path routing and health checks |
| Terraform drift | Real infrastructure differs from code/state |
| Terraform data block | Read-only lookup of existing/provider information |
| Ansible | Inventory plus YAML playbooks for repeatable configuration and deployment |
| App Gateway DNS | A record to public IP; CNAME to public-IP FQDN for a subdomain |
| Trust policy | Defines who can assume an AWS IAM role |
| Terraform idempotency | Repeated apply makes only the changes needed to reach desired state |

## Official references

## AWS

- [Amazon S3 security best practices](https://docs.aws.amazon.com/AmazonS3/latest/userguide/security-best-practices.html)
- [S3 Block Public Access](https://docs.aws.amazon.com/AmazonS3/latest/userguide/access-control-block-public-access.html)
- [Amazon VPC subnet route tables](https://docs.aws.amazon.com/vpc/latest/userguide/subnet-route-tables.html)
- [Amazon VPC peering](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-peering.html)
- [AWS Transit Gateway overview](https://docs.aws.amazon.com/vpc/latest/tgw/what-is-transit-gateway.html)
- [Application Load Balancer overview](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/introduction.html)
- [AWS IAM roles and trust policies](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles.html)

## Microsoft Azure

- [Azure Management Groups](https://learn.microsoft.com/azure/governance/management-groups/overview)
- [Use an Azure Resource Manager service connection](https://learn.microsoft.com/azure/devops/pipelines/library/connect-to-azure)
- [Microsoft Entra federated identity credentials](https://learn.microsoft.com/entra/workload-id/workload-identity-federation-create-trust)
- [Convert older Azure DevOps workload-identity service connections](https://learn.microsoft.com/azure/devops/pipelines/release/convert-service-connections)
- [Application Gateway custom DNS guidance](https://learn.microsoft.com/azure/application-gateway/configure-web-app)

## Terraform and Ansible

- [Terraform state](https://developer.hashicorp.com/terraform/language/state)
- [Manage Terraform resource drift](https://developer.hashicorp.com/terraform/tutorials/state/resource-drift)
- [Terraform data sources](https://developer.hashicorp.com/terraform/language/data-sources)
- [Ansible playbooks](https://docs.ansible.com/projects/ansible/latest/playbook_guide/index.html)
- [Ansible inventory](https://docs.ansible.com/projects/ansible/latest/inventory_guide/intro_inventory.html)
