# 01 - Profile, Introduction and Current Project

This chapter gives interview-ready answers for profile, project and daily-responsibility questions. The sample project narrative uses the industrial monitoring details provided during preparation. Keep only the statements that are true for your actual work.

---

## 1. Tell me about yourself with project details

### Short interview answer

My name is Amritpal Singh. I have more than 15 years of progressive IT experience, with recent experience focused on Microsoft Azure infrastructure, DevOps automation and secure cloud operations. I work with Azure DevOps, Terraform, ARM/Bicep, PowerShell, Bash, Azure CLI, Git, Azure Monitor, Entra ID and core Azure networking and compute services.

In my current role, I support Azure infrastructure automation and CI/CD delivery across Development, QA and Production environments. My main contribution is to provision repeatable infrastructure, maintain build and release pipelines, improve monitoring and security, and reduce manual operational work.

### Detailed interview answer

Thank you for giving me the opportunity to introduce myself.

My name is **Amritpal Singh**. I have more than **15 years of IT experience** across infrastructure operations, systems administration, cloud services, automation and service delivery. During the recent part of my career, my focus has moved toward **Azure Cloud, Azure DevOps, Infrastructure as Code and secure cloud operations**.

My primary technical skills include:

- Microsoft Azure infrastructure: virtual machines, VNets, subnets, NSGs, storage, Azure Backup, Site Recovery, Azure Monitor, Key Vault, Azure Firewall, Load Balancer, Application Gateway and VNet peering.
- CI/CD: Azure DevOps Repos and Pipelines, GitHub Actions, multi-stage deployment and approval gates.
- Infrastructure as Code: Terraform and ARM/Bicep with remote state and environment isolation.
- Automation: PowerShell, Bash and Azure CLI.
- Identity and security: Entra ID, Conditional Access, MFA, SSPR, SSO, RBAC and hybrid identity.
- Monitoring: Azure Monitor, Log Analytics and Application Insights.
- Operating systems: Windows Server and Linux.

A sample project that I use to explain my Azure DevOps responsibilities is an **industrial monitoring and alerting platform**. The business has multiple operational sites with industrial IoT devices connected to motors and other equipment. These devices send telemetry such as temperature, vibration and performance data to **Azure Event Hubs**. The application processes this data and presents it through a monitoring and alerting dashboard.

The application is a three-tier solution:

- React-based frontend.
- Python-based backend services.
- A managed PostgreSQL or SQL database, depending on the final implementation.

The Azure entry point is an **Application Gateway with WAF and TLS**. The application workloads run across multiple instances for availability, private administrative access is provided through **Azure Bastion**, and secrets are stored in **Azure Key Vault**. Monitoring is implemented with Azure Monitor, Log Analytics and Application Insights.

My responsibilities include designing the Azure foundation, provisioning resources with Terraform, separating Dev/QA/Production state and configuration, creating and maintaining CI/CD pipelines, implementing networking and access controls, troubleshooting deployments, and working with application, security and network teams.

### Scenario-based version

> In one environment, application teams were manually requesting VNets, VMs, NSGs and monitoring configuration. This created delays and differences between Dev and Production. I helped standardize the deployment through Terraform modules and Azure DevOps pipelines. A pull request generated a Terraform plan, reviewers checked the changes, and the approved pipeline deployed to the selected environment. This reduced manual effort and made the infrastructure more consistent.

### Strong closing line

My strength is that I can work across infrastructure operations and automation. I can troubleshoot an Azure issue manually, identify the root cause, and then convert the permanent fix into Terraform, PowerShell or a CI/CD control.

---

## 2. Explain your day-to-day activities and team contribution

### Interview answer

My day normally starts by reviewing Azure Monitor alerts, Service Health notifications, failed backup or patch jobs, open incidents and failed pipeline runs. I then join the daily stand-up and confirm priorities, dependencies and production changes.

My common activities are:

1. Provisioning or modifying Azure resources through Terraform.
2. Reviewing pull requests and Terraform plans.
3. Maintaining Azure DevOps or GitHub Actions workflows.
4. Troubleshooting VM, networking, DNS, storage, identity or pipeline issues.
5. Managing RBAC and access requests using least privilege.
6. Reviewing backup, update and monitoring compliance.
7. Coordinating with developers, security, networking and service-management teams.
8. Updating runbooks, architecture notes and root-cause documents.

### Team contribution

I contribute by creating reusable modules and pipeline templates, reviewing other engineers' code, improving operational documentation, helping with incident resolution and automating repetitive work. I also support release calls and production change windows when infrastructure changes are required.

### Scenario-based example

> A deployment repeatedly failed because the pipeline identity could create resources but could not write Terraform state to the storage container. I checked the pipeline logs, separated management-plane and storage data-plane permissions, and assigned the required Blob data role at the correct scope. I then documented the permission model so the same issue did not repeat in other environments.

---

## 3. What is the difference between infrastructure and application?

### Simple answer

Infrastructure is the platform on which the software runs. The application is the business software that users interact with.

| Infrastructure | Application |
|---|---|
| VNets, subnets, DNS, compute, storage, load balancers and identity | Frontend, API, background service, database schema and business logic |
| Focuses on availability, connectivity, security and capacity | Focuses on features, user experience and business transactions |
| Usually managed by cloud/platform/infrastructure teams | Usually managed by developers and application-support teams |
| Example: Application Gateway and VM Scale Set | Example: React frontend and Python API |

### Detailed answer

Infrastructure includes the shared technical foundation: subscriptions, resource groups, virtual networks, virtual machines, Kubernetes clusters, App Service plans, storage, DNS, firewalls, monitoring and access controls.

The application includes the source code, APIs, libraries, configuration, database schema and business rules that deliver the required functionality.

DevOps connects both sides. The infrastructure team provides a secure, repeatable platform, while the application team builds and operates the software. CI/CD automates how both infrastructure and application changes move through environments.

### Troubleshooting example

- If Application Gateway cannot reach the backend because of an NSG rule, it is mainly an infrastructure issue.
- If the gateway reaches the backend but the API returns HTTP 500 due to a code defect, it is mainly an application issue.
- If the app is using the wrong Key Vault secret name, both teams may need to investigate together.

---

## 4. What is the aim of your project?

### Interview answer

The aim of the project is to provide a secure, scalable and automated Azure platform for an industrial monitoring and alerting application. The application receives equipment telemetry, processes it and helps operations teams identify abnormal conditions before they result in downtime.

From the DevOps perspective, the project aims to:

- Provision repeatable Dev, QA and Production environments.
- Reduce manual infrastructure work.
- Improve release consistency through CI/CD.
- Secure the environment through private networking, RBAC, Key Vault and policy controls.
- Improve availability through multiple application instances and health-based routing.
- Provide centralized logs, metrics and alerts.
- Make recovery and troubleshooting faster.

### Scenario-based example

> Earlier, an environment could take several days to prepare because each resource was created manually. By using Terraform modules and pipelines, a standard environment could be planned, reviewed and deployed in a controlled manner. The business benefit was faster onboarding and fewer configuration differences.

---

## 5. Explain the current project architecture

### Architecture summary

```mermaid
flowchart LR
    IoT[Industrial IoT Devices] --> EH[Azure Event Hubs]
    Users[Operations Users] --> AGW[Application Gateway + WAF + TLS]
    AGW --> FE[Frontend Instances - React]
    FE --> BE[Backend Instances - Python]
    BE --> DB[(Managed PostgreSQL or SQL)]
    BE --> EH
    BE --> KV[Azure Key Vault]
    FE --> MON[Application Insights]
    BE --> MON
    AGW --> LAW[Log Analytics]
    VMs[Private VMs] --- BAS[Azure Bastion]
```

### Interview explanation

The industrial devices publish telemetry to Azure Event Hubs. The backend consumes the data, applies processing and alert logic, and stores required information in a managed database. Users access the dashboard through Application Gateway.

Application Gateway provides TLS termination, WAF protection, routing and backend health checks. Frontend and backend resources are deployed in separate network segments where possible. The VMs do not require direct public IP addresses, and administrators connect through Azure Bastion or private corporate connectivity.

Application credentials are stored in Azure Key Vault. Azure Monitor, Log Analytics and Application Insights provide platform and application observability.

### Security measures

- No direct administrative access from the public internet.
- Separate subnets and NSGs for gateway, frontend, backend and private endpoints.
- TLS for user and service communication.
- Key Vault for secrets and certificates.
- Managed identity where supported.
- Least-privilege RBAC.
- Central diagnostics and alerts.
- Backup and recovery policy for stateful services.

---

## 6. What infrastructure have you provisioned?

### Interview answer

I have worked with or prepared Terraform modules for resources such as:

- Resource groups.
- VNets, subnets, NSGs and VNet peering.
- Windows and Linux VMs.
- Load Balancer and Application Gateway.
- Storage accounts.
- Key Vault.
- Azure Monitor, Log Analytics and diagnostic settings.
- Azure Backup and Site Recovery-related configuration.
- RBAC role assignments.
- Private endpoints and DNS integration where required.

### Safe way to describe experience

Use wording such as:

> I have hands-on experience with Azure infrastructure, Terraform, Azure DevOps pipelines, monitoring, identity and automation. I have working familiarity with Docker and AKS and can explain their deployment and security model, but I do not present advanced Kubernetes administration as my strongest production area.

This answer is stronger than overstating experience that may not survive follow-up questions.

---

## 7. How is the application deployed?

### Interview answer

The application deployment is automated through a multi-stage CI/CD pipeline.

A typical flow is:

```text
Pull Request -> Build -> Unit Test -> Code Scan -> Package -> Publish Artifact
             -> Deploy Dev -> Smoke Test -> Deploy QA -> Approval -> Deploy Prod
```

For containerized applications, the artifact is a versioned container image stored in Azure Container Registry. For VM- or App-Service-based applications, the pipeline publishes a package and deploys that same immutable version across environments.

Infrastructure and application pipelines are separated where possible. Terraform provisions the platform, and the application pipeline deploys the code onto the approved platform.

### Scenario-based example

> A release was failing only in QA. I compared the pipeline variables, artifact version and application settings between Dev and QA. The artifact was correct, but QA used an outdated Key Vault secret reference. After correcting the configuration and adding a pre-deployment validation, the same issue was prevented in Production.

---

## 8. What technologies are being used?

### Project technology summary

- Microsoft Azure.
- Azure Event Hubs.
- Application Gateway and WAF.
- Azure virtual networking and private access.
- Windows/Linux virtual machines or approved Azure compute platform.
- Managed PostgreSQL or SQL database.
- Azure Key Vault.
- Azure Monitor, Log Analytics and Application Insights.
- Terraform and ARM/Bicep.
- Azure DevOps and GitHub Actions.
- Git and pull-request workflows.
- PowerShell, Bash and Azure CLI.
- React frontend and Python backend.
- Docker and AKS as working-familiarity topics where applicable.

### Interview tip

Do not read the full list without context. Group it into categories: cloud, infrastructure as code, CI/CD, application stack, security and monitoring.
