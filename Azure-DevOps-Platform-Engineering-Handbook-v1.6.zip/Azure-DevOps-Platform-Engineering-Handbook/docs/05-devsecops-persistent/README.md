# 05 - Persistent DevSecOps Interview Questions

This chapter answers every Persistent interview question shared during preparation. The examples show a production-style implementation, but you should clearly distinguish between tools used hands-on and tools learned for interview preparation.

---

# A. DevSecOps Fundamentals

## 1. What is your understanding of DevSecOps?

### Short interview answer

DevSecOps means integrating security into the complete software delivery lifecycle instead of performing security only at the end. Developers, operations and security teams share responsibility, and automated controls check code, dependencies, secrets, infrastructure, containers and deployed applications throughout CI/CD.

### Detailed answer

Traditional delivery often treats security as a final approval before Production. That approach detects issues late, when fixes are expensive and release pressure is high. DevSecOps shifts security earlier while also maintaining runtime monitoring after deployment.

A DevSecOps process normally includes:

- Threat modelling and secure design.
- Secure coding standards.
- Peer review and branch protection.
- Secret scanning.
- SAST for source-code weaknesses.
- SCA for vulnerable dependencies and licenses.
- IaC scanning for Terraform/Bicep/Kubernetes configuration.
- Container image scanning.
- DAST or API security testing in a running environment.
- Artifact integrity, SBOM and signing where required.
- Policy gates and controlled exceptions.
- Runtime monitoring and vulnerability management.

The goal is not to add many tools. The goal is to reduce risk while keeping delivery fast and repeatable.

---

## 2. Can you explain DevSecOps in detail?

### Lifecycle view

```text
Plan -> Code -> Build -> Test -> Package -> Deploy -> Operate -> Monitor
  |       |       |       |        |         |         |         |
Threat  Secret   SAST    SCA     Image      IaC      Runtime   Incident
Model   Scan             Test    Scan       Policy   Security  Feedback
```

### People

- Developers fix code and dependency findings.
- Platform/DevOps engineers build secure pipelines and deployment controls.
- Security teams define policies, threat models and risk acceptance.
- Operations teams monitor runtime behavior and incidents.
- Product owners prioritize remediation based on business risk.

### Process

- Define severity thresholds and remediation SLAs.
- Separate new findings from accepted legacy debt.
- Make exceptions time-bound and approved.
- Store evidence for audit.
- Feed runtime incidents back into design and pipeline controls.

### Technology

A possible toolchain is:

- Git and pull requests.
- SonarQube for code quality/SAST-related analysis.
- Dependency scanning such as Dependabot or another SCA tool.
- Trivy for images, filesystems, secrets and misconfiguration scanning.
- tfsec or `trivy config` for Terraform.
- Azure Key Vault for secrets.
- Azure DevOps, GitHub Actions or Jenkins for orchestration.
- Defender for Cloud/Containers and Azure Monitor for runtime visibility.

---

## 3. Give a practical example of DevSecOps

### Scenario

A developer changes Terraform to create an Azure Storage Account and enables public access.

The pull-request pipeline performs:

1. `terraform fmt` and `terraform validate`.
2. tfsec or Trivy configuration scan.
3. Terraform plan.
4. Policy checks.

The IaC scanner reports that the storage account permits public network access. Because the finding is High severity and violates the company's baseline, the pipeline fails before deployment. The developer changes the configuration to use private access, updates networking and reruns the pipeline. Azure Policy also acts as a final platform guardrail if an unsafe change reaches deployment.

This is DevSecOps because the issue is identified automatically during development, the developer receives immediate feedback, and the cloud platform has a second preventive control.

---

## 4. What security best practices do you recommend during SDLC?

### Planning and design

- Classify data and compliance needs.
- Perform threat modelling for important features.
- Define trust boundaries and abuse cases.
- Use approved architectures and libraries.

### Source control

- Protect main branches.
- Require pull requests and peer review.
- Use CODEOWNERS for sensitive areas.
- Require signed commits/tags where policy requires.
- Enable secret scanning.

### Build and test

- Pin and update dependencies.
- Run unit, integration and security tests.
- Use SAST, SCA, secret and IaC scanning.
- Use isolated, ephemeral build agents where possible.
- Keep build credentials short-lived.

### Artifact security

- Build once and promote the same artifact.
- Store artifacts in a controlled registry.
- Generate an SBOM where required.
- Sign artifacts/images for higher-assurance environments.
- Scan images before release and monitor new CVEs after release.

### Deployment

- Use IaC and Git-based review.
- Use managed identity/OIDC instead of long-lived secrets.
- Separate Production permissions.
- Use approvals and health checks.
- Use least privilege and private networking.

### Operations

- Centralize logs and alerts.
- Patch supported platforms.
- Rotate secrets and certificates.
- Track vulnerabilities to closure.
- Test incident response, backup and recovery.

---

## 5. If you had to lead a DevSecOps project, what would your approach be?

### Step-by-step answer

1. **Assess current maturity:** applications, pipelines, tools, security findings, release speed and pain points.
2. **Identify crown-jewel systems:** prioritize high-risk applications rather than applying the same controls blindly.
3. **Define security baseline:** required scans, thresholds, SLAs, exceptions and ownership.
4. **Choose a pilot:** select one cooperative team and representative application.
5. **Build reusable controls:** pipeline templates, scan configuration, reporting and dashboards.
6. **Start in audit mode:** collect findings and remove noise before blocking builds.
7. **Introduce progressive enforcement:** block clear, fixable Critical findings first, then expand.
8. **Integrate ticketing and ownership:** every finding needs an owner, due date and evidence.
9. **Train developers:** explain how to fix issues, not only how to read tool output.
10. **Measure outcomes:** escaped vulnerabilities, remediation time, pipeline time, false-positive rate and adoption.
11. **Scale through templates:** onboard more repositories without rebuilding the process each time.
12. **Continuously improve:** update policy based on incidents and threat intelligence.

### Scenario

> Instead of enabling blocking scans for 50 applications on day one, I would scan all repositories in reporting mode, establish a baseline, tune rules, then enforce Critical fixable vulnerabilities on newly changed code and images. This prevents sudden disruption while still moving toward stronger enforcement.

---

## 6. What kind of DevSecOps work have you done in your current project?

### Resume-aligned answer

My current hands-on work is strongest in secure Azure infrastructure operations, Terraform, Azure DevOps pipelines, Git controls, identity, monitoring and automation. I work with pull-request-based infrastructure changes, remote state, approval gates, RBAC, Key Vault, Conditional Access and centralized monitoring.

For tools such as SonarQube, Trivy and tfsec, use one of these answers depending on truth:

### When used hands-on

> I integrated SonarQube for code analysis, Trivy for image scanning and tfsec for Terraform scanning. Pull requests ran the scans, results were published to the pipeline, and the build failed for policy-defined findings. Exceptions required security approval and an expiry date.

### When learned but not owned in Production

> My direct project ownership has focused on Azure infrastructure, Terraform and Azure DevOps. I understand how SonarQube, Trivy and tfsec integrate into CI/CD and have practised the implementation, but I would not claim that I owned every tool in Production.

Honesty is important because interviewers may ask for exact commands, configuration files, false-positive handling and real findings.

---

# B. CI/CD Pipeline

## 7. Explain your complete CI/CD pipeline

### Application CI flow

```text
PR Trigger
-> Checkout
-> Restore Dependencies
-> Lint
-> Unit Tests + Coverage
-> Secret Scan
-> SAST / SonarQube
-> SCA / Dependency Scan
-> Build
-> Container Build
-> Trivy Image Scan
-> Publish Signed/Versioned Artifact
```

### Infrastructure CI flow

```text
PR Trigger
-> terraform fmt
-> terraform init -backend=false or approved backend
-> terraform validate
-> TFLint
-> tfsec / trivy config
-> terraform plan
-> Publish Plan and Scan Reports
-> Peer Review
```

### CD flow

```text
Deploy Dev
-> Smoke Test
-> Deploy QA
-> Integration/DAST Test
-> Approval
-> Deploy Production
-> Health Check
-> Monitor
-> Rollback if required
```

### Security and governance

- Protected branch and required reviews.
- OIDC/workload identity federation.
- Key Vault integration.
- Separate Production permissions.
- Environment approvals.
- Immutable artifacts.
- Audit evidence and report retention.
- Time-bound exceptions.

### Scenario

> The image was built once, tagged with the commit SHA, scanned and stored in ACR. Dev, QA and Production referenced the same digest. Only configuration changed by environment, so Production received the exact artifact tested in QA.

---

## 8. Which security tools have you integrated into your pipeline?

### Example interview answer

A typical pipeline can include:

- SonarQube for static analysis and quality gates.
- Trivy for container image, filesystem, secret and misconfiguration scanning.
- tfsec or Trivy configuration scanning for Terraform.
- Dependency/SCA tooling for vulnerable open-source packages.
- GitHub secret scanning or another secret-detection tool.
- DAST in a deployed test environment.
- Defender for Cloud/Containers for runtime findings.

### Safe wording

State clearly which tools you used directly and which you understand conceptually. The interviewer may ask how each tool is installed, invoked, authenticated and configured to fail a build.

---

## 9. How did you integrate SonarQube, Trivy and tfsec into CI/CD?

### SonarQube

- Create a project and token or use supported CI integration.
- Store the token in a secure secret store.
- Run the appropriate scanner after checkout/build preparation.
- Publish or wait for the quality-gate result.
- Fail the pipeline if the quality gate fails according to policy.

### Trivy

- Install the CLI or use an approved container/action/task.
- Scan the image after build and before push/deployment, or scan after push by immutable digest.
- Use `--severity` and `--exit-code` to enforce policy.
- Save JSON/SARIF reports for evidence.
- Use an ignore file only with approved, time-bound exceptions.

### tfsec

- Run after Terraform formatting/validation and before apply.
- Load `.tfsec/config.yml` and custom checks where required.
- Publish the report.
- Let the non-zero exit code fail the CI stage for configured severities.

### Azure DevOps stage example

```yaml
- script: sonar-scanner -Dsonar.qualitygate.wait=true
  displayName: SonarQube analysis
  env:
    SONAR_TOKEN: $(SONAR_TOKEN)

- script: tfsec . --minimum-severity HIGH
  displayName: Terraform security scan

- script: trivy image --exit-code 1 --severity CRITICAL,HIGH $(IMAGE_NAME):$(Build.BuildId)
  displayName: Container vulnerability scan
```

Do not print tokens or use `set -x` around secret-bearing commands.

---

## 10. How are these tools invoked from the pipeline?

### Answer

They are invoked as command-line steps, official CI tasks/actions or containers.

Examples:

```bash
sonar-scanner \
  -Dsonar.projectKey=my-api \
  -Dsonar.host.url="$SONAR_HOST_URL" \
  -Dsonar.token="$SONAR_TOKEN" \
  -Dsonar.qualitygate.wait=true
```

```bash
tfsec ./terraform --minimum-severity HIGH
```

```bash
trivy image \
  --exit-code 1 \
  --severity CRITICAL,HIGH \
  --ignore-unfixed \
  myregistry.azurecr.io/my-api:${BUILD_ID}
```

The pipeline agent must have network access to SonarQube, package feeds, registries and vulnerability databases.

---

## 11. How do you implement these stages in Azure DevOps or Jenkins?

### Azure DevOps

Use YAML stages/jobs with conditions, variable groups, Key Vault-linked secrets, service connections, artifacts and environments.

```text
stages:
  Validate
  Security
  Build
  Publish
  Deploy_Dev
  Deploy_QA
  Deploy_Prod
```

### Jenkins

Use a declarative Jenkinsfile with stages, agents, credentials binding, post actions and quality-gate waiting.

```text
pipeline {
  agent any
  stages {
    stage('Checkout')
    stage('Test')
    stage('SonarQube')
    stage('Terraform Security')
    stage('Build Image')
    stage('Trivy')
    stage('Deploy')
  }
}
```

### Design principle

The orchestration syntax differs, but the security policy should remain consistent across CI tools. Reusable templates or Jenkins shared libraries reduce duplication.

---

# C. Vulnerability Management

## 12. What happens if Trivy detects vulnerabilities?

### Answer

Trivy reports the vulnerability ID, affected package, installed version, fixed version when available and severity. Whether the pipeline fails depends on the command configuration.

Example:

```bash
trivy image --exit-code 1 --severity CRITICAL,HIGH myimage:1.0
```

This returns a non-zero exit code when matching findings are present, so the pipeline fails unless the CI step is explicitly configured to continue.

### Next actions

- Confirm the vulnerable package and source layer.
- Check whether a fixed version exists.
- Update the base image or package.
- Rebuild and rescan.
- If no fix exists, assess exploitability and compensating controls.
- Use an exception only with owner, business justification and expiry.

---

## 13. What happens when tfsec reports vulnerabilities?

### Answer

tfsec reports insecure Terraform configuration with a check ID, severity, affected file/line, impact and recommended resolution. In CI, a non-zero exit code normally fails the stage when findings meet the configured threshold.

The developer fixes the Terraform code, for example by disabling public access, enabling encryption, restricting an NSG or adding required logging. The pipeline reruns and must pass before merge.

### Important point

tfsec checks configuration before deployment. Azure Policy and Defender for Cloud provide additional platform/runtime controls. One tool does not replace the others.

---

## 14. What vulnerability thresholds do you configure?

### Interview answer

Thresholds should be risk-based and agreed with security and product owners. A common starting point is:

- Block Critical vulnerabilities with a vendor fix.
- Block High vulnerabilities for internet-facing or sensitive workloads, especially on new code/images.
- Report Medium and Low for remediation planning.
- Treat actively exploited vulnerabilities more strictly regardless of score.
- Use lower tolerance for Production and regulated workloads.

### Factors beyond severity

- Is the vulnerable component reachable?
- Is a fixed version available?
- Is exploit code known or active exploitation reported?
- Is the service internet-facing?
- What data and privilege are exposed?
- Are compensating controls effective?
- Is the finding new or accepted legacy debt?

### Example policy

```text
Pull Request: block new Critical and High fixable findings.
Nightly scan: report all severities and create tickets.
Production deploy: block Critical, active exploitation and policy violations.
```

---

## 15. How do you decide whether the pipeline should fail?

### Decision model

The pipeline should fail when the finding:

- Exceeds the approved severity threshold.
- Has a fix and is introduced by the current change.
- Violates a mandatory compliance or architecture policy.
- Exposes secrets.
- Enables unsafe public access.
- Represents an actively exploited or business-critical risk.

It may report without blocking when:

- The issue is pre-existing and being handled through a documented backlog.
- No fix exists and compensating controls are approved.
- The scanner produces a confirmed false positive.
- The environment is an early audit-only rollout.

### Governance

Developers should not bypass the scan by editing the pipeline. Exceptions should be stored in a controlled file or system, reviewed by security, linked to a ticket and given an expiry date.

---

## 16. How do you configure policies in Trivy?

### Basic CLI policy

```bash
trivy image \
  --severity CRITICAL,HIGH \
  --ignore-unfixed \
  --exit-code 1 \
  myimage:tag
```

### Configuration file

A repository or central Trivy configuration can define severity, scanners and exit behavior. Keep one centrally reviewed baseline and allow only controlled application overrides.

### Ignore files

Use `.trivyignore` or `.trivyignore.yaml` for approved suppression. The exception process should record:

- Finding ID.
- Reason.
- Owner.
- Compensating control.
- Ticket.
- Expiry/review date.

### Rego policy

For advanced filtering or misconfiguration policy, Trivy can use Rego/OPA-based logic. Treat experimental filtering features carefully and test version compatibility.

### Important answer

Policy is more than a command flag. It includes severity, fix availability, asset exposure, exception governance, remediation SLA and reporting.

---

## 17. Do you know about Progressive Enforcement?

### Answer

Progressive Enforcement means introducing security gates in stages so teams improve without suddenly blocking all delivery.

### Example phases

1. **Visibility:** scans run but do not fail builds.
2. **Critical only:** fail new, fixable Critical findings.
3. **Critical + High on new changes:** legacy findings remain tracked separately.
4. **Broader policy:** include mandatory configuration and selected Medium risks.
5. **Continuous improvement:** reduce exceptions and update rules based on incidents.

### Scenario

> A portfolio had thousands of legacy findings. Blocking everything would stop releases. We first created a baseline, then failed only new Critical/High findings. Existing debt received owners and deadlines. Over time, the baseline was reduced and enforcement expanded.

---

# D. SonarQube

## 18. What command is used to invoke SonarQube scan?

### Generic SonarScanner CLI

```bash
sonar-scanner \
  -Dsonar.projectKey=my-project \
  -Dsonar.sources=. \
  -Dsonar.host.url="$SONAR_HOST_URL" \
  -Dsonar.token="$SONAR_TOKEN"
```

### Maven

```bash
mvn clean verify sonar:sonar
```

### Gradle

```bash
./gradlew clean test sonar
```

### .NET

```bash
dotnet sonarscanner begin /k:"my-project" /d:sonar.token="$SONAR_TOKEN"
dotnet build
dotnet sonarscanner end /d:sonar.token="$SONAR_TOKEN"
```

The exact command depends on the language and scanner. Avoid exposing the token in logs.

---

## 19. How is SonarQube integrated into your pipeline?

### Answer

1. SonarQube project and quality gate are configured.
2. A secure token or CI integration is created.
3. The pipeline checks out the full required Git history.
4. The application is prepared/built as required by the scanner.
5. The scanner runs and uploads the analysis report.
6. SonarQube computes results.
7. The pipeline waits for or publishes the quality-gate result.
8. The merge/deployment is blocked if the gate fails according to policy.

### Quality gate examples

- No new blocker/critical issues.
- Required coverage on new code.
- Limited duplication on new code.
- Security hotspots reviewed.

The exact conditions should be set centrally and tuned for the language and business risk.

---

## 20. Is SonarQube configured at repository level or branch level?

### Correct answer

The SonarQube **project** is normally associated with a repository or application. Analysis runs can be performed for the main branch, supported additional branches and pull requests.

Quality profiles and quality gates are generally project-level standards. The quality gate cannot normally be independently changed for each branch, although the new-code definition can be configured by branch in supported editions.

Branch analysis availability depends on the SonarQube edition or SonarQube Cloud plan.

---

## 21. Why is SonarQube configured at branch level?

### Answer

Branch or pull-request analysis gives developers feedback before code is merged. It allows the team to focus on issues introduced by the current change and protects the main branch.

Typical use:

- Pull request: analyze changed/new code and show decoration.
- Main branch: maintain the complete project trend and release health.
- Release branch: monitor supported long-lived versions when the edition supports it.

### Scenario

> A pull request introduced an SQL injection pattern. SonarQube reported the issue on the PR, the quality gate failed and the developer corrected parameter handling before merge.

---

## 22. Is a SonarQube scan incremental or full?

### Accurate answer

Do not answer simply “always incremental” or “always full.” The scanner analyzes the project within its configured scope each run, while some analyzers use caches and incremental mechanisms to avoid repeating unchanged work. SonarQube also emphasizes **new code** for quality gates, but the server still maintains overall project analysis.

The behavior depends on language analyzer, scanner, branch/PR context and cache availability.

---

## 23. Can you force SonarQube to perform a full scan?

### Answer

There is no universal `sonar.fullScan=true` switch for every scanner and language. To obtain a clean reanalysis, use a clean checkout/build workspace, remove local analysis output such as `.scannerwork`, avoid restoring the scanner analysis cache for that run, and rerun the normal scanner command.

For compiled languages, perform a clean build. If a CI or language-specific cache is causing a problem, invalidate only that relevant cache. Server-side analysis behavior is managed by SonarQube and its analyzers.

### Example

```bash
rm -rf .scannerwork
mvn clean verify sonar:sonar
```

### Warning

Do not routinely delete all caches. It slows pipelines and normally does not improve results. Use clean analysis when troubleshooting stale or corrupted local state.

---

## 24. How would you configure a clean/full reanalysis?

### Steps

1. Use a fresh CI workspace or clean checkout.
2. Fetch sufficient Git history for blame/new-code analysis.
3. Delete build outputs and `.scannerwork`.
4. Run the clean build/test command.
5. Run the scanner with the same project key and correct branch/PR parameters.
6. Do not restore the analysis cache for that diagnostic run.
7. Compare scanner and Compute Engine logs if results remain unexpected.

### Interview note

Explain that “full scan” is a troubleshooting concept, not usually a separate everyday pipeline mode.

---

# E. Terraform Security

## 25. At what stage do you run tfsec?

### Answer

I run tfsec in the pull-request CI stage after checkout and usually after `terraform fmt`/`terraform validate`, but before `terraform plan` approval and definitely before `terraform apply`.

A good order is:

```text
fmt -> init -> validate -> lint -> tfsec/trivy config -> plan -> review -> apply
```

Running early gives fast feedback and avoids wasting time on an unsafe deployment plan.

---

## 26. Is tfsec executed during CI or CD?

### Answer

Primarily during **CI**, because it scans Terraform code before deployment. It can also run again in the CD pipeline as a defence-in-depth check, especially when the deploy pipeline can be triggered independently, but the main feedback should occur in the pull request.

---

## 27. What command do you use to run tfsec?

```bash
tfsec ./terraform --minimum-severity HIGH
```

For a report:

```bash
tfsec ./terraform \
  --minimum-severity HIGH \
  --format sarif \
  --out tfsec.sarif
```

A modern alternative for consolidated scanning is:

```bash
trivy config ./terraform
```

Use the tool and version approved by the organization.

---

## 28. How do you configure tfsec policies?

### Configuration

Place configuration in `.tfsec/config.yml` or supply `--config-file`.

Example:

```yaml
minimum_severity: HIGH
exclude:
  - approved-check-id
severity_overrides:
  selected-check-id: CRITICAL
```

### Custom checks

Organization-specific checks can be stored in `.tfsec` as supported JSON/YAML custom-check files or loaded from a controlled directory/URL. Examples include required tags or approved network configuration.

### Governance rule

Do not let each repository silently exclude checks. Central changes should be peer-reviewed, linked to policy and tested.

---

## 29. Give a real example where tfsec detected a security violation

### Example

Terraform attempted to create a Storage Account with public network access allowed and no restrictive network rule.

The scanner reported that the account could be reachable from untrusted networks. The code was changed to deny public access, use an approved Private Endpoint and integrate private DNS.

### Another example

An NSG allowed inbound SSH from `0.0.0.0/0`. The scanner failed the pull request, and the design was changed to use Azure Bastion/private access.

---

## 30. What was the exact violation?

### Interview wording

> The Terraform configuration allowed unrestricted inbound SSH on TCP 22 from the internet. The rule used a source prefix equivalent to any address. The IaC scan marked it as a high-risk network exposure.

Or:

> The Storage Account did not enforce the approved private-access baseline and allowed public network connectivity.

If the interviewer asks for the exact check ID, provide it only when you know the tool/version used, because rule identifiers can change between tool versions. The configuration and risk are more important than memorizing an outdated ID.

---

## 31. Why was that considered a security risk?

### Answer

Unrestricted SSH creates a large attack surface for password attacks, credential stuffing and exploitation of exposed services. Public Storage access can lead to data exposure or unauthorized access if another permission is misconfigured.

The preferred design is:

- No direct public IP on the workload VM.
- Bastion, VPN or ExpressRoute for administration.
- Least-privilege NSGs.
- Private Endpoints and disabled public network access for sensitive PaaS services.
- Logging and alerting for access attempts.

---

# F. GitHub Actions and Jenkins

## 32. How comfortable are you with Jenkins?

### Resume-aligned safe answer

My strongest hands-on pipeline experience is Azure DevOps, and I am also comfortable with GitHub Actions. I understand Jenkins declarative pipelines, stages, agents, credentials, plugins, post conditions and shared-library concepts. I can read, modify and troubleshoot a Jenkinsfile, but I would describe my Jenkins level honestly if I have not administered a large Jenkins platform in Production.

### Follow-up areas to prepare

- Controller and agent architecture.
- Declarative versus scripted pipeline.
- Credentials binding.
- Shared libraries.
- Plugin/version management.
- Workspace cleanup.
- Pipeline replay and logs.
- Kubernetes-based agents.

---

## 33. Difference between GitHub Actions and Jenkins

| GitHub Actions | Jenkins |
|---|---|
| Hosted as part of GitHub | Self-managed or managed by the organization |
| YAML workflows in `.github/workflows` | Jenkinsfile plus Jenkins platform configuration |
| GitHub-hosted or self-hosted runners | Static, cloud or Kubernetes agents |
| Strong native GitHub event integration | Broad plugin ecosystem and highly customizable |
| Platform updates handled by GitHub for hosted service | Team owns controller security, upgrades, backup and plugins |
| OIDC integration available | Credentials/federation configured through Jenkins ecosystem |

### Selection answer

Choose based on source platform, governance, existing investment, network isolation, customization and operational ownership. Jenkins provides flexibility but creates more platform-maintenance responsibility.

---

## 34. What security scans are available in GitHub Actions?

### Native or GitHub-integrated capabilities

- CodeQL code scanning.
- Secret scanning and push protection where available.
- Dependabot alerts and updates.
- Dependency review.
- Artifact attestations and related supply-chain features.

### Third-party integrations

- SonarQube/SonarQube Cloud.
- Trivy.
- tfsec or Trivy config.
- Checkov.
- Snyk or other SCA/SAST tools.
- DAST tools.
- Cosign for signing/verification.

### Security practices for workflows

- Minimum `GITHUB_TOKEN` permissions.
- Pin third-party actions to trusted versions or commit SHAs according to policy.
- Use OIDC for cloud access.
- Protect environments.
- Avoid untrusted pull-request code accessing secrets.
- Review self-hosted runner isolation.

---

## 35. How do you configure GitHub Actions?

### Answer

Create a YAML file under:

```text
.github/workflows/
```

Define:

- `name`.
- `on` trigger.
- `permissions`.
- Jobs and runner.
- Steps/actions.
- Variables and secrets.
- Environments and approvals.
- Conditions, dependencies and artifacts.

Example:

```yaml
name: ci
on:
  pull_request:
  push:
    branches: [main]

permissions:
  contents: read

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: echo "Run tests and scans"
```

---

## 36. How do GitHub Actions pipelines get triggered?

### Common triggers

- `push`.
- `pull_request`.
- `workflow_dispatch` for manual runs.
- `schedule` using cron.
- `workflow_call` for reusable workflows.
- Release, tag, issue or other repository events.
- `repository_dispatch` for external events.

### Example

```yaml
on:
  pull_request:
    branches: [main]
  push:
    tags: ['v*']
  workflow_dispatch:
```

Use path filters so a Terraform workflow does not run for unrelated documentation changes.

---

# G. Python, Groovy and Ruby

## 37. How good are you with Python?

### Safe answer

I use Python at a practical scripting level for DevOps automation, file and JSON processing, API calls and small operational utilities. My strongest automation language is PowerShell for Microsoft environments, but I can read and write Python scripts and continue to improve through hands-on tasks.

Prepare examples involving:

- Reading JSON/YAML.
- REST API calls.
- File processing.
- Azure SDK/CLI orchestration.
- Exception handling and logging.

---

## 38. How good are you with Groovy?

### Safe answer

I understand Groovy mainly in the context of Jenkins pipelines: variables, functions, conditions, loops, stages and shared-library calls. If I have not built complex Groovy applications, I state that clearly.

---

## 39. How good are you with Ruby?

### Safe answer

Ruby is not my primary language. I can understand and write small functions when required, but my practical scripting focus is PowerShell, Bash and Python. This is better than overstating expertise.

---

## 40. Write a function to extract the last two characters from a string

### Python

```python
def last_two(value: str) -> str:
    return value[-2:]

print(last_two("Azure"))  # re
```

Python slicing safely returns the complete string when its length is less than two.

### Groovy

```groovy
String lastTwo(String value) {
    return value == null ? "" : value.takeRight(2)
}

println lastTwo("Azure")  // re
```

### Ruby

```ruby
def last_two(value)
  value.to_s.last(2)
end

puts last_two("Azure") # re
```

### Interview discussion

Clarify expected behavior for null, empty and one-character input before coding.

---

# H. Current Project

## 41. Explain your current project

### Answer

The sample project is an Azure-based monitoring and alerting platform for industrial operations. IoT devices send equipment telemetry to Azure Event Hubs. A Python backend processes data and a React frontend provides dashboards and alerts. The solution uses managed database services, Azure networking, Application Gateway, Key Vault and centralized monitoring.

My responsibility is the cloud infrastructure and DevOps side: Azure foundation, Terraform, CI/CD, access, monitoring and deployment troubleshooting.

---

## 42. What problem is your project solving?

### Answer

The platform gives operations teams a centralized view of equipment health and abnormal conditions. It helps detect temperature, vibration or performance issues early, supports maintenance decisions and reduces the risk of unplanned downtime.

The DevOps work solves a second problem: it makes environments and releases repeatable, secure and observable instead of relying on manual setup.

---

## 43. What is your role in the project?

### Answer

My role includes:

- Azure infrastructure provisioning and administration.
- Terraform module and environment management.
- Azure DevOps pipeline creation and maintenance.
- Git pull-request workflow.
- Networking, RBAC, Key Vault and monitoring configuration.
- Release and incident support.
- Documentation, change control and coordination with developers/security/network teams.

---

## 44. What DevSecOps work are you doing in the project?

### Answer

The project uses security controls such as pull-request review, protected branches, secure service connections, Key Vault, least-privilege RBAC, private networking, IaC review and centralized logging. Where code, image and IaC scanning tools are integrated, findings are evaluated through quality gates and vulnerability thresholds.

If SonarQube, Trivy or tfsec are lab/interview knowledge rather than production ownership, state that clearly and explain the implementation approach without presenting it as completed production work.

---

## 45. What infrastructure have you provisioned?

### Answer

Typical resources include resource groups, VNets, subnets, NSGs, VMs, storage, Load Balancer/Application Gateway, Key Vault, Log Analytics, monitoring alerts, private endpoints, RBAC assignments, backup configuration and related shared services.

---

## 46. How is the application deployed?

### Answer

Application code is built, tested, scanned and packaged through CI. The versioned artifact or image is published to an approved repository. CD promotes that same artifact through Dev, QA and Production with environment-specific configuration, approvals, smoke tests and rollback planning.

Infrastructure is deployed through a separate Terraform pipeline to reduce coupling and maintain clear permissions.

---

## 47. What technologies are being used?

### Answer

- Azure and Azure DevOps.
- Terraform and ARM/Bicep.
- Git/GitHub Actions.
- PowerShell, Bash and Azure CLI.
- Azure networking, VMs, storage, Key Vault and monitoring.
- React, Python and managed SQL/PostgreSQL for the sample application.
- Event Hubs for telemetry.
- Docker/AKS as working-familiarity technologies.
- SonarQube, Trivy, tfsec and Jenkins for DevSecOps interview/lab coverage unless used directly in the project.

---

# I. Container Security

## 48. How do you perform container image scanning?

### Process

1. Build the image from an approved Dockerfile and base image.
2. Tag it with an immutable identifier such as commit SHA.
3. Scan packages, language dependencies, secrets and misconfigurations.
4. Fail based on risk policy.
5. Publish the report.
6. Push the approved image or scan again by digest in the registry.
7. Continue registry/runtime scanning because new CVEs can appear later.

### Command

```bash
trivy image \
  --exit-code 1 \
  --severity CRITICAL,HIGH \
  --ignore-unfixed \
  myregistry.azurecr.io/api:${BUILD_ID}
```

---

## 49. Why is container image scanning important?

### Answer

An application can have secure custom code but still contain vulnerable operating-system packages or libraries in its image. Image scanning identifies known CVEs, exposed secrets and some configuration issues before deployment. It also supports ongoing monitoring because a previously clean image may become vulnerable when a new CVE is published.

Image scanning is one control, not a guarantee. It must be combined with patching, minimal images, non-root execution, policy and runtime monitoring.

---

## 50. Why should containers run as a non-root user?

### Answer

If a process runs as root inside the container and an attacker compromises it, the attacker has greater privileges within the container and may have more opportunity to abuse mounted resources or kernel vulnerabilities. Running as a non-root user reduces impact and supports least privilege.

### Dockerfile example

```dockerfile
RUN addgroup --system app && adduser --system --ingroup app app
USER app
```

Also drop unnecessary capabilities, use read-only filesystems where possible and avoid privileged mode.

---

## 51. Why use minimal base images such as Alpine?

### Answer

A smaller image usually has fewer packages, fewer vulnerabilities, faster pulls and a smaller attack surface. However, Alpine is not automatically the best choice for every application. Its musl-based environment can cause compatibility or debugging challenges.

The better principle is to use a **minimal, trusted and supported base image** such as a slim or distroless image that matches application requirements. Patch it regularly and pin approved versions/digests.

---

## 52. What Trivy command do you use for image scanning?

```bash
trivy image --exit-code 1 --severity CRITICAL,HIGH --ignore-unfixed repository/image:tag
```

For JSON reporting:

```bash
trivy image \
  --format json \
  --output trivy-report.json \
  --severity CRITICAL,HIGH \
  repository/image:tag
```

For a filesystem/repository scan:

```bash
trivy fs --scanners vuln,secret,misconfig .
```

---

## 53. Give a real example where image scanning blocked a build

### Scenario

> A Docker image used an old base image containing a Critical OpenSSL or system-library vulnerability with an available fixed package. Trivy returned exit code 1, so the pipeline stopped before pushing the release image. We updated the base image, rebuilt the application, reran tests and rescanned. The new image passed and was promoted.

### Strong follow-up

Explain how you used `docker history`, the Dockerfile and package information to identify whether the vulnerable package came from the base image or an application dependency.

---

# J. Build Failure Scenario

## 54. Your build is blocked because of vulnerabilities. What are your next steps?

### Response process

1. Do not bypass the gate immediately.
2. Save and review the exact scan report.
3. Identify vulnerability, package, image layer, severity and fixed version.
4. Confirm whether the issue is in direct code, transitive dependency or base image.
5. Check exploitability and application exposure.
6. Upgrade, patch, remove or replace the component.
7. Rebuild and rerun all relevant tests/scans.
8. If no fix exists, follow the approved risk-exception process.
9. Document the outcome and prevent recurrence.

---

## 55. How would you unblock the build?

### Preferred remediation order

1. Upgrade to the fixed package/base image.
2. Remove the unused vulnerable component.
3. Replace it with a supported alternative.
4. Apply an official vendor patch.
5. Add a compensating control if technically justified.
6. Request a time-bound exception only when the risk is understood and approved.

Never unblock by changing `--exit-code 1` to `0`, adding `continueOnError`, or globally ignoring the vulnerability without review.

---

## 56. How do you differentiate a true positive from a false positive?

### Investigation

- Confirm the package/version actually exists in the final artifact.
- Check whether it is reachable or used at runtime.
- Review vendor advisory rather than relying only on one generic database.
- Check whether the OS vendor backported the fix without changing the upstream version pattern.
- Confirm image architecture and distribution.
- Reproduce with another scanner or package query if needed.
- Review scanner version and database freshness.
- Involve security/application owners for ambiguous findings.

### Definitions

- **True positive:** vulnerable component exists and the finding applies.
- **False positive:** scanner reports a vulnerability that does not apply to the actual component/context.
- **True but not exploitable:** finding is technically valid, but application context greatly limits exploitability. This still needs documented risk assessment; it is not automatically a false positive.

---

## 57. What remediation process do you follow before rerunning the pipeline?

### Process

1. Create or link a vulnerability ticket.
2. Update the affected package/base image/configuration.
3. Run local unit and security tests.
4. Update lock files and SBOM if used.
5. Build a fresh artifact without unsafe cache reuse.
6. Run targeted scan locally.
7. Commit through a pull request.
8. Let the full pipeline rerun.
9. Confirm the finding is removed and no regression is introduced.
10. Close the ticket with scan evidence and version details.

### Scenario

> The fix required upgrading a library with a breaking change. We created a branch, updated the dependency, modified affected code, ran unit and integration tests, rebuilt the image and rescanned. We did not simply suppress the CVE because a supported fix existed.

---

## Official references

- SonarQube analysis overview: https://docs.sonarsource.com/sonarqube-server/analyzing-source-code/analysis-overview
- SonarQube branch analysis: https://docs.sonarsource.com/sonarqube-server/analyzing-source-code/branch-analysis/introduction
- Trivy vulnerability scanning: https://trivy.dev/docs/latest/scanner/vulnerability/
- Trivy filtering and suppression: https://trivy.dev/docs/latest/configuration/filtering/
- tfsec configuration: https://aquasecurity.github.io/tfsec/latest/guides/configuration/config/
- tfsec custom checks: https://aquasecurity.github.io/tfsec/latest/guides/configuration/custom-checks/
- GitHub Actions workflow documentation: https://docs.github.com/actions/reference/workflows-and-actions
