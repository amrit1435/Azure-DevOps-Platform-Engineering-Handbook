# Roadmap

## Release 1 - Consolidated interview bank

- [x] Profile and current project
- [x] Azure administrator and networking scenarios
- [x] Azure Landing Zone and Terraform
- [x] Complete TCS platform engineering, Azure, Terraform, CI/CD and troubleshooting bank
- [x] Persistent DevSecOps questions
- [x] Resume-based and missing core DevOps questions
- [x] GitHub publishing guide
- [x] Word handbook
- [x] TCS interview repetition tracker
- [x] LTM client round 2 AWS/Azure/Terraform/Ansible interview bank and tracker

## Release 2 - Hands-on labs

- [ ] Azure Landing Zone lab using Terraform
- [ ] Hub-spoke networking lab
- [ ] Azure DevOps multi-stage pipeline lab
- [ ] GitHub Actions OIDC deployment lab
- [ ] Docker and AKS deployment lab
- [ ] SonarQube, Trivy and IaC scanning lab
- [ ] Central monitoring with Azure Monitor and Grafana

## Release 3 - Mock interviews

- [ ] Azure Administrator mock interview
- [ ] Azure DevOps mock interview
- [ ] DevSecOps mock interview
- [ ] Platform Engineering mock interview
- [ ] AKS troubleshooting mock interview

- **v1.3:** Azure DevOps, Terraform state/drift, Production deployment troubleshooting, PaaS scaling and HA interview round.

## v1.4 - Architect-Level Azure Landing Zone

- Enterprise-scale management-group and subscription design
- Hub-and-spoke and Virtual WAN architecture
- Zero Trust identity, PIM, managed identity and OIDC
- Terraform module, backend, drift and pipeline design
- DevSecOps, observability, resilience, FinOps and production readiness


## Release 1.5 - Priority Terraform Architect Bank

- [x] Top 20 Senior/Architect Terraform questions
- [x] Private AKS architecture
- [x] Multi-region Landing Zone architecture
- [x] Terraform DevSecOps pipeline and drift/recovery scenarios
