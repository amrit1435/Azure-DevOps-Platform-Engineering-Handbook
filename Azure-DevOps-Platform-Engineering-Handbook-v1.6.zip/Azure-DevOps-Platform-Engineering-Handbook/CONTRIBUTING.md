# Contributing to the Handbook

Use the following format when adding a new interview question:

```markdown
## Question

### Short interview answer

### Detailed answer

### Scenario-based example

### Implementation or commands

### Common mistakes

### Follow-up questions
```

## Content rules

- Use simple and direct language.
- Do not claim project experience that did not happen.
- Remove client names, IDs, IP addresses and secrets.
- Prefer official Microsoft, GitHub, HashiCorp, Kubernetes, Sonar and Trivy documentation.
- Test commands before treating them as production-ready.
- Explain trade-offs rather than presenting one design as correct for every situation.
