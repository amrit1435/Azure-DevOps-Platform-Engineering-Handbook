# Changelog

## 1.6.0 - 2026-09-05

- Added 38 Git fundamentals interview questions with simple answers and practical DevOps/Terraform examples.
- Added Git working directory, staging area, commits, status, history, branching, merge conflicts and remote repository concepts.
- Added Git vs GitHub, clone/pull/push comparisons and complete local-to-remote workflow.
- Updated the Word handbook and repository index.


## 1.5.0 - 2026-08-18

- Added the Priority-1 Top 20 Azure + Terraform + DevSecOps Architect interview bank.
- Added architecture, implementation, security, troubleshooting and production scenarios for the highest-weight questions.
- Added enterprise Terraform repository/state design, OIDC authentication, Key Vault secret patterns, drift handling and partial-apply recovery.
- Added production private AKS architecture and multi-subscription/multi-region Landing Zone design.
- Updated question index, README and Word handbook export.

## v1.3 - 2026-07-22

- Added 22 Azure DevOps, Terraform and Production deployment interview questions.
- Added detailed troubleshooting for failed deployments, log analysis and rollback.
- Added Terraform state, refresh, drift, state locking and deleted-resource recovery.
- Added Azure PaaS scaling and high-availability scenarios.
- Added a dedicated interview tracker for repeated-topic analysis.


## 1.2.0 - 2026-07-20

- Added 12 LTM client round 2 interview questions with detailed, simple-language answers and scenario-based examples.
- Added AWS S3 security, subnet connectivity, Transit Gateway, Application Load Balancer and IAM trust-policy coverage.
- Added current Azure Management Group and Azure DevOps workload-identity federation guidance.
- Added Terraform drift, data sources and idempotency explanations.
- Added Ansible inventory, playbook, role, security and rolling-deployment guidance.
- Added LTM interview tracker, rapid revision and official AWS/Ansible references.
- Updated the Word handbook and repository export to release 1.2.

## 1.1.0 - 2026-07-19

- Consolidated 25 additional TCS Azure DevOps questions into the existing TCS chapter.
- Added detailed answers for Landing Zone, Application Gateway, Load Balancer, Storage, subnets, Terraform providers, Git branching, CI/CD and VM change safety.
- Added Docker, Kubernetes, Azure networking, pipeline and Terraform troubleshooting scenarios.
- Added a TCS interview repetition tracker for future interview records.
- Updated the Word handbook and official-reference list.

## 1.0.0 - 2026-07-17

- Consolidated all interview questions shared in the preparation conversation.
- Added detailed answers in simple language and scenario-based examples.
- Added questions derived from the resume and missing Azure DevOps topics.
- Added Azure DevOps, GitHub Actions and Jenkins pipeline examples.
- Added Git and GitHub publishing instructions.

## [1.4.0] - 2026-07-31

### Added

- Architect-level enterprise Azure Landing Zone end-to-end interview chapter.
- Regulated-enterprise governance, network, identity, security and operating model.
- Terraform module, state, drift and zero-touch CI/CD architecture.
- Monitoring, backup, disaster recovery, FinOps and production-readiness guidance.
- Interview tracker for the comprehensive Azure Landing Zone architecture question.
